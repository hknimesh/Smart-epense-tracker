# SMART EXPENSE TRACKING AND ANALYTICS SYSTEM
## Phases 1–8 + Corporate Expense Management (Phase 1)

> **New:** the app now also supports a **Corporate Finance** mode (organizations, roles, departments, approval workflow). See [Corporate Expense Management](#corporate-expense-management-phase-1) below. Personal mode is unchanged.

An authenticated personal-finance application for recording expenses and income, setting monthly budgets, reviewing real dashboard/analytics data, exporting reports, and managing an account profile. Financial features use the signed-in account’s MySQL records; the ML features are optional estimates and review suggestions, not financial advice.

## Technology and architecture

- **Frontend:** React, React Router, Vite, Axios, Recharts
- **Backend:** Python, Flask, Flask-SQLAlchemy, SQLAlchemy ORM, PyMySQL
- **Database:** MySQL in local development; isolated in-memory SQLite databases in backend tests
- **Analysis:** Decimal/SQL aggregates for authoritative financial calculations; Pandas, NumPy, and Scikit-learn for documented optional baselines/classification
- **Authentication:** Werkzeug password hashes, signed HTTP-only cookie sessions, CSRF token checks on state-changing API requests

```text
backend/
  app.py                 Flask app factory, error handlers, schema commands
  config.py              Environment-backed database and session configuration
  models/                User, category, expense, income, and budget models
  routes/                Authenticated REST API blueprints
  services/              Validation, CRUD, analytics, dashboard, and ML services
  tests/                 SQLite-isolated API and service tests
frontend/
  src/components/        Shared navigation, forms, charts, and dialogs
  src/context/           Authentication/session context
  src/pages/             Dashboard, finance, analytics, reports, and profile screens
  src/services/          Axios API clients
  src/styles/            Responsive page styles
  src/test/              Frontend test setup
database/
  README.md              MySQL database and least-privilege account setup
```

Phase 1 provides the React/Vite interface. Phase 2 adds Flask, MySQL-backed accounts, and cookie-based authentication. Phase 3 adds authenticated expense management and category administration. Phase 4 adds user-scoped income and monthly budget management. Phase 5 connects the dashboard, charts, and insights to authenticated financial data. Phase 6 adds weekly/monthly/custom analytics and CSV reports. Phase 7 adds optional, user-scoped categorization, predictions, unusual-spending checks, and duplicate candidates.

### Included
- Login and registration connected to Flask APIs with frontend and server-side validation
- Protected dashboard routes with responsive navigation across finance, analytics, reports, and account screens
- Expense CRUD, server-side search/filter/sort, and paginated transaction history
- Income CRUD with inclusive date-range filtering and deterministic sorting
- Monthly overall and category-specific budgets with server-calculated spending, balances, utilization, and over-budget status
- Database-enforced uniqueness for a user's overall or category budget per month and year
- Authenticated dashboard summary, recent transactions, six-month trends, category breakdown, and budget-progress APIs
- Recharts visualizations, selected-month filtering, real transaction history, and transparent financial insights
- Weekly (Monday–Sunday), monthly, and custom inclusive date-range analytics with previous-period comparisons, category totals, largest transactions, and monthly budget utilization
- Authenticated CSV exports containing filtered transaction rows and matching income, expense, savings, and balance totals
- Aggregations use MySQL/SQLAlchemy `SUM` and Python `Decimal` for monetary precision; Pandas/NumPy are intentionally not used for these database-backed financial totals
- Weekly and monthly dashboard views reuse the authenticated analytics report; week boundaries are Monday–Sunday. Month-to-date budget progress remains distinct from weekly cash flow.
- Optional ML APIs provide a TF-IDF/logistic-regression category suggestion trained on small static example phrases, keyword fallback rules, a historical daily-average or Scikit-learn monthly prediction, category median/MAD unusual-spending flags, and exact normalized-text duplicate candidates. ML insights cannot mutate transactions.
- Profile and account management includes optional personal details, unique usernames, authenticated avatar uploads, current-password-confirmed email changes, password changes, and account logout.
- Profile photos are decoded and re-encoded as JPEG, PNG, or WebP, stored under the Flask instance directory (not the static web root), limited to 5 MB and 20 megapixels, and served only to the signed-in account owner.
- Lifetime totals and balance are separate from selected-month metrics; savings rate is monthly net income divided by monthly income, and average daily spending uses elapsed days in the current month or all days in a completed month
- Categories seeded from the predefined list; only emails in `ADMIN_EMAILS` can mutate categories
- HTTP-only signed session cookies and CSRF protection for state-changing requests
- Password hashing with Werkzeug; no passwords or session secrets are stored in browser local storage
- Idempotent category seed command and SQLite-isolated authentication tests

## ML implementation and limitations

- **Categorization:** Cached TF-IDF/logistic-regression classifier trained on a small static set of example phrases; transparent keyword rules are used for common examples or when the optional classifier is unavailable. The examples are not private user transactions. Suggestions require user confirmation.
- **Prediction:** A historical daily-average estimate with at least three completed months of history; linear regression is used when at least six completed months are available. Insufficient history returns no numeric estimate.
- **Unusual-spending flags:** Same-user, same-category historical median/MAD thresholds; a flag is neither a fraud determination nor an automatic transaction change.
- **Possible duplicates:** Conservative exact date/amount/category and normalized description/vendor comparisons. Results are review candidates only.
- These are deliberately simple baselines, not financial advice. The application does not send data to a third-party model service.

## Database setup and schema

Install MySQL and create a database and application user using [database/README.md](database/README.md). The MySQL application user needs the documented permissions to initialize tables and run the profile schema migration. Configure the backend environment file before starting Flask.

`flask --app app init-db` creates missing tables and seeds built-in categories without dropping or resetting existing tables. For an existing database, back it up and run `flask --app app migrate-profile` to add missing nullable profile fields and username uniqueness. The profile migration is repeatable. Neither command deletes financial records.

Tests use in-memory SQLite fixtures and do not read or write configured MySQL records. Local runtime verification uses only the health endpoint; it does not create, modify, or delete user transactions.

## Environment variables

Copy the templates and use local values:

```powershell
Copy-Item backend/.env.example backend/.env
Copy-Item frontend/.env.example frontend/.env
```

Backend settings:

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Long, random, stable Flask session-signing key; never use the template value in a real deployment. |
| `MYSQL_HOST`, `MYSQL_PORT` | MySQL server address and port. |
| `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE` | Application database credentials and database name. |
| `FRONTEND_ORIGINS` | Comma-separated allowed frontend origins; defaults to localhost and 127.0.0.1 on port 5173. |
| `SESSION_COOKIE_SECURE` | Set `true` behind HTTPS; keep `false` only for local HTTP development. Cookies are HTTP-only and SameSite=Lax. |
| `FLASK_DEBUG` | Set `true` only for local development. |
| `ADMIN_EMAILS` | Optional comma-separated existing account emails allowed to administer shared categories. |
| `PROFILE_UPLOAD_DIR` | Optional absolute persistent directory for profile photos; defaults to `backend/instance/profile_photos`. |

The frontend uses `VITE_API_BASE_URL`, defaulting to `http://localhost:5000/api`. Use matching hostnames for the frontend/backend in local development because cookies are host-scoped. The Vite default origin must be listed in `FRONTEND_ORIGINS`.

Never commit `backend/.env` or `frontend/.env`. `.env.example` files contain placeholders only. `SECRET_KEY` falls back to a generated process-local value if it is not set; configure a stable secret before relying on persistent sessions across restarts.

## Installation and run

Run these commands from the project root in PowerShell.

```powershell
Set-Location backend
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m flask --app app init-db
python -m flask --app app migrate-profile
python -m flask --app app run
```

The API listens at `http://localhost:5000`; `GET /api/health` checks the MySQL connection. In another terminal:

```powershell
Set-Location frontend
npm install
npm run dev
```

Vite defaults to `http://localhost:5173`.

## API overview

All account and financial routes below require the authenticated session except registration, login, CSRF bootstrap, and health. State-changing requests must send `X-CSRF-Token`. Record reads and updates are scoped to the current user; category administration additionally requires an email listed in `ADMIN_EMAILS`.

| Group | Routes |
|---|---|
| Health/auth | `GET /api/health`; `GET /api/auth/csrf`; `POST /api/auth/register`; `POST /api/auth/login`; `POST /api/auth/logout`; `GET /api/auth/me` |
| Expenses | `GET/POST /api/expenses`; `GET/PUT/DELETE /api/expenses/<id>` |
| Income | `GET/POST /api/income`; `GET/PUT/DELETE /api/income/<id>` |
| Budgets | `GET/POST /api/budgets`; `GET/PUT/DELETE /api/budgets/<id>` |
| Categories | `GET/POST /api/categories`; `PUT/DELETE /api/categories/<id>` |
| Dashboard | `GET /api/dashboard/summary`; `GET /api/dashboard/recent-transactions`; `GET /api/dashboard/monthly-trends`; `GET /api/dashboard/category-breakdown`; `GET /api/dashboard/budget-progress` |
| Analytics/reports | `GET /api/analytics` with weekly/monthly/custom filters; `GET /api/analytics/export.csv` |
| ML insights | `POST /api/ml/categorize`; `GET /api/ml/prediction`; `/anomalies`; `/duplicates`; `/insights` |
| Profile/security | `GET/PUT /api/users/profile`; `POST/DELETE/GET /api/users/profile/photo`; `POST /api/users/password` |

Dates are ISO `YYYY-MM-DD`; report date filters are inclusive. Weekly analytics use Monday through Sunday. Monetary API values are decimal-formatted strings.

## Seed data

`flask --app app init-db` seeds the eight built-in expense categories idempotently. There is no development user, sample financial transaction seed, or default account/password. Register an account through the UI or `POST /api/auth/register`. Category writes require setting the registered email in `ADMIN_EMAILS`.

## Tests and build checks

Backend and frontend checks:

```powershell
Set-Location backend
python -m pip install -r requirements.txt
python -m pytest
Set-Location ..\frontend
npm ci
npm test
npm run build
```

Backend tests use isolated in-memory SQLite databases. Frontend tests exercise registration/login interactions using mocked API context; they do not call a live API or database.

## Troubleshooting and known limitations

- If `/api/health` fails, verify MySQL is running, the database/user exists, `backend/.env` matches the local MySQL configuration, and the account can connect.
- If the browser reports a CORS or login/session issue, use a hostname consistently (`localhost` or `127.0.0.1`), include the frontend origin in `FRONTEND_ORIGINS`, and keep credentials enabled.
- For a missing database table/column, back up the database and run `flask --app app init-db` and `flask --app app migrate-profile`; these are non-resetting commands.
- If ML dependencies are unavailable, categorization rules and the prediction/statistical fallbacks remain available; predictions may be unavailable when history is insufficient.
- Password reset by email and email verification are not implemented. Users can change their password after signing in from Profile → Account & Security; email changes require the current password.
- Profile images are private authenticated API responses. Multi-instance deployments need shared durable photo storage and HTTPS; the supplied defaults target local development and are not, by themselves, a production deployment configuration.


---

# Corporate Expense Management (Phase 1)

The same application now runs in two modes. **Personal Finance** is the original tracker, unchanged. **Corporate Finance** adds organizations, role-based access, departments, expense submission and a fixed **Employee → Manager → Finance** approval workflow. Both modes share one login page, one user table and one Flask/React app, but their data is stored in separate tables and never mixed.

Phase 1 is the *foundation* only. Corporate AI/analytics (anomaly detection, forecasting, duplicate detection, budget intelligence, AI insights) are intentionally **not** implemented; see [Remaining limitations](#remaining-limitations).

## How it fits together

- **One account, many memberships.** A person has one `user` row (the existing table). Their corporate role lives on an `organization_memberships` row, so the same login can be a personal user and a member of one or more organizations with different roles. Role is **never** a property of the user.
- **One corporate login.** Corporate Finance uses a single endpoint (`POST /api/corporate/auth/login`). The role is read from the database after authentication; the client can neither choose nor send a role.
- **Server-side RBAC.** Every corporate endpoint is wrapped with `corporate_required(...)`, which re-loads the membership from the database on every request (so deactivation or a role change takes effect immediately) and checks role and organization. Hiding buttons in React is only a convenience.
- **Status codes.** `401` not signed in · `403` role not permitted / not in corporate mode · `404` resource not visible to you (other organization, other employee, other department; existence is not leaked) · `409` invalid workflow transition or conflict · `429` too many failed login/join attempts.

### New files

```text
backend/
  corporate_cli.py                    init-corporate-db and seed-corporate-demo commands
  models/  organization.py, department.py, organization_membership.py,
           corporate_expense.py, expense_approval.py, audit_log.py, corporate_constants.py
  routes/  organization_routes.py     corporate auth, session, organization, members
           department_routes.py       departments
           corporate_routes.py        expenses, receipts, role dashboards, reports
           approval_routes.py         approval queues and approve/reject/pay
  services/ rbac.py                   corporate_required decorator + context
            corporate_service.py      organizations, joining, login, members, departments
            corporate_expense_service.py  validation, role scoping, filters
            approval_service.py       workflow engine (atomic transitions)
            corporate_report_service.py   dashboards, reports, CSV
            receipt_service.py        receipt validation/storage
            corporate_demo_service.py demo data generator / cleanup
            rate_limit.py, corporate_errors.py
  tests/test_corporate.py             49 tests
database/migrations/001_add_corporate_tables.sql
frontend/src/
  pages/Login.jsx (modified)          Personal / Corporate selector
  pages/RegisterOrganization.jsx, JoinOrganization.jsx
  pages/corporate/                    dashboards, approvals, reports, employees, departments, ...
  components/corporate/               layout, tables, filters, modal, charts, status badges
  context/AuthContext.jsx (extended)  mode, membership, role
  styles/corporate.css                namespaced (.corp-*) so personal pages are unaffected
```

Existing files modified: `backend/app.py` (register blueprints, 3 public CSRF paths, CLI registration), `backend/config.py` (optional `CORPORATE_RECEIPT_DIR`), `backend/models/__init__.py` (exports), `backend/.env.example`, `frontend/src/App.jsx`, `frontend/src/context/AuthContext.jsx`, `frontend/src/pages/Login.jsx`, `frontend/src/services/api.js` (appended `corporateApi`). **No personal route, service, model or ML file was changed.**

## Roles and permissions

| Capability | Org Admin | Employee | Manager | Finance Officer | Executive |
|---|:--:|:--:|:--:|:--:|:--:|
| Organization settings, code, joining on/off | ✔ | | | | |
| Add members, assign roles/departments, (de)activate | ✔ | | | | |
| Create/edit/deactivate departments, assign managers | ✔ | | | | |
| Submit corporate expenses, edit while pending manager | | ✔ (own) | | | |
| View expenses | | own | managed departments | whole organization | whole organization (read-only) |
| Approve / reject (stage 1) | | | managed departments | | |
| Verify / reject (stage 2), mark paid | | | | ✔ | |
| Role dashboards and basic reports | admin overview | own | department | organization | organization |
| CSV export | | | scoped | ✔ | ✔ |

Notable rules: the **administrator has no automatic access to expenses or financial reports**; nobody can review their **own** expense; a manager only reviews departments they are **explicitly assigned to manage**; admins cannot change their own role/status and the last active admin cannot be removed; users cannot change their own role through any API (including profile).

## Approval workflow

```text
Employee submits ─► pending_manager ─ manager approves ─► pending_finance ─ finance verifies ─► approved ─ finance marks paid ─► paid
                         │                                      │
                         └──── manager rejects (reason) ──► rejected ◄── finance rejects (reason) ┘
```

Displayed as: Pending Manager Approval · Pending Finance Verification · Approved · Paid · Rejected. Every transition is validated on the server and written to `expense_approvals` (reviewer, previous status, new status, comments, timestamp, starting with the submission itself). Transitions use a conditional `UPDATE ... WHERE status = <previous>`, so two reviewers racing on the same expense cannot both succeed (the loser gets `409`). Rejections require a reason. Rejected and Paid are final; to correct a rejected claim the employee submits a new one.

**Figure definitions used by dashboards (all computed from the database):**
*Expenditure* = approved + paid (finance-verified). *Approved* (finance dashboard card) = approved + paid. *Reimbursement pending* = status `approved` (verified, not yet paid). *Pending* = pending manager + pending finance.

## Database setup and upgrade

All corporate tables are **new**; no personal table is altered. Choose one:

**A. Existing installation (has personal data).** From `backend`, with the venv active:
```powershell
python -m flask --app app init-corporate-db
```
Creates only the missing corporate tables (`organizations`, `departments`, `organization_memberships`, `corporate_expenses`, `expense_approvals`, `organization_audit_logs`). Re-running reports "none (already present)". It refuses to run until the base schema exists.

**B. Plain SQL** (e.g. MySQL Workbench): run `database/migrations/001_add_corporate_tables.sql` against your database. It is additive and idempotent (`CREATE TABLE IF NOT EXISTS`).

**C. Brand-new installation:** the existing `python -m flask --app app init-db` already creates every table, corporate ones included, because the models are registered.

Monetary amounts are `DECIMAL(12,2)`. Role, status and amount rules are also enforced by database `CHECK` constraints; `(organization_id, user_id)` and `(organization_id, department_name)` are unique; foreign keys use `RESTRICT` so organizational history cannot be silently deleted.

## Windows installation and run

Prerequisites: Python 3.11+, Node.js 20+, MySQL 8. Use PowerShell from the project root.

1. **Database** — follow `database/README.md` (create `smart_expense_tracking` and a least-privilege user; the grants listed there are sufficient).
2. **Backend**
```powershell
Set-Location backend
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env        # then edit .env: MYSQL_PASSWORD and a long random SECRET_KEY
python -m flask --app app init-db
python -m flask --app app migrate-profile
python -m flask --app app init-corporate-db      # safe on a new or existing database
python -m flask --app app seed-corporate-demo    # optional demo organization
python -m flask --app app run
```
3. **Frontend** (new terminal)
```powershell
Set-Location frontend
npm install
npm run dev
```
Open `http://localhost:5173`.

Optional `.env` setting: `CORPORATE_RECEIPT_DIR` (absolute path for uploaded receipts; default `backend/instance/corporate_receipts`, never inside the web root).

## Using Corporate mode

1. **Register an organization:** Login page → *Corporate Finance* → *Register your organization*. You become the Organization Administrator and the page shows a generated **organization code** (nine characters, e.g. `ABC7K2M9Q`: a readable name prefix plus six random characters from an unambiguous alphabet; also shown on the admin dashboard and Settings). The six default departments are created.
2. **Employees join:** *Join with an organization code* (full name, email, password, code). They always join as **Employee** with no department. An existing personal account can join by entering its own email and password (no duplicate account is created). The administrator then assigns a department and, if needed, another role in *Employees*.
3. **Or the admin adds people directly** (*Employees → Add employee*, new accounts only; people who already have an account must join with the code so they consent).
4. **Departments:** admin creates departments and assigns each a manager (must hold the Manager role). A manager reviews only departments assigned to them.
5. **Sign in:** *Corporate Finance* tab → *Corporate Login*. Users in several organizations pick one at login; *Switch to Personal* and organization switching are in the sidebar/account menu.

## Demonstration data

`seed-corporate-demo` creates one clearly labelled fictional organization, **Northwind Technologies (DEMO DATA)** (organization code `NWDDEMO26`, joining disabled): 5 departments (IT, Human Resources, Marketing, Sales, Operations), 20 users, and 420 expenses over the last 90 days across all categories, with realistic approval histories and a mix of all five statuses. Dates are relative to the day you run it; amounts are fictional. A banner reminds viewers it is demo data.

```powershell
python -m flask --app app seed-corporate-demo            # create (does nothing if it already exists)
python -m flask --app app seed-corporate-demo --reset    # remove the demo organization, then recreate it
python -m flask --app app seed-corporate-demo --cleanup  # remove only the demo data
```

Safety: everything belongs to one organization flagged `is_demo`; demo users all use the reserved domain `@northwind-demo.example`; no real/personal account is touched or attached; cleanup deletes only that organization's rows and demo-domain users who have no other memberships or personal data, and refuses to delete an organization that is not flagged demo. Do not run it on a production database.

**Demo logins** (Corporate Finance tab; all use the demonstration password `Demo@12345`):

| Role | Email |
|---|---|
| Organization Administrator | `priya.nair@northwind-demo.example` |
| Executive (CEO) | `rohan.mehta@northwind-demo.example` |
| Executive (CFO) | `ananya.iyer@northwind-demo.example` |
| Finance Officer | `vikram.shah@northwind-demo.example`, `meera.kulkarni@northwind-demo.example` |
| Manager (IT) | `arjun.rao@northwind-demo.example` |
| Manager (HR / Marketing / Sales / Operations) | `sneha.patil@…`, `karan.malhotra@…`, `divya.menon@…`, `rahul.deshmukh@…` (same domain) |
| Employee (IT) | `isha.kapoor@northwind-demo.example`, `nikhil.joshi@…` |

## Corporate API overview

All under `/api/corporate`; state-changing requests need `X-CSRF-Token`. Public: `POST /organizations/register`, `POST /auth/join`, `POST /auth/login`.

| Area | Endpoints |
|---|---|
| Session | `GET /session`, `POST /session/switch`, `GET /meta` |
| Organization (admin) | `GET/PUT /organization`, `POST /organization/regenerate-code`, `GET /dashboard/admin` |
| Members (admin) | `GET/POST /members`, `PUT /members/<id>` |
| Departments | `GET /departments` (scoped by role), admin: `POST`, `PUT /<id>`; `GET /<id>/members` (admin, that department's manager) |
| Expenses | `POST /expenses` (employee, JSON or multipart with `receipt`), `GET /expenses` (role-scoped, filters, pagination), `GET/PUT /expenses/<id>`, `GET /expenses/<id>/receipt` |
| Approvals | `GET /approvals?queue=manager|verification|payment&search=`, `POST /approvals/<expense_id>/approve|reject|pay` |
| Dashboards | `GET /dashboard/employee|manager|finance|executive` |
| Reports | `GET /reports/summary`, `GET /reports/export` (CSV), `GET /reports/transactions` (finance, executive) |

Expense list filters: `status` (comma-separated), `department_id`, `user_id`, `category`, `start_date`, `end_date`, `search`, `sort`, `page`, `per_page`.

## Security notes

Server-side RBAC on every endpoint · organization isolation (every query is filtered by the organization of the *verified membership*, never a client-supplied id) · client cannot set organization, user, department, status or role · department of an expense is derived from the employee's membership · secure organization codes (`secrets`), regeneratable, joining can be switched off · failed corporate login/join attempts are rate-limited (10 per 15 minutes per IP and per email; in-process, see limitations) · passwords hashed (Werkzeug), never returned · existing session cookie settings, CSRF enforcement and CORS unchanged · receipts: PDF/PNG/JPG only, ≤ 5 MB, content signature checked, random server-side names outside the web root, served only through an authorized endpoint with `nosniff` and a restrictive CSP · CSV exports neutralize spreadsheet-formula cells · approval history is append-only.

## Tests and verification results (Phase 1)

Results from the final run in the development environment (not simulated):

| Check | Result |
|---|---|
| Backend suite, `python -m pytest -q` | **132 passed, 2 failed** (134 total: the original 85 + 49 new corporate tests) |
| Frontend unit tests, `npm test` | **17 passed** (5 original + 12 new) |
| Frontend build, `npm run build` | **succeeds** |
| Browser end-to-end (headless Chromium, real Flask API on a real MariaDB 10.11 database, production build) | **41 checks passed, 0 console/server errors**: every page of all 5 roles; employee → manager → finance → paid; rejection with required reason; RBAC redirect; personal login and expenses page; organization registration and joining |
| Migration on MariaDB | `init-corporate-db` and the SQL script create only the 6 new tables, are re-runnable, and left a pre-existing personal user and expense intact; `seed-corporate-demo` (create / rerun / `--reset` / `--cleanup`) verified; dashboard totals compared with direct SQL aggregates matched exactly |

**The 2 failures are pre-existing and unrelated to Phase 1**: `tests/test_ml.py::test_prediction_reports_insufficient_history_without_a_fake_value` and `::test_prediction_with_sufficient_history_and_regression_or_baseline` hard-code October 2026 as a *future* month. After 1 November 2026 the (correct) prediction service refuses to predict a completed month, so the tests fail. They failed identically on the untouched original code before any change; the personal ML code was deliberately left untouched. Fix: make those tests use dates relative to today.

Run them yourself:
```powershell
Set-Location backend
.venv\Scripts\python.exe -m pytest -q                     # all backend tests (isolated in-memory SQLite)
.venv\Scripts\python.exe -m pytest -q tests\test_corporate.py
Set-Location ..\frontend
npm test
npm run build
```
Tests never touch your MySQL database.

## Remaining limitations

- **Phase 2 intentionally absent:** no corporate anomaly/duplicate detection, forecasting, budget intelligence, AI insights, or advanced executive analytics. The personal ML features are unchanged and still apply only to personal data.
- **Only the Employee role submits expenses.** Managers, finance officers and executives cannot file claims of their own (no one could approve them without breaking the "no self-approval" rule). A multi-level or self-service flow would need an approval-routing design.
- **Fixed workflow:** Employee → Manager → Finance only; no amount-based routing, delegation, or manager-less departments. Rejected claims cannot be resubmitted; the employee files a new one. Submitted expenses are never deleted, to keep the audit trail.
- **Department scope:** a manager is tied to departments through "department manager" assignment; one department has a single manager. Employees belong to one department per organization.
- **Currency:** a single currency (₹, INR) like the personal side; no multi-currency or tax handling.
- **Single-process rate limiter:** login/join throttling is in memory per server process; use a shared store (e.g. Redis) behind multiple workers.
- **Account recovery/invitations:** no email sending, password-reset or invitation links; admin-added members get a temporary password the admin must hand over securely.
- **Receipts** are stored on local disk and are not malware-scanned or virus-checked beyond type/size/signature validation.
- **Audit log** records key administrative actions but has no UI beyond the admin "recent activity" panel.
- **MariaDB note:** the *existing* `budgets` table uses `GENERATED ALWAYS AS (...) STORED NOT NULL`, which MySQL 8 accepts but MariaDB rejects. Use MySQL 8 as documented. (Found while testing on MariaDB; not changed.)
