"""Flask CLI commands for the corporate module: safe schema upgrade and demo data."""
import click
from flask import current_app
from sqlalchemy import inspect

from extensions import db


def register_corporate_cli(app):
    @app.cli.command("init-corporate-db")
    def init_corporate_db():
        """Create the corporate tables that are missing. Never alters or drops existing tables."""
        from models import (
            CorporateExpense, Department, ExpenseApproval, Organization, OrganizationAuditLog,
            OrganizationMembership,
        )
        if "user" not in inspect(db.engine).get_table_names():
            raise click.ClickException("Initialize the database first with `flask --app app init-db`.")
        tables = [m.__table__ for m in (
            Organization, Department, OrganizationMembership, CorporateExpense,
            ExpenseApproval, OrganizationAuditLog,
        )]
        existing = set(inspect(db.engine).get_table_names())
        db.metadata.create_all(db.engine, tables=tables, checkfirst=True)
        created = [t.name for t in tables if t.name not in existing]
        click.echo("Created tables: " + (", ".join(created) if created else "none (already present)"))
        click.echo("Personal tables and data were not modified.")

    @app.cli.command("seed-corporate-demo")
    @click.option("--reset", is_flag=True, help="Remove the existing demo organization first, then recreate it.")
    @click.option("--cleanup", is_flag=True, help="Only remove the demo organization and its demo users.")
    def seed_corporate_demo(reset, cleanup):
        """Create (or remove) the fictional demonstration organization."""
        from services import corporate_demo_service as demo
        if cleanup or reset:
            removed = demo.cleanup_demo()
            click.echo(f"Removed demo data: {removed}")
            if cleanup:
                return
        result = demo.seed_demo()
        if result is None:
            click.echo("Demo organization already exists. Use --reset to recreate it. Nothing was changed.")
            return
        click.echo(f"Demo organization created: {result['organization']} (code {result['code']}).")
        click.echo(f"Created {result['users']} users, {result['expenses']} expenses.")
        click.echo(f"All demo accounts use the password: {demo.DEMO_PASSWORD}  (demonstration only)")
