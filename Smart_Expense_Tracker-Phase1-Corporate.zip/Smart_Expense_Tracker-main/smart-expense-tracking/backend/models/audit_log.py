from datetime import datetime, timezone

from sqlalchemy import Index

from extensions import db


def _now():
    return datetime.now(timezone.utc)


class OrganizationAuditLog(db.Model):
    """Record of important administrative actions inside an organization."""

    __tablename__ = "organization_audit_logs"
    __table_args__ = (Index("ix_audit_org_created", "organization_id", "created_at"),)

    log_id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.organization_id", ondelete="RESTRICT"), nullable=False)
    actor_id = db.Column(db.Integer, db.ForeignKey("user.user_id", ondelete="SET NULL"), nullable=True)
    action = db.Column(db.String(60), nullable=False)
    details = db.Column(db.String(500))
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now)

    actor = db.relationship("User", foreign_keys=[actor_id])

    def to_dict(self):
        return {
            "log_id": self.log_id,
            "actor_name": self.actor.name if self.actor else "System",
            "action": self.action,
            "details": self.details,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
