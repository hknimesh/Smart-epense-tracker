"""Shared constants for the Corporate Expense Management module."""

ROLE_ADMIN = "org_admin"
ROLE_EMPLOYEE = "employee"
ROLE_MANAGER = "manager"
ROLE_FINANCE = "finance_officer"
ROLE_EXECUTIVE = "executive"

ROLES = (ROLE_ADMIN, ROLE_EMPLOYEE, ROLE_MANAGER, ROLE_FINANCE, ROLE_EXECUTIVE)
ROLE_LABELS = {
    ROLE_ADMIN: "Organization Administrator",
    ROLE_EMPLOYEE: "Employee",
    ROLE_MANAGER: "Manager",
    ROLE_FINANCE: "Finance Officer",
    ROLE_EXECUTIVE: "Executive (CEO/CFO)",
}

MEMBERSHIP_ACTIVE = "active"
MEMBERSHIP_INACTIVE = "inactive"
MEMBERSHIP_STATUSES = (MEMBERSHIP_ACTIVE, MEMBERSHIP_INACTIVE)

ORG_ACTIVE = "active"
ORG_INACTIVE = "inactive"
ORG_STATUSES = (ORG_ACTIVE, ORG_INACTIVE)

DEPT_ACTIVE = "active"
DEPT_INACTIVE = "inactive"
DEPT_STATUSES = (DEPT_ACTIVE, DEPT_INACTIVE)

DEFAULT_DEPARTMENTS = ("IT", "Human Resources", "Finance", "Marketing", "Sales", "Operations")

# Fixed approval workflow: Employee -> Manager -> Finance
STATUS_PENDING_MANAGER = "pending_manager"
STATUS_PENDING_FINANCE = "pending_finance"
STATUS_REJECTED = "rejected"
STATUS_APPROVED = "approved"
STATUS_PAID = "paid"

EXPENSE_STATUSES = (
    STATUS_PENDING_MANAGER,
    STATUS_PENDING_FINANCE,
    STATUS_REJECTED,
    STATUS_APPROVED,
    STATUS_PAID,
)
STATUS_LABELS = {
    STATUS_PENDING_MANAGER: "Pending Manager Approval",
    STATUS_PENDING_FINANCE: "Pending Finance Verification",
    STATUS_REJECTED: "Rejected",
    STATUS_APPROVED: "Approved",
    STATUS_PAID: "Paid",
}
# Statuses that count as company expenditure (verified by finance).
EXPENDITURE_STATUSES = (STATUS_APPROVED, STATUS_PAID)
PENDING_STATUSES = (STATUS_PENDING_MANAGER, STATUS_PENDING_FINANCE)

CORPORATE_CATEGORIES = (
    "Travel",
    "Food and accommodation",
    "Office supplies",
    "Software subscriptions",
    "Internet and communication",
    "Equipment",
    "Employee reimbursements",
    "Other",
)
PAYMENT_METHODS = ("Corporate Card", "Personal Card", "Cash", "Bank Transfer", "UPI", "Other")


def _in_clause(column, values):
    return f"{column} IN ({', '.join(repr(v) for v in values)})"


ROLE_CHECK_SQL = _in_clause("role", ROLES)
EXPENSE_STATUS_CHECK_SQL = _in_clause("approval_status", EXPENSE_STATUSES)
