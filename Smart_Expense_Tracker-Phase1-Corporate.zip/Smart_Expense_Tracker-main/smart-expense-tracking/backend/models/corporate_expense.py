from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, Index, Numeric

from extensions import db
from models.corporate_constants import EXPENSE_STATUS_CHECK_SQL, STATUS_LABELS, STATUS_PENDING_MANAGER


def _now():
    return datetime.now(timezone.utc)


class CorporateExpense(db.Model):
    """A business expense. Deliberately separate from the personal `expenses` table."""

    __tablename__ = "corporate_expenses"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_corporate_expenses_positive_amount"),
        CheckConstraint(EXPENSE_STATUS_CHECK_SQL, name="ck_corporate_expenses_status"),
        Index("ix_corp_exp_org_status", "organization_id", "approval_status"),
        Index("ix_corp_exp_org_date", "organization_id", "expense_date"),
        Index("ix_corp_exp_org_dept", "organization_id", "department_id"),
        Index("ix_corp_exp_org_user", "organization_id", "user_id"),
    )

    expense_id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.organization_id", ondelete="RESTRICT"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.user_id", ondelete="RESTRICT"), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey("departments.department_id", ondelete="RESTRICT"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.String(1000))
    amount = db.Column(Numeric(12, 2), nullable=False)
    category = db.Column(db.String(60), nullable=False)
    vendor = db.Column(db.String(160))
    payment_method = db.Column(db.String(40))
    receipt_path = db.Column(db.String(255))
    receipt_filename = db.Column(db.String(255))
    expense_date = db.Column(db.Date, nullable=False)
    approval_status = db.Column(db.String(30), nullable=False, default=STATUS_PENDING_MANAGER)
    rejection_reason = db.Column(db.String(500))
    paid_at = db.Column(db.DateTime(timezone=True))
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now, onupdate=_now)

    organization = db.relationship("Organization")
    submitter = db.relationship("User", foreign_keys=[user_id])
    department = db.relationship("Department")
    approvals = db.relationship(
        "ExpenseApproval", back_populates="expense", cascade="all, delete-orphan",
        order_by="ExpenseApproval.approval_id",
    )

    def to_dict(self, include_history=False):
        data = {
            "expense_id": self.expense_id,
            "organization_id": self.organization_id,
            "user_id": self.user_id,
            "employee_name": self.submitter.name if self.submitter else None,
            "department_id": self.department_id,
            "department_name": self.department.department_name if self.department else None,
            "title": self.title,
            "description": self.description,
            "amount": format(self.amount, ".2f"),
            "category": self.category,
            "vendor": self.vendor,
            "payment_method": self.payment_method,
            "has_receipt": bool(self.receipt_path),
            "receipt_filename": self.receipt_filename,
            "expense_date": self.expense_date.isoformat(),
            "approval_status": self.approval_status,
            "status_label": STATUS_LABELS.get(self.approval_status, self.approval_status),
            "rejection_reason": self.rejection_reason,
            "paid_at": self.paid_at.isoformat() if self.paid_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_history:
            data["history"] = [approval.to_dict() for approval in self.approvals]
        return data
