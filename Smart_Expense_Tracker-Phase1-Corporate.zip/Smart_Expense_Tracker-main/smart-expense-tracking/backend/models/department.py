from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, UniqueConstraint

from extensions import db
from models.corporate_constants import DEPT_ACTIVE


def _now():
    return datetime.now(timezone.utc)


class Department(db.Model):
    """A department inside one organization. `manager_id` points at the user who manages it."""

    __tablename__ = "departments"
    __table_args__ = (
        UniqueConstraint("organization_id", "department_name", name="uq_departments_org_name"),
        CheckConstraint("status IN ('active', 'inactive')", name="ck_departments_status"),
    )

    department_id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.organization_id", ondelete="RESTRICT"), nullable=False, index=True)
    department_name = db.Column(db.String(100), nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey("user.user_id", ondelete="SET NULL"), nullable=True, index=True)
    status = db.Column(db.String(20), nullable=False, default=DEPT_ACTIVE)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now)

    manager = db.relationship("User", foreign_keys=[manager_id])

    def to_dict(self):
        return {
            "department_id": self.department_id,
            "organization_id": self.organization_id,
            "department_name": self.department_name,
            "manager_id": self.manager_id,
            "manager_name": self.manager.name if self.manager else None,
            "status": self.status,
        }
