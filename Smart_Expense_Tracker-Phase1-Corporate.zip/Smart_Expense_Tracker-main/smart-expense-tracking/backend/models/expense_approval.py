from datetime import datetime, timezone

from extensions import db
from models.corporate_constants import STATUS_LABELS


def _now():
    return datetime.now(timezone.utc)


class ExpenseApproval(db.Model):
    """Immutable history of every status change of a corporate expense."""

    __tablename__ = "expense_approvals"

    approval_id = db.Column(db.Integer, primary_key=True)
    expense_id = db.Column(db.Integer, db.ForeignKey("corporate_expenses.expense_id", ondelete="CASCADE"), nullable=False, index=True)
    reviewer_id = db.Column(db.Integer, db.ForeignKey("user.user_id", ondelete="RESTRICT"), nullable=False, index=True)
    previous_status = db.Column(db.String(30))
    new_status = db.Column(db.String(30), nullable=False)
    comments = db.Column(db.String(500))
    action_date = db.Column(db.DateTime(timezone=True), nullable=False, default=_now, index=True)

    expense = db.relationship("CorporateExpense", back_populates="approvals")
    reviewer = db.relationship("User", foreign_keys=[reviewer_id])

    def to_dict(self):
        return {
            "approval_id": self.approval_id,
            "expense_id": self.expense_id,
            "reviewer_id": self.reviewer_id,
            "reviewer_name": self.reviewer.name if self.reviewer else None,
            "previous_status": self.previous_status,
            "new_status": self.new_status,
            "new_status_label": STATUS_LABELS.get(self.new_status, self.new_status),
            "comments": self.comments,
            "action_date": self.action_date.isoformat() if self.action_date else None,
        }
