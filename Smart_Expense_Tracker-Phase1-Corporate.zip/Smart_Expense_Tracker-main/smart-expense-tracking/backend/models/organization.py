from datetime import datetime, timezone

from sqlalchemy import CheckConstraint

from extensions import db
from models.corporate_constants import ORG_ACTIVE, ORG_STATUSES


def _now():
    return datetime.now(timezone.utc)


class Organization(db.Model):
    __tablename__ = "organizations"
    __table_args__ = (
        CheckConstraint("status IN ('active', 'inactive')", name="ck_organizations_status"),
    )

    organization_id = db.Column(db.Integer, primary_key=True)
    organization_name = db.Column(db.String(150), nullable=False)
    organization_code = db.Column(db.String(16), nullable=False, unique=True, index=True)
    organization_email = db.Column(db.String(254), nullable=False)
    contact_phone = db.Column(db.String(30))
    address = db.Column(db.String(300))
    status = db.Column(db.String(20), nullable=False, default=ORG_ACTIVE)
    joining_enabled = db.Column(db.Boolean, nullable=False, default=True)
    # True only for records created by the demonstration-data generator.
    is_demo = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now)

    def to_dict(self, include_code=False):
        data = {
            "organization_id": self.organization_id,
            "organization_name": self.organization_name,
            "organization_email": self.organization_email,
            "contact_phone": self.contact_phone,
            "address": self.address,
            "status": self.status,
            "is_demo": bool(self.is_demo),
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_code:
            data["organization_code"] = self.organization_code
            data["joining_enabled"] = bool(self.joining_enabled)
        return data
