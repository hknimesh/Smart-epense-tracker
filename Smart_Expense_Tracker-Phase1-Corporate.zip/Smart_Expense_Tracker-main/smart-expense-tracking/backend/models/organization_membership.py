from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, Index, UniqueConstraint

from extensions import db
from models.corporate_constants import MEMBERSHIP_ACTIVE, ROLE_CHECK_SQL, ROLE_EMPLOYEE, ROLE_LABELS


def _now():
    return datetime.now(timezone.utc)


class OrganizationMembership(db.Model):
    """Links a user account to an organization. The corporate role lives here, never on the user."""

    __tablename__ = "organization_memberships"
    __table_args__ = (
        UniqueConstraint("organization_id", "user_id", name="uq_memberships_org_user"),
        CheckConstraint(ROLE_CHECK_SQL, name="ck_memberships_role"),
        CheckConstraint("membership_status IN ('active', 'inactive')", name="ck_memberships_status"),
        Index("ix_memberships_org_role", "organization_id", "role"),
    )

    membership_id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.organization_id", ondelete="RESTRICT"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.user_id", ondelete="CASCADE"), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey("departments.department_id", ondelete="SET NULL"), nullable=True, index=True)
    role = db.Column(db.String(30), nullable=False, default=ROLE_EMPLOYEE)
    membership_status = db.Column(db.String(20), nullable=False, default=MEMBERSHIP_ACTIVE)
    joined_at = db.Column(db.DateTime(timezone=True), nullable=False, default=_now)

    organization = db.relationship("Organization")
    user = db.relationship("User")
    department = db.relationship("Department")

    @property
    def is_active(self):
        return self.membership_status == MEMBERSHIP_ACTIVE

    def to_dict(self, include_code=False):
        return {
            "membership_id": self.membership_id,
            "organization_id": self.organization_id,
            "organization": self.organization.to_dict(include_code=include_code) if self.organization else None,
            "user_id": self.user_id,
            "user_name": self.user.name if self.user else None,
            "user_email": self.user.email if self.user else None,
            "department_id": self.department_id,
            "department_name": self.department.department_name if self.department else None,
            "role": self.role,
            "role_label": ROLE_LABELS.get(self.role, self.role),
            "membership_status": self.membership_status,
            "joined_at": self.joined_at.isoformat() if self.joined_at else None,
        }
