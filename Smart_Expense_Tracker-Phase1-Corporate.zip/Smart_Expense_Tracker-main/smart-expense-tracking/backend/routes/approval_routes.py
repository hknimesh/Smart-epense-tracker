from flask import Blueprint, g, jsonify, request

from models.corporate_constants import ROLE_FINANCE, ROLE_MANAGER
from services import approval_service
from services.corporate_errors import install_error_handler
from services.rbac import corporate_required

approval_bp = Blueprint("approvals", __name__)
install_error_handler(approval_bp)


@approval_bp.get("")
@corporate_required(ROLE_MANAGER, ROLE_FINANCE)
def queue():
    page = int(request.args["page"]) if request.args.get("page", "").isdigit() and int(request.args["page"]) > 0 else 1
    default_queue = "manager" if g.corp.role == ROLE_MANAGER else "verification"
    data = approval_service.approval_queue(g.corp, request.args.get("queue", default_queue), page, search=request.args.get("search"))
    return jsonify(success=True, data=data)


@approval_bp.post("/<int:expense_id>/<action>")
@corporate_required(ROLE_MANAGER, ROLE_FINANCE)
def review(expense_id, action):
    body = request.get_json(silent=True)
    comments = body.get("comments") if isinstance(body, dict) else None
    expense = approval_service.review_expense(g.corp, expense_id, action, comments)
    messages = {"approve": "Expense approved.", "reject": "Expense rejected.", "pay": "Expense marked as paid."}
    return jsonify(success=True, message=messages[action], data={"expense": expense.to_dict(include_history=True)})
