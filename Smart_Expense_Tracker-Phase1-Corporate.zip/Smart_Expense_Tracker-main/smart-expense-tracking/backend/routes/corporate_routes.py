"""Corporate expenses, receipts, role dashboards and reports."""
from flask import Blueprint, Response, g, jsonify, request, send_file

from extensions import db
from models.corporate_constants import (
    ROLE_EMPLOYEE, ROLE_EXECUTIVE, ROLE_FINANCE, ROLE_MANAGER,
)
from services import corporate_expense_service as expenses
from services import corporate_report_service as reports
from services.corporate_errors import ServiceError, install_error_handler
from services.rbac import corporate_required
from services.receipt_service import receipt_file, receipt_mime

corporate_bp = Blueprint("corporate", __name__)
install_error_handler(corporate_bp)

EXPENSE_VIEWERS = (ROLE_EMPLOYEE, ROLE_MANAGER, ROLE_FINANCE, ROLE_EXECUTIVE)
REPORT_VIEWERS = (ROLE_MANAGER, ROLE_FINANCE, ROLE_EXECUTIVE)


def _payload():
    """Accept JSON or multipart/form-data (for receipt uploads)."""
    if request.mimetype == "multipart/form-data":
        return request.form.to_dict(), request.files.get("receipt")
    body = request.get_json(silent=True)
    return (body if isinstance(body, dict) else {}), None


@corporate_bp.post("/expenses")
@corporate_required(ROLE_EMPLOYEE)
def create_expense():
    payload, receipt = _payload()
    expense = expenses.create_expense(g.corp, payload, receipt)
    return jsonify(success=True, message="Expense submitted for manager approval.", data={"expense": expense.to_dict(include_history=True)}), 201


@corporate_bp.get("/expenses")
@corporate_required(*EXPENSE_VIEWERS)
def list_expenses():
    return jsonify(success=True, data=expenses.list_expenses(g.corp, request.args))


@corporate_bp.get("/expenses/<int:expense_id>")
@corporate_required(*EXPENSE_VIEWERS)
def get_expense(expense_id):
    expense = expenses.get_scoped_expense(g.corp, expense_id)
    return jsonify(success=True, data={"expense": expense.to_dict(include_history=True)})


@corporate_bp.put("/expenses/<int:expense_id>")
@corporate_required(ROLE_EMPLOYEE)
def update_expense(expense_id):
    payload, _ = _payload()
    expense = expenses.update_own_expense(g.corp, expense_id, payload)
    return jsonify(success=True, message="Expense updated.", data={"expense": expense.to_dict(include_history=True)})


@corporate_bp.get("/expenses/<int:expense_id>/receipt")
@corporate_required(*EXPENSE_VIEWERS)
def download_receipt(expense_id):
    expense = expenses.get_scoped_expense(g.corp, expense_id)
    path = receipt_file(expense.receipt_path)
    if not path:
        raise ServiceError(404, "Receipt not found.")
    response = send_file(path, mimetype=receipt_mime(path), as_attachment=False, download_name=expense.receipt_filename or path.name)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'"
    return response


@corporate_bp.get("/dashboard/<role_name>")
@corporate_required(*EXPENSE_VIEWERS)
def role_dashboard(role_name):
    builders = {
        "employee": (ROLE_EMPLOYEE, reports.employee_dashboard),
        "manager": (ROLE_MANAGER, reports.manager_dashboard),
        "finance": (ROLE_FINANCE, reports.finance_dashboard),
        "executive": (ROLE_EXECUTIVE, reports.executive_dashboard),
    }
    entry = builders.get(role_name)
    if not entry:
        raise ServiceError(404, "Dashboard not found.")
    required_role, builder = entry
    if g.corp.role != required_role:
        raise ServiceError(403, "Your role does not permit this action.")
    return jsonify(success=True, data=builder(g.corp))


@corporate_bp.get("/reports/summary")
@corporate_required(*EXPENSE_VIEWERS)
def report_summary():
    return jsonify(success=True, data=reports.report_summary(g.corp, request.args))


@corporate_bp.get("/reports/export")
@corporate_required(*REPORT_VIEWERS)
def export_report():
    content = reports.export_csv(g.corp, request.args)
    return Response(content, mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=corporate-expenses.csv"})


@corporate_bp.get("/reports/transactions")
@corporate_required(ROLE_FINANCE, ROLE_EXECUTIVE)
def transactions():
    return jsonify(success=True, data={"transactions": reports.recent_transactions(g.corp, 50)})
