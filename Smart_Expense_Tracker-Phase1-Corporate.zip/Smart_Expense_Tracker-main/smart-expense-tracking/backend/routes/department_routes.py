from flask import Blueprint, g, jsonify, request
from sqlalchemy import func

from extensions import db
from models import Department, OrganizationMembership
from models.corporate_constants import (
    MEMBERSHIP_ACTIVE, ROLE_ADMIN, ROLE_EMPLOYEE, ROLE_EXECUTIVE, ROLE_FINANCE, ROLE_MANAGER,
)
from services import corporate_service as svc
from services.corporate_errors import install_error_handler
from services.rbac import corporate_required

department_bp = Blueprint("departments", __name__)
install_error_handler(department_bp)


def _json():
    payload = request.get_json(silent=True)
    return payload if isinstance(payload, dict) else {}


@department_bp.get("")
@corporate_required()
def list_departments():
    """Admin/finance/executive: all departments. Manager: managed ones. Employee: own department."""
    context = g.corp
    query = Department.query.filter_by(organization_id=context.organization_id)
    if context.role == ROLE_MANAGER:
        query = query.filter(Department.department_id.in_(svc.managed_department_ids(context) or [0]))
    elif context.role == ROLE_EMPLOYEE:
        query = query.filter(Department.department_id == (context.membership.department_id or 0))
    departments = query.order_by(Department.department_name).all()
    counts = dict(db.session.query(OrganizationMembership.department_id, func.count(OrganizationMembership.membership_id)).filter(
        OrganizationMembership.organization_id == context.organization_id,
        OrganizationMembership.membership_status == MEMBERSHIP_ACTIVE).group_by(OrganizationMembership.department_id).all())
    return jsonify(success=True, data={"departments": [{**d.to_dict(), "member_count": counts.get(d.department_id, 0)} for d in departments]})


@department_bp.post("")
@corporate_required(ROLE_ADMIN)
def create_department():
    department = svc.create_department(g.corp, _json())
    return jsonify(success=True, message="Department created.", data={"department": department.to_dict()}), 201


@department_bp.put("/<int:department_id>")
@corporate_required(ROLE_ADMIN)
def update_department(department_id):
    department = svc.update_department(g.corp, department_id, _json())
    return jsonify(success=True, message="Department updated.", data={"department": department.to_dict()})


@department_bp.get("/<int:department_id>/members")
@corporate_required(ROLE_ADMIN, ROLE_MANAGER)
def members(department_id):
    context = g.corp
    if context.role == ROLE_MANAGER and department_id not in svc.managed_department_ids(context):
        return jsonify(success=False, message="Department not found."), 404
    department, members_ = svc.department_members(context, department_id)
    return jsonify(success=True, data={"department": department.to_dict(), "members": [m.to_dict() for m in members_]})
