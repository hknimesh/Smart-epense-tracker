"""Corporate authentication, organization settings and member management."""
from flask import Blueprint, g, jsonify, request, session

from extensions import db
from models import User
from models.corporate_constants import CORPORATE_CATEGORIES, PAYMENT_METHODS, ROLE_ADMIN, ROLE_LABELS, STATUS_LABELS
from services import corporate_service as svc
from services.corporate_errors import ServiceError, install_error_handler
from services.rbac import corporate_required
from services import corporate_report_service as reports

organization_bp = Blueprint("organization", __name__)
install_error_handler(organization_bp)


def _json():
    payload = request.get_json(silent=True)
    return payload if isinstance(payload, dict) else {}


# ------------------------------------------------------------ public auth
@organization_bp.post("/organizations/register")
def register_organization():
    organization, user = svc.register_organization(_json())
    return jsonify(
        success=True,
        message="Organization registered. Sign in with Corporate Finance to open your dashboard.",
        data={"organization": organization.to_dict(include_code=True), "user": user.to_safe_dict()},
    ), 201


@organization_bp.post("/auth/join")
def join_organization():
    organization, user, membership = svc.join_organization(_json())
    return jsonify(
        success=True,
        message=f"You have joined {organization.organization_name}. Sign in with Corporate Finance to continue.",
        data={"membership": membership.to_dict()},
    ), 201


@organization_bp.post("/auth/login")
def corporate_login():
    user, membership, csrf = svc.corporate_login(_json())
    return jsonify(success=True, message="Signed in successfully.", data={
        "user": user.to_safe_dict(), "membership": membership.to_dict(include_code=membership.role == ROLE_ADMIN),
        "csrf_token": csrf, **{k: v for k, v in svc.session_payload(user).items() if k == "memberships"}, "mode": "corporate",
    })


# ------------------------------------------------------------ session
def _session_user():
    user = db.session.get(User, session.get("user_id")) if session.get("user_id") else None
    if not user:
        raise ServiceError(401, "Authentication required.")
    return user


@organization_bp.get("/session")
def get_session():
    return jsonify(success=True, data=svc.session_payload(_session_user()))


@organization_bp.post("/session/switch")
def switch_session():
    user = _session_user()
    svc.switch_mode(user, _json())
    return jsonify(success=True, data=svc.session_payload(user))


@organization_bp.get("/meta")
@corporate_required()
def meta():
    return jsonify(success=True, data={
        "categories": list(CORPORATE_CATEGORIES), "payment_methods": list(PAYMENT_METHODS),
        "statuses": [{"value": k, "label": v} for k, v in STATUS_LABELS.items()],
        "roles": [{"value": k, "label": v} for k, v in ROLE_LABELS.items()],
    })


# ------------------------------------------------------------ organization (admin)
@organization_bp.get("/organization")
@corporate_required()
def get_organization():
    context = g.corp
    return jsonify(success=True, data={"organization": context.organization.to_dict(include_code=context.role == ROLE_ADMIN)})


@organization_bp.put("/organization")
@corporate_required(ROLE_ADMIN)
def update_organization():
    org = svc.update_organization(g.corp, _json())
    return jsonify(success=True, message="Organization updated.", data={"organization": org.to_dict(include_code=True)})


@organization_bp.post("/organization/regenerate-code")
@corporate_required(ROLE_ADMIN)
def regenerate_code():
    org = svc.regenerate_code(g.corp)
    return jsonify(success=True, message="A new organization code was generated. The old code no longer works.", data={"organization": org.to_dict(include_code=True)})


@organization_bp.get("/dashboard/admin")
@corporate_required(ROLE_ADMIN)
def admin_dashboard():
    return jsonify(success=True, data=reports.admin_dashboard(g.corp))


# ------------------------------------------------------------ members (admin)
@organization_bp.get("/members")
@corporate_required(ROLE_ADMIN)
def list_members():
    members = svc.list_members(g.corp, request.args)
    return jsonify(success=True, data={"members": [m.to_dict() for m in members]})


@organization_bp.post("/members")
@corporate_required(ROLE_ADMIN)
def add_member():
    membership = svc.add_member(g.corp, _json())
    return jsonify(success=True, message="Member added. Share the temporary password securely and ask them to change it in Profile.", data={"member": membership.to_dict()}), 201


@organization_bp.put("/members/<int:membership_id>")
@corporate_required(ROLE_ADMIN)
def update_member(membership_id):
    membership = svc.update_member(g.corp, membership_id, _json())
    return jsonify(success=True, message="Member updated.", data={"member": membership.to_dict()})
