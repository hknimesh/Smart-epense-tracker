"""Approval workflow: Employee -> Manager -> Finance. All transitions are validated server-side."""
from datetime import datetime, timezone

from sqlalchemy import func, or_, update

from extensions import db
from models import CorporateExpense, ExpenseApproval, User
from models.corporate_constants import (
    ROLE_FINANCE, ROLE_MANAGER, STATUS_APPROVED, STATUS_PAID, STATUS_PENDING_FINANCE,
    STATUS_PENDING_MANAGER, STATUS_REJECTED,
)
from services.corporate_errors import ServiceError
from services.corporate_service import managed_department_ids

# (role, action, current status) -> new status
TRANSITIONS = {
    (ROLE_MANAGER, "approve", STATUS_PENDING_MANAGER): STATUS_PENDING_FINANCE,
    (ROLE_MANAGER, "reject", STATUS_PENDING_MANAGER): STATUS_REJECTED,
    (ROLE_FINANCE, "approve", STATUS_PENDING_FINANCE): STATUS_APPROVED,
    (ROLE_FINANCE, "reject", STATUS_PENDING_FINANCE): STATUS_REJECTED,
    (ROLE_FINANCE, "pay", STATUS_APPROVED): STATUS_PAID,
}
ACTIONS = {"approve", "reject", "pay"}
DEFAULT_COMMENTS = {
    (ROLE_MANAGER, "approve"): "Approved by manager.",
    (ROLE_FINANCE, "approve"): "Verified by finance.",
    (ROLE_FINANCE, "pay"): "Marked as paid.",
}


def _reviewable_expense(context, expense_id):
    query = CorporateExpense.query.filter_by(expense_id=expense_id, organization_id=context.organization_id)
    if context.role == ROLE_MANAGER:
        ids = managed_department_ids(context)
        query = query.filter(CorporateExpense.department_id.in_(ids)) if ids else query.filter(db.false())
    expense = query.first()
    if not expense:
        raise ServiceError(404, "Expense not found.")
    return expense


def review_expense(context, expense_id, action, comments=None):
    if action not in ACTIONS:
        raise ServiceError(400, "Unknown action.")
    if comments is not None and not isinstance(comments, str):
        raise ServiceError(400, "Comments must be text.")
    comments = (comments or "").strip()
    if len(comments) > 500:
        raise ServiceError(400, "Comments must be at most 500 characters.", {"comments": "Too long."})

    expense = _reviewable_expense(context, expense_id)
    if expense.user_id == context.user_id:
        raise ServiceError(403, "You cannot review your own expense.")
    previous = expense.approval_status
    new_status = TRANSITIONS.get((context.role, action, previous))
    if not new_status:
        raise ServiceError(409, f"This action is not allowed while the expense is '{previous}'.")
    if action == "reject" and len(comments) < 3:
        raise ServiceError(400, "A rejection reason is required.", {"comments": "Provide a rejection reason."})

    now = datetime.now(timezone.utc)
    values = {"approval_status": new_status, "updated_at": now}
    if new_status == STATUS_REJECTED:
        values["rejection_reason"] = comments
    if new_status == STATUS_PAID:
        values["paid_at"] = now
    # Conditional UPDATE makes the transition atomic: if two reviewers race, only one wins.
    result = db.session.execute(
        update(CorporateExpense)
        .where(CorporateExpense.expense_id == expense.expense_id, CorporateExpense.approval_status == previous)
        .values(**values)
    )
    if result.rowcount != 1:
        db.session.rollback()
        raise ServiceError(409, "This expense was just updated by someone else. Refresh and try again.")
    db.session.add(ExpenseApproval(
        expense_id=expense.expense_id, reviewer_id=context.user_id, previous_status=previous,
        new_status=new_status, comments=comments or DEFAULT_COMMENTS.get((context.role, action)), action_date=now,
    ))
    db.session.commit()
    db.session.refresh(expense)
    return expense


def approval_queue(context, queue, page=1, per_page=20, search=None):
    """Expenses awaiting this reviewer. manager: 'manager'; finance: 'verification' or 'payment'."""
    allowed = {ROLE_MANAGER: {"manager": STATUS_PENDING_MANAGER}, ROLE_FINANCE: {"verification": STATUS_PENDING_FINANCE, "payment": STATUS_APPROVED}}
    status = allowed.get(context.role, {}).get(queue)
    if not status:
        raise ServiceError(400, "Invalid queue for your role.")
    query = CorporateExpense.query.filter(
        CorporateExpense.organization_id == context.organization_id,
        CorporateExpense.approval_status == status,
        CorporateExpense.user_id != context.user_id,
    )
    if context.role == ROLE_MANAGER:
        ids = managed_department_ids(context)
        query = query.filter(CorporateExpense.department_id.in_(ids)) if ids else query.filter(db.false())
    search = (search or "").strip()
    if search:
        like = f"%{search.lower()[:100]}%"
        query = query.join(User, User.user_id == CorporateExpense.user_id).filter(or_(
            func.lower(CorporateExpense.title).like(like), func.lower(CorporateExpense.vendor).like(like), func.lower(User.name).like(like),
        ))
    query = query.order_by(CorporateExpense.expense_date.asc(), CorporateExpense.expense_id.asc())
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return {
        "expenses": [item.to_dict() for item in pagination.items],
        "pagination": {"page": pagination.page, "per_page": pagination.per_page, "total": pagination.total, "pages": pagination.pages},
    }
