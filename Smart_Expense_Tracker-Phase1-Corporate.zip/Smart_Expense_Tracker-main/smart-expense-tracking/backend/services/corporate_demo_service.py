"""Fictional demonstration data for the corporate module.

Safety properties:
* Everything belongs to ONE organization flagged `is_demo=True`.
* Demo users all use the reserved e-mail domain `@northwind-demo.example`.
* Nothing is ever attached to real/personal accounts; existing users are never modified.
* `seed_demo()` does nothing if the demo organization already exists (safe to re-run).
* `cleanup_demo()` removes only the demo organization's rows and demo-domain users that have
  no other memberships and no personal expense/income/budget data.
"""
import random
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal

from extensions import db
from models import (
    Budget, CorporateExpense, Department, Expense, ExpenseApproval, Income, Organization,
    OrganizationAuditLog, OrganizationMembership, User,
)
from models.corporate_constants import (
    ROLE_ADMIN, ROLE_EMPLOYEE, ROLE_EXECUTIVE, ROLE_FINANCE, ROLE_MANAGER, STATUS_APPROVED,
    STATUS_PAID, STATUS_PENDING_FINANCE, STATUS_PENDING_MANAGER, STATUS_REJECTED,
)

DEMO_DOMAIN = "northwind-demo.example"
DEMO_ORG_NAME = "Northwind Technologies (DEMO DATA)"
DEMO_ORG_CODE = "NWDDEMO26"
DEMO_PASSWORD = "Demo@12345"
EXPENSE_COUNT = 420
HISTORY_DAYS = 90

DEPARTMENTS = ["IT", "Human Resources", "Marketing", "Sales", "Operations"]
# (name, role, department or None)
PEOPLE = [
    ("Priya Nair", ROLE_ADMIN, None),
    ("Rohan Mehta", ROLE_EXECUTIVE, None),      # CEO
    ("Ananya Iyer", ROLE_EXECUTIVE, None),      # CFO
    ("Vikram Shah", ROLE_FINANCE, None),
    ("Meera Kulkarni", ROLE_FINANCE, None),
    ("Arjun Rao", ROLE_MANAGER, "IT"),
    ("Sneha Patil", ROLE_MANAGER, "Human Resources"),
    ("Karan Malhotra", ROLE_MANAGER, "Marketing"),
    ("Divya Menon", ROLE_MANAGER, "Sales"),
    ("Rahul Deshmukh", ROLE_MANAGER, "Operations"),
    ("Isha Kapoor", ROLE_EMPLOYEE, "IT"), ("Nikhil Joshi", ROLE_EMPLOYEE, "IT"),
    ("Pooja Bansal", ROLE_EMPLOYEE, "Human Resources"), ("Aditya Verma", ROLE_EMPLOYEE, "Human Resources"),
    ("Neha Gupta", ROLE_EMPLOYEE, "Marketing"), ("Siddharth Jain", ROLE_EMPLOYEE, "Marketing"),
    ("Kavya Reddy", ROLE_EMPLOYEE, "Sales"), ("Manish Tiwari", ROLE_EMPLOYEE, "Sales"),
    ("Tanvi Kulshreshtha", ROLE_EMPLOYEE, "Operations"), ("Harsh Vardhan", ROLE_EMPLOYEE, "Operations"),
]

# category -> (min, max, [(title, vendor)...])
CATALOG = {
    "Travel": (2500, 38000, [("Client visit flight", "IndiGo"), ("Train tickets for site visit", "IRCTC"), ("Airport cab", "Ola Corporate"), ("Conference travel", "Air India"), ("Local taxi for meetings", "Uber Business")]),
    "Food and accommodation": (800, 22000, [("Hotel stay during client visit", "Taj Hotels"), ("Team lunch", "Barbeque Nation"), ("Client dinner", "The Oberoi"), ("Business trip accommodation", "OYO Business"), ("Working lunch", "Haldiram's")]),
    "Office supplies": (300, 9000, [("Stationery restock", "Staples"), ("Printer cartridges", "HP Store"), ("Whiteboard markers and files", "Amazon Business"), ("Pantry supplies", "BigBasket")]),
    "Software subscriptions": (1500, 60000, [("Design tool licenses", "Figma"), ("Cloud hosting invoice", "AWS"), ("Project management seats", "Atlassian"), ("Team chat subscription", "Slack"), ("Antivirus renewal", "Quick Heal")]),
    "Internet and communication": (500, 12000, [("Broadband bill", "Airtel Business"), ("Mobile postpaid plan", "Jio"), ("Conference calling plan", "Zoom")]),
    "Equipment": (4000, 90000, [("Laptop accessories", "Croma"), ("Monitor purchase", "Dell"), ("Ergonomic chairs", "Featherlite"), ("Wireless headsets", "Sony")]),
    "Employee reimbursements": (400, 15000, [("Training course fee", "Udemy Business"), ("Certification exam fee", "Pearson VUE"), ("Medical checkup reimbursement", "Apollo Clinic"), ("Remote work internet allowance", "ACT Fibernet")]),
}
WEIGHTS = {"Travel": 20, "Food and accommodation": 22, "Office supplies": 14, "Software subscriptions": 12, "Internet and communication": 8, "Equipment": 8, "Employee reimbursements": 16}
PAYMENT = ["Corporate Card", "Personal Card", "Cash", "Bank Transfer", "UPI"]


def _email(name):
    return f"{name.lower().replace(' ', '.')}@{DEMO_DOMAIN}"


def _status_for(rng, age_days):
    roll = rng.random()
    if age_days > 45:
        table = [(STATUS_PAID, .70), (STATUS_APPROVED, .12), (STATUS_REJECTED, .13), (STATUS_PENDING_FINANCE, .05)]
    elif age_days > 15:
        table = [(STATUS_PAID, .40), (STATUS_APPROVED, .20), (STATUS_REJECTED, .12), (STATUS_PENDING_FINANCE, .13), (STATUS_PENDING_MANAGER, .15)]
    else:
        table = [(STATUS_PAID, .08), (STATUS_APPROVED, .05), (STATUS_REJECTED, .07), (STATUS_PENDING_FINANCE, .20), (STATUS_PENDING_MANAGER, .60)]
    cumulative = 0
    for status, share in table:
        cumulative += share
        if roll <= cumulative:
            return status
    return table[-1][0]


def seed_demo():
    """Create the demo organization. Returns a summary dict, or None if it already exists."""
    existing = Organization.query.filter_by(organization_code=DEMO_ORG_CODE).first()
    if existing:
        return None
    rng = random.Random(2026)
    now = datetime.now(timezone.utc)
    today = date.today()

    org = Organization(
        organization_name=DEMO_ORG_NAME, organization_code=DEMO_ORG_CODE,
        organization_email=f"info@{DEMO_DOMAIN}", contact_phone="+91 20 5550 0100",
        address="Fictional demonstration data - not a real company", joining_enabled=False, is_demo=True,
    )
    db.session.add(org)
    db.session.flush()
    departments = {}
    for name in DEPARTMENTS:
        departments[name] = Department(organization_id=org.organization_id, department_name=name)
        db.session.add(departments[name])
    db.session.flush()

    users, members = {}, []
    created_users = 0
    for name, role, dept in PEOPLE:
        email = _email(name)
        user = User.query.filter_by(email=email).first()
        if not user:
            user = User(name=name, email=email)
            user.set_password(DEMO_PASSWORD)
            db.session.add(user)
            created_users += 1
        users[name] = user
    db.session.flush()
    for name, role, dept in PEOPLE:
        member = OrganizationMembership(
            organization_id=org.organization_id, user_id=users[name].user_id, role=role,
            department_id=departments[dept].department_id if dept else None,
        )
        members.append((name, role, dept, member))
        db.session.add(member)
        if role == ROLE_MANAGER:
            departments[dept].manager_id = users[name].user_id

    managers = {dept: users[name] for name, role, dept in PEOPLE if role == ROLE_MANAGER}
    finance = [users[name] for name, role, _ in PEOPLE if role == ROLE_FINANCE]
    employees = [(users[name], dept) for name, role, dept in PEOPLE if role == ROLE_EMPLOYEE]
    admin = users["Priya Nair"]
    db.session.add(OrganizationAuditLog(organization_id=org.organization_id, actor_id=admin.user_id, action="demo_data_created", details="Demonstration organization generated (fictional data)."))

    categories, weights = list(WEIGHTS), list(WEIGHTS.values())
    expense_count = 0
    for _ in range(EXPENSE_COUNT):
        employee, dept = rng.choice(employees)
        category = rng.choices(categories, weights)[0]
        low, high, titles = CATALOG[category]
        title, vendor = rng.choice(titles)
        amount = Decimal(rng.randint(low, high)).quantize(Decimal("1")) + Decimal(rng.choice([0, 0, 0.25, 0.5, 0.75])).quantize(Decimal("0.01"))
        spent_on = today - timedelta(days=rng.randint(0, HISTORY_DAYS))
        age = (today - spent_on).days
        status = _status_for(rng, age)
        submitted = min(datetime.combine(spent_on, time(rng.randint(9, 20), rng.randint(0, 59)), tzinfo=timezone.utc) + timedelta(days=rng.randint(0, 2)), now - timedelta(minutes=5))
        expense = CorporateExpense(
            organization_id=org.organization_id, user_id=employee.user_id,
            department_id=departments[dept].department_id, title=f"{title} (demo)", description=f"Fictional demonstration expense: {title.lower()}.",
            amount=amount, category=category, vendor=vendor, payment_method=rng.choice(PAYMENT),
            expense_date=spent_on, approval_status=status, created_at=submitted, updated_at=submitted,
        )
        db.session.add(expense)
        db.session.flush()
        steps = [(employee, None, STATUS_PENDING_MANAGER, "Expense submitted.", submitted)]
        manager, officer = managers[dept], rng.choice(finance)
        t1 = min(submitted + timedelta(hours=rng.randint(4, 60)), now - timedelta(minutes=3))
        t2 = min(t1 + timedelta(hours=rng.randint(6, 72)), now - timedelta(minutes=2))
        t3 = min(t2 + timedelta(hours=rng.randint(12, 120)), now - timedelta(minutes=1))
        if status != STATUS_PENDING_MANAGER:
            rejected_by_manager = status == STATUS_REJECTED and rng.random() < 0.65
            if rejected_by_manager:
                steps.append((manager, STATUS_PENDING_MANAGER, STATUS_REJECTED, rng.choice(["Missing business justification.", "Exceeds department policy.", "Duplicate of an earlier claim."]), t1))
            else:
                steps.append((manager, STATUS_PENDING_MANAGER, STATUS_PENDING_FINANCE, "Approved by manager.", t1))
                if status == STATUS_REJECTED:
                    steps.append((officer, STATUS_PENDING_FINANCE, STATUS_REJECTED, rng.choice(["Receipt required for reimbursement.", "Amount does not match vendor invoice."]), t2))
                elif status in (STATUS_APPROVED, STATUS_PAID):
                    steps.append((officer, STATUS_PENDING_FINANCE, STATUS_APPROVED, "Verified by finance.", t2))
                    if status == STATUS_PAID:
                        steps.append((officer, STATUS_APPROVED, STATUS_PAID, "Marked as paid.", t3))
        for reviewer, previous, new, comment, when in steps:
            db.session.add(ExpenseApproval(expense_id=expense.expense_id, reviewer_id=reviewer.user_id, previous_status=previous, new_status=new, comments=comment, action_date=when))
        last = steps[-1][4]
        expense.updated_at = last
        if status == STATUS_REJECTED:
            expense.rejection_reason = steps[-1][3]
        if status == STATUS_PAID:
            expense.paid_at = last
        expense_count += 1
    db.session.commit()
    return {"organization": DEMO_ORG_NAME, "code": DEMO_ORG_CODE, "users": created_users, "expenses": expense_count}


def cleanup_demo():
    """Delete only the demo organization's data and orphaned demo-domain users."""
    org = Organization.query.filter_by(organization_code=DEMO_ORG_CODE).first()
    counts = {"expenses": 0, "approvals": 0, "members": 0, "departments": 0, "users": 0}
    if org and not org.is_demo:
        raise RuntimeError("Refusing to delete: organization with the demo code is not flagged as demo data.")
    user_ids = []
    if org:
        org_id = org.organization_id
        expense_ids = [row[0] for row in db.session.query(CorporateExpense.expense_id).filter_by(organization_id=org_id)]
        if expense_ids:
            counts["approvals"] = ExpenseApproval.query.filter(ExpenseApproval.expense_id.in_(expense_ids)).delete(synchronize_session=False)
        counts["expenses"] = CorporateExpense.query.filter_by(organization_id=org_id).delete(synchronize_session=False)
        OrganizationAuditLog.query.filter_by(organization_id=org_id).delete(synchronize_session=False)
        Department.query.filter_by(organization_id=org_id).update({"manager_id": None})
        user_ids = [m.user_id for m in OrganizationMembership.query.filter_by(organization_id=org_id)]
        OrganizationMembership.query.filter_by(organization_id=org_id).update({"department_id": None})
        counts["members"] = OrganizationMembership.query.filter_by(organization_id=org_id).delete(synchronize_session=False)
        counts["departments"] = Department.query.filter_by(organization_id=org_id).delete(synchronize_session=False)
        db.session.delete(org)
        db.session.flush()
    # Remove demo-domain users that are now unused. Real accounts never match the reserved domain.
    for user in User.query.filter(User.email.like(f"%@{DEMO_DOMAIN}")).all():
        has_membership = OrganizationMembership.query.filter_by(user_id=user.user_id).first()
        has_personal = (Expense.query.filter_by(user_id=user.user_id).first() or Income.query.filter_by(user_id=user.user_id).first()
                        or Budget.query.filter_by(user_id=user.user_id).first())
        if not has_membership and not has_personal:
            db.session.delete(user)
            counts["users"] += 1
    db.session.commit()
    return counts
