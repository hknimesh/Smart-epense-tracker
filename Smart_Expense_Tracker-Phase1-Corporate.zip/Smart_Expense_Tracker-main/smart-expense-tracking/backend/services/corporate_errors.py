class ServiceError(Exception):
    """Raised by corporate services; routes convert it to a JSON error response."""

    def __init__(self, status, message, errors=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.errors = errors


def install_error_handler(blueprint):
    """Make a blueprint turn ServiceError into a JSON response (rolling back the session)."""
    from flask import jsonify
    from extensions import db

    @blueprint.errorhandler(ServiceError)
    def _handle(error):
        db.session.rollback()
        body = {"success": False, "message": error.message}
        if error.errors:
            body["errors"] = error.errors
        return jsonify(body), error.status
