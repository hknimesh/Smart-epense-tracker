"""Corporate expense validation, role-based scoping, filtering and listing."""
from datetime import date
from decimal import Decimal, InvalidOperation

from sqlalchemy import func, or_
from sqlalchemy.orm import joinedload

from extensions import db
from models import CorporateExpense, Department, ExpenseApproval, OrganizationMembership
from models.corporate_constants import (
    CORPORATE_CATEGORIES, DEPT_ACTIVE, EXPENSE_STATUSES, PAYMENT_METHODS, ROLE_EMPLOYEE,
    ROLE_EXECUTIVE, ROLE_FINANCE, ROLE_MANAGER, STATUS_PENDING_MANAGER,
)
from services.corporate_errors import ServiceError
from services.corporate_service import managed_department_ids

CENT = Decimal("0.01")
MAX_AMOUNT = Decimal("9999999999.99")


def parse_date(value, field):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ServiceError(400, "Invalid date.", {field: "Use the YYYY-MM-DD format."})


def validate_expense_payload(payload, membership, partial=False):
    """Return cleaned column values. organization/user/department/status never come from the client."""
    if not isinstance(payload, dict):
        raise ServiceError(400, "Expense data is required.")
    errors, values = {}, {}

    def present(key):
        return (not partial) or key in payload

    if present("title"):
        title = payload.get("title")
        if not isinstance(title, str) or not 3 <= len(title.strip()) <= 200:
            errors["title"] = "Title must be between 3 and 200 characters."
        else:
            values["title"] = title.strip()
    if "description" in payload or not partial:
        description = payload.get("description")
        if description in (None, ""):
            values["description"] = None
        elif not isinstance(description, str) or len(description.strip()) > 1000:
            errors["description"] = "Description must be at most 1000 characters."
        else:
            values["description"] = description.strip()
    if present("amount"):
        raw = payload.get("amount")
        try:
            if isinstance(raw, bool) or raw in (None, ""):
                raise InvalidOperation
            amount = Decimal(str(raw).strip())
            if not amount.is_finite() or amount <= 0 or amount > MAX_AMOUNT or amount != amount.quantize(CENT):
                raise InvalidOperation
            values["amount"] = amount.quantize(CENT)
        except InvalidOperation:
            errors["amount"] = "Amount must be greater than 0 with at most 2 decimal places."
    if present("expense_date"):
        try:
            parsed = date.fromisoformat(payload.get("expense_date"))
            if parsed > date.today():
                errors["expense_date"] = "Expense date cannot be in the future."
            else:
                values["expense_date"] = parsed
        except (TypeError, ValueError):
            errors["expense_date"] = "Use the YYYY-MM-DD format."
    if present("category"):
        if payload.get("category") not in CORPORATE_CATEGORIES:
            errors["category"] = "Choose a valid category."
        else:
            values["category"] = payload["category"]
    for field, limit in (("vendor", 160),):
        if field in payload or not partial:
            value = payload.get(field)
            if value in (None, ""):
                values[field] = None
            elif not isinstance(value, str) or len(value.strip()) > limit:
                errors[field] = f"Vendor must be at most {limit} characters."
            else:
                values[field] = value.strip()
    if "payment_method" in payload or not partial:
        method = payload.get("payment_method")
        if method in (None, ""):
            values["payment_method"] = None
        elif method not in PAYMENT_METHODS:
            errors["payment_method"] = "Choose a valid payment method."
        else:
            values["payment_method"] = method
    # A client-supplied department is only accepted if it is the employee's own department.
    supplied_department = payload.get("department_id")
    if supplied_department not in (None, "") and str(supplied_department) != str(membership.department_id):
        errors["department_id"] = "Expenses are submitted under your own department."
    if errors:
        raise ServiceError(400, "Please correct the expense fields.", errors)
    return values


def create_expense(context, payload, receipt=None):
    membership = context.membership
    if not membership.department_id:
        raise ServiceError(400, "You are not assigned to a department yet. Ask your administrator to assign one.")
    department = db.session.get(Department, membership.department_id)
    if not department or department.organization_id != context.organization_id or department.status != DEPT_ACTIVE:
        raise ServiceError(400, "Your department is not active. Contact your administrator.")
    values = validate_expense_payload(payload, membership)
    receipt_path = receipt_name = None
    if receipt is not None:
        from services.receipt_service import save_receipt
        receipt_path, receipt_name = save_receipt(receipt, context.organization_id)
    expense = CorporateExpense(
        organization_id=context.organization_id, user_id=context.user_id,
        department_id=department.department_id, approval_status=STATUS_PENDING_MANAGER,
        receipt_path=receipt_path, receipt_filename=receipt_name, **values,
    )
    db.session.add(expense)
    db.session.flush()
    db.session.add(ExpenseApproval(
        expense_id=expense.expense_id, reviewer_id=context.user_id, previous_status=None,
        new_status=STATUS_PENDING_MANAGER, comments="Expense submitted.",
    ))
    db.session.commit()
    return expense


def scoped_query(context):
    """Base query containing ONLY the expenses this role may see.

    employee -> own; manager -> departments they manage; finance/executive -> whole organization.
    Anyone else (e.g. org admin) sees nothing here; routes also forbid them outright.
    """
    query = CorporateExpense.query.filter(CorporateExpense.organization_id == context.organization_id)
    role = context.role
    if role == ROLE_EMPLOYEE:
        return query.filter(CorporateExpense.user_id == context.user_id)
    if role == ROLE_MANAGER:
        ids = managed_department_ids(context)
        return query.filter(CorporateExpense.department_id.in_(ids)) if ids else query.filter(db.false())
    if role in (ROLE_FINANCE, ROLE_EXECUTIVE):
        return query
    return query.filter(db.false())


def get_scoped_expense(context, expense_id):
    expense = scoped_query(context).filter(CorporateExpense.expense_id == expense_id).first()
    if not expense:
        raise ServiceError(404, "Expense not found.")
    return expense


def apply_filters(query, args):
    errors = {}
    status = args.get("status")
    if status:
        statuses = [s for s in status.split(",") if s]
        if any(s not in EXPENSE_STATUSES for s in statuses):
            errors["status"] = "Invalid status."
        else:
            query = query.filter(CorporateExpense.approval_status.in_(statuses))
    for key in ("department_id", "user_id"):
        if args.get(key):
            if not args[key].isdigit():
                errors[key] = "Must be a number."
            else:
                column = CorporateExpense.department_id if key == "department_id" else CorporateExpense.user_id
                query = query.filter(column == int(args[key]))
    if args.get("category"):
        if args["category"] not in CORPORATE_CATEGORIES:
            errors["category"] = "Invalid category."
        else:
            query = query.filter(CorporateExpense.category == args["category"])
    start = end = None
    try:
        if args.get("start_date"):
            start = parse_date(args["start_date"], "start_date")
            query = query.filter(CorporateExpense.expense_date >= start)
        if args.get("end_date"):
            end = parse_date(args["end_date"], "end_date")
            query = query.filter(CorporateExpense.expense_date <= end)
    except ServiceError as error:
        errors.update(error.errors)
    if start and end and start > end:
        errors["end_date"] = "End date must not be before the start date."
    search = (args.get("search") or "").strip()
    if search:
        like = f"%{search.lower()}%"
        query = query.filter(or_(func.lower(CorporateExpense.title).like(like), func.lower(CorporateExpense.vendor).like(like)))
    if errors:
        raise ServiceError(400, "Invalid filters.", errors)
    return query


def list_expenses(context, args):
    query = apply_filters(scoped_query(context), args)
    total_amount = query.with_entities(func.coalesce(func.sum(CorporateExpense.amount), 0)).scalar()
    sorts = {
        "newest": (CorporateExpense.expense_date.desc(), CorporateExpense.expense_id.desc()),
        "oldest": (CorporateExpense.expense_date.asc(), CorporateExpense.expense_id.asc()),
        "amount_desc": (CorporateExpense.amount.desc(),),
        "amount_asc": (CorporateExpense.amount.asc(),),
    }
    query = query.options(joinedload(CorporateExpense.submitter), joinedload(CorporateExpense.department))
    query = query.order_by(*sorts.get(args.get("sort"), sorts["newest"]))
    page = int(args["page"]) if args.get("page", "").isdigit() and int(args["page"]) > 0 else 1
    per_page = min(int(args["per_page"]), 100) if args.get("per_page", "").isdigit() and int(args["per_page"]) > 0 else 20
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return {
        "expenses": [item.to_dict() for item in pagination.items],
        "total_amount": format(Decimal(str(total_amount)).quantize(CENT), ".2f"),
        "pagination": {"page": pagination.page, "per_page": pagination.per_page, "total": pagination.total, "pages": pagination.pages},
    }


def update_own_expense(context, expense_id, payload):
    expense = CorporateExpense.query.filter_by(
        expense_id=expense_id, organization_id=context.organization_id, user_id=context.user_id
    ).first()
    if not expense:
        raise ServiceError(404, "Expense not found.")
    if expense.approval_status != STATUS_PENDING_MANAGER:
        raise ServiceError(409, "Only expenses still pending manager approval can be edited.")
    values = validate_expense_payload(payload, context.membership, partial=True)
    for field, value in values.items():
        setattr(expense, field, value)
    db.session.commit()
    return expense
