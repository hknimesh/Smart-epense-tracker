"""Dashboards and basic reports for corporate expenses. All figures are computed from the database."""
import csv
import io
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func
from sqlalchemy.orm import joinedload

from extensions import db
from models import CorporateExpense, Department, ExpenseApproval, OrganizationAuditLog, OrganizationMembership, User
from models.corporate_constants import (
    DEPT_ACTIVE, EXPENDITURE_STATUSES, EXPENSE_STATUSES, MEMBERSHIP_ACTIVE, ROLE_EMPLOYEE,
    ROLE_MANAGER, ROLES, STATUS_APPROVED, STATUS_LABELS, STATUS_PAID, STATUS_PENDING_FINANCE,
    STATUS_PENDING_MANAGER, STATUS_REJECTED,
)
from services.corporate_expense_service import apply_filters, scoped_query
from services.corporate_service import managed_department_ids

CENT = Decimal("0.01")


def _money(value):
    return format(Decimal(str(value or 0)).quantize(CENT), ".2f")


def _metrics(status_map):
    """status_map: {status: (count, Decimal amount)} -> flat metrics dict with string amounts."""
    def count(*statuses):
        return sum(status_map.get(s, (0, Decimal(0)))[0] for s in statuses)

    def amount(*statuses):
        return sum((status_map.get(s, (0, Decimal(0)))[1] for s in statuses), Decimal(0))

    return {
        "submitted_count": count(*EXPENSE_STATUSES), "submitted_amount": _money(amount(*EXPENSE_STATUSES)),
        "pending_manager_count": count(STATUS_PENDING_MANAGER), "pending_manager_amount": _money(amount(STATUS_PENDING_MANAGER)),
        "pending_finance_count": count(STATUS_PENDING_FINANCE), "pending_finance_amount": _money(amount(STATUS_PENDING_FINANCE)),
        "pending_count": count(STATUS_PENDING_MANAGER, STATUS_PENDING_FINANCE),
        "pending_amount": _money(amount(STATUS_PENDING_MANAGER, STATUS_PENDING_FINANCE)),
        "rejected_count": count(STATUS_REJECTED), "rejected_amount": _money(amount(STATUS_REJECTED)),
        # approved = finance-verified, awaiting payment (i.e. reimbursement pending)
        "approved_count": count(STATUS_APPROVED), "approved_amount": _money(amount(STATUS_APPROVED)),
        "paid_count": count(STATUS_PAID), "paid_amount": _money(amount(STATUS_PAID)),
        # expenditure = approved + paid (verified by finance)
        "expenditure_count": count(*EXPENDITURE_STATUSES), "expenditure_amount": _money(amount(*EXPENDITURE_STATUSES)),
    }


def _grouped(query, *columns):
    rows = query.with_entities(*columns, CorporateExpense.approval_status, func.count(CorporateExpense.expense_id), func.sum(CorporateExpense.amount)).group_by(*columns, CorporateExpense.approval_status).all()
    grouped = {}
    for row in rows:
        *keys, status, count, total = row
        key = tuple(keys) if len(keys) > 1 else keys[0] if keys else None
        grouped.setdefault(key, {})[status] = (int(count), Decimal(str(total or 0)))
    return grouped


def overall(query):
    return _metrics(_grouped(query).get(None, {}))


def by_department(query):
    grouped = _grouped(query, CorporateExpense.department_id)
    names = {d.department_id: d.department_name for d in Department.query.filter(Department.department_id.in_(list(grouped) or [0])).all()}
    result = [{"department_id": key, "department_name": names.get(key, "Unknown"), **_metrics(value)} for key, value in grouped.items()]
    return sorted(result, key=lambda row: Decimal(row["expenditure_amount"]), reverse=True)


def by_category(query):
    grouped = _grouped(query, CorporateExpense.category)
    result = [{"category": key, **_metrics(value)} for key, value in grouped.items()]
    return sorted(result, key=lambda row: Decimal(row["submitted_amount"]), reverse=True)


def by_employee(query):
    grouped = _grouped(query, CorporateExpense.user_id)
    names = {u.user_id: u.name for u in User.query.filter(User.user_id.in_(list(grouped) or [0])).all()}
    result = [{"user_id": key, "employee_name": names.get(key, "Unknown"), **_metrics(value)} for key, value in grouped.items()]
    return sorted(result, key=lambda row: Decimal(row["submitted_amount"]), reverse=True)


def monthly(query, months=6):
    today = date.today()
    index = today.year * 12 + today.month - 1 - (months - 1)
    start = date(index // 12, index % 12 + 1, 1)
    year = func.extract("year", CorporateExpense.expense_date)
    month = func.extract("month", CorporateExpense.expense_date)
    rows = query.filter(CorporateExpense.expense_date >= start).with_entities(
        year, month, CorporateExpense.approval_status, func.count(CorporateExpense.expense_id), func.sum(CorporateExpense.amount)
    ).group_by(year, month, CorporateExpense.approval_status).all()
    buckets = {}
    for y, m, status, count, total in rows:
        buckets.setdefault((int(y), int(m)), {})[status] = (int(count), Decimal(str(total or 0)))
    series = []
    for offset in range(months):
        idx = index + offset
        key = (idx // 12, idx % 12 + 1)
        metrics = _metrics(buckets.get(key, {}))
        series.append({"year": key[0], "month": key[1], "label": date(key[0], key[1], 1).strftime("%b %Y"),
                       "submitted_amount": metrics["submitted_amount"], "expenditure_amount": metrics["expenditure_amount"],
                       "submitted_count": metrics["submitted_count"]})
    return series


def _recent(query, limit=5):
    items = query.options(joinedload(CorporateExpense.submitter), joinedload(CorporateExpense.department)).order_by(CorporateExpense.created_at.desc(), CorporateExpense.expense_id.desc()).limit(limit).all()
    return [item.to_dict() for item in items]


def recent_transactions(context, limit=8):
    rows = (
        ExpenseApproval.query.join(CorporateExpense, ExpenseApproval.expense_id == CorporateExpense.expense_id)
        .filter(CorporateExpense.organization_id == context.organization_id, ExpenseApproval.new_status.in_((STATUS_APPROVED, STATUS_PAID)))
        .options(joinedload(ExpenseApproval.reviewer), joinedload(ExpenseApproval.expense).joinedload(CorporateExpense.submitter))
        .order_by(ExpenseApproval.action_date.desc(), ExpenseApproval.approval_id.desc()).limit(limit).all()
    )
    return [{
        **row.to_dict(), "title": row.expense.title, "amount": format(row.expense.amount, ".2f"),
        "employee_name": row.expense.submitter.name if row.expense.submitter else None,
    } for row in rows]


# ---------------------------------------------------------------- dashboards
def employee_dashboard(context):
    query = scoped_query(context)
    return {"summary": overall(query), "recent": _recent(query, 5), "monthly": monthly(query)}


def manager_dashboard(context):
    query = scoped_query(context)
    ids = managed_department_ids(context)
    departments = Department.query.filter(Department.department_id.in_(ids or [0])).order_by(Department.department_name).all()
    per_dept = {row["department_id"]: row for row in by_department(query)}
    start_of_month = date.today().replace(day=1)
    month_query = query.filter(CorporateExpense.expense_date >= start_of_month)
    pending_query = query.filter(CorporateExpense.approval_status == STATUS_PENDING_MANAGER)
    stale_cutoff = datetime.now(timezone.utc) - timedelta(days=3)
    stale = pending_query.filter(CorporateExpense.created_at < stale_cutoff).count()
    alerts = []
    pending_total = pending_query.count()
    if pending_total:
        alerts.append({"level": "info", "message": f"{pending_total} expense(s) are waiting for your approval."})
    if stale:
        alerts.append({"level": "warning", "message": f"{stale} pending expense(s) have been waiting more than 3 days."})
    return {
        "departments": [{**per_dept.get(d.department_id, _metrics({})), "department_id": d.department_id, "department_name": d.department_name} for d in departments],
        "summary": overall(query), "this_month": overall(month_query), "monthly": monthly(query),
        "pending_approvals": _recent(pending_query.order_by(None), 8) if pending_total else [],
        "recent_submissions": _recent(query, 6), "alerts": alerts, "by_employee": by_employee(query)[:10],
    }


def finance_dashboard(context):
    query = scoped_query(context)
    return {
        "summary": overall(query), "by_department": by_department(query), "monthly": monthly(query),
        "recent_transactions": recent_transactions(context), "recent": _recent(query, 6),
    }


def executive_dashboard(context):
    query = scoped_query(context)
    return {
        "summary": overall(query), "by_department": by_department(query), "monthly": monthly(query, 6),
        "by_category": by_category(query), "recent_activity": recent_transactions(context, 10),
    }


def admin_dashboard(context):
    org_id = context.organization_id
    memberships = OrganizationMembership.query.filter_by(organization_id=org_id).all()
    role_counts = {role: 0 for role in ROLES}
    for m in memberships:
        if m.membership_status == MEMBERSHIP_ACTIVE:
            role_counts[m.role] += 1
    departments = Department.query.filter_by(organization_id=org_id).order_by(Department.department_name).all()
    member_counts = dict(db.session.query(OrganizationMembership.department_id, func.count(OrganizationMembership.membership_id)).filter(
        OrganizationMembership.organization_id == org_id, OrganizationMembership.membership_status == MEMBERSHIP_ACTIVE).group_by(OrganizationMembership.department_id).all())
    logs = OrganizationAuditLog.query.filter_by(organization_id=org_id).options(joinedload(OrganizationAuditLog.actor)).order_by(OrganizationAuditLog.created_at.desc(), OrganizationAuditLog.log_id.desc()).limit(10).all()
    return {
        "organization": context.organization.to_dict(include_code=True),
        "counts": {
            "total_members": len(memberships),
            "active_memberships": sum(1 for m in memberships if m.membership_status == MEMBERSHIP_ACTIVE),
            "total_employees": sum(1 for m in memberships if m.role == ROLE_EMPLOYEE),
            "total_departments": len(departments),
            "active_departments": sum(1 for d in departments if d.status == DEPT_ACTIVE),
            "by_role": role_counts,
        },
        "departments": [{**d.to_dict(), "member_count": member_counts.get(d.department_id, 0)} for d in departments],
        "recent_activity": [log.to_dict() for log in logs],
    }


# ---------------------------------------------------------------- reports
def report_summary(context, args):
    query = apply_filters(scoped_query(context), args)
    data = {
        "summary": overall(query), "by_department": by_department(query), "by_category": by_category(query),
        "monthly": monthly(query, 6),
    }
    if context.role != ROLE_EMPLOYEE:
        data["by_employee"] = by_employee(query)
    return data


def _safe_cell(value):
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def export_csv(context, args):
    query = apply_filters(scoped_query(context), args).options(joinedload(CorporateExpense.submitter), joinedload(CorporateExpense.department)).order_by(CorporateExpense.expense_date.desc(), CorporateExpense.expense_id.desc())
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["Expense ID", "Date", "Employee", "Department", "Title", "Category", "Vendor", "Payment method", "Amount", "Status", "Rejection reason"])
    for e in query.all():
        writer.writerow([e.expense_id, e.expense_date.isoformat(), _safe_cell(e.submitter.name), _safe_cell(e.department.department_name), _safe_cell(e.title),
                         e.category, _safe_cell(e.vendor), e.payment_method or "", format(e.amount, ".2f"), STATUS_LABELS[e.approval_status], _safe_cell(e.rejection_reason)])
    return buffer.getvalue()
