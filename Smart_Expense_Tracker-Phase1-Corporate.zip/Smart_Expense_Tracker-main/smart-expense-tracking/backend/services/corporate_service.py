"""Organization, membership, department and corporate-session logic."""
import re
import secrets

from flask import request, session
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError

from extensions import db
from models import Department, Organization, OrganizationAuditLog, OrganizationMembership, User
from models.corporate_constants import (
    DEFAULT_DEPARTMENTS, DEPT_ACTIVE, DEPT_STATUSES, MEMBERSHIP_ACTIVE, MEMBERSHIP_INACTIVE,
    MEMBERSHIP_STATUSES, ORG_ACTIVE, ROLE_ADMIN, ROLE_EMPLOYEE, ROLE_LABELS, ROLE_MANAGER, ROLES,
)
from services import rate_limit
from services.auth_service import validate_email
from services.corporate_errors import ServiceError

CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O/1/I to avoid transcription mistakes
CODE_RANDOM_LENGTH = 6
PHONE_PATTERN = re.compile(r"^[+()\d .-]{7,30}$")


# ---------------------------------------------------------------- helpers
def _text(value, label, max_len, required=True, errors=None, key=None):
    key = key or label
    if value is None or (isinstance(value, str) and not value.strip()):
        if required:
            errors[key] = f"{label.replace('_', ' ').capitalize()} is required."
        return None
    if not isinstance(value, str):
        errors[key] = f"{label.replace('_', ' ').capitalize()} must be text."
        return None
    value = value.strip()
    if len(value) > max_len:
        errors[key] = f"{label.replace('_', ' ').capitalize()} must be at most {max_len} characters."
        return None
    return value


def _email(value, key, errors):
    value = value.strip().lower() if isinstance(value, str) else ""
    if not validate_email(value):
        errors[key] = "Enter a valid email address."
        return None
    return value


def _password(value, errors, key="password"):
    if not isinstance(value, str) or not 8 <= len(value) <= 128:
        errors[key] = "Password must be between 8 and 128 characters."
        return None
    return value


def _client_key():
    return f"ip:{request.remote_addr}"


def log_action(organization_id, actor_id, action, details=None):
    db.session.add(OrganizationAuditLog(
        organization_id=organization_id, actor_id=actor_id, action=action,
        details=(details or "")[:500] or None,
    ))


def normalize_code(raw):
    return re.sub(r"[\s-]", "", raw).upper() if isinstance(raw, str) else ""


def generate_organization_code(name):
    """Name-derived prefix (readability) + cryptographically random suffix (unguessability)."""
    letters = re.sub(r"[^A-Z]", "", name.upper().replace("0", "O"))
    letters = "".join(ch for ch in letters if ch in CODE_ALPHABET)
    prefix = (letters[:3] or "ORG").ljust(3, "X")
    suffix = "".join(secrets.choice(CODE_ALPHABET) for _ in range(CODE_RANDOM_LENGTH))
    return prefix + suffix


def _unique_code(name):
    for _ in range(20):
        code = generate_organization_code(name)
        if not Organization.query.filter_by(organization_code=code).first():
            return code
    raise ServiceError(503, "Could not generate a unique organization code. Try again.")


def create_default_departments(organization_id):
    for name in DEFAULT_DEPARTMENTS:
        db.session.add(Department(organization_id=organization_id, department_name=name))


# ---------------------------------------------------------------- registration / joining
def register_organization(payload):
    payload = payload if isinstance(payload, dict) else {}
    errors = {}
    org_name = _text(payload.get("organization_name"), "organization_name", 150, errors=errors)
    org_email = _email(payload.get("organization_email"), "organization_email", errors)
    admin_name = _text(payload.get("admin_name"), "admin_name", 120, errors=errors)
    admin_email = _email(payload.get("admin_email"), "admin_email", errors)
    password = _password(payload.get("password"), errors)
    phone = _text(payload.get("contact_phone"), "contact_phone", 30, required=False, errors=errors)
    address = _text(payload.get("address"), "address", 300, required=False, errors=errors)
    if phone and not PHONE_PATTERN.fullmatch(phone):
        errors["contact_phone"] = "Enter a valid phone number."
    if errors:
        raise ServiceError(400, "Please correct the highlighted fields.", errors)

    keys = (_client_key(), f"reg:{admin_email}")
    rate_limit.check_allowed(*keys)
    user = User.query.filter_by(email=admin_email).first()
    if user:
        # Associate an existing personal account: the owner must prove it with the password.
        if not user.check_password(password):
            rate_limit.record_failure(*keys)
            raise ServiceError(401, "An account with this email exists; the password does not match it.")
    else:
        user = User(name=admin_name, email=admin_email)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

    organization = Organization(
        organization_name=org_name, organization_code=_unique_code(org_name),
        organization_email=org_email, contact_phone=phone, address=address,
    )
    db.session.add(organization)
    try:
        db.session.flush()
        create_default_departments(organization.organization_id)
        membership = OrganizationMembership(
            organization_id=organization.organization_id, user_id=user.user_id, role=ROLE_ADMIN,
        )
        db.session.add(membership)
        log_action(organization.organization_id, user.user_id, "organization_created", f"Organization '{org_name}' registered.")
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise ServiceError(409, "The organization could not be created. Please try again.")
    return organization, user


def join_organization(payload):
    payload = payload if isinstance(payload, dict) else {}
    errors = {}
    name = _text(payload.get("name"), "name", 120, errors=errors)
    email = _email(payload.get("email"), "email", errors)
    password = _password(payload.get("password"), errors)
    code = normalize_code(payload.get("organization_code"))
    if not code:
        errors["organization_code"] = "Organization code is required."
    if errors:
        raise ServiceError(400, "Please correct the highlighted fields.", errors)

    keys = (_client_key(), f"join:{email}")
    rate_limit.check_allowed(*keys)
    organization = Organization.query.filter_by(organization_code=code).first()
    if not organization or organization.status != ORG_ACTIVE or not organization.joining_enabled:
        rate_limit.record_failure(*keys)
        raise ServiceError(400, "Invalid organization code.", {"organization_code": "Invalid organization code."})

    user = User.query.filter_by(email=email).first()
    if user:
        if not user.check_password(password):
            rate_limit.record_failure(*keys)
            raise ServiceError(401, "An account with this email exists; the password does not match it.")
        if OrganizationMembership.query.filter_by(organization_id=organization.organization_id, user_id=user.user_id).first():
            raise ServiceError(409, "You are already a member of this organization.")
    else:
        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()
    # Joining never grants more than the Employee role, regardless of what the client sends.
    membership = OrganizationMembership(
        organization_id=organization.organization_id, user_id=user.user_id, role=ROLE_EMPLOYEE,
    )
    db.session.add(membership)
    log_action(organization.organization_id, user.user_id, "member_joined", f"{user.name} joined using the organization code.")
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise ServiceError(409, "You are already a member of this organization.")
    return organization, user, membership


# ---------------------------------------------------------------- session
def active_memberships(user_id):
    return (
        OrganizationMembership.query.join(Organization)
        .filter(
            OrganizationMembership.user_id == user_id,
            OrganizationMembership.membership_status == MEMBERSHIP_ACTIVE,
            Organization.status == ORG_ACTIVE,
        )
        .order_by(OrganizationMembership.membership_id)
        .all()
    )


def start_corporate_session(user, membership):
    session.clear()
    session["user_id"] = user.user_id
    session["membership_id"] = membership.membership_id
    session["mode"] = "corporate"
    session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def corporate_login(payload):
    payload = payload if isinstance(payload, dict) else {}
    email = payload.get("email")
    password = payload.get("password")
    if not isinstance(email, str) or not isinstance(password, str) or not email.strip() or not password:
        raise ServiceError(400, "Email and password are required.")
    if "remember" in payload and not isinstance(payload["remember"], bool):
        raise ServiceError(400, "Remember me must be a boolean value.")
    email = email.strip().lower()
    keys = (_client_key(), f"login:{email}")
    rate_limit.check_allowed(*keys)
    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        rate_limit.record_failure(*keys)
        raise ServiceError(401, "Invalid email or password.")

    memberships = active_memberships(user.user_id)
    if not memberships:
        raise ServiceError(403, "This account has no active organization membership. Join an organization or contact your administrator.")
    wanted_id = payload.get("organization_id")
    wanted_code = normalize_code(payload.get("organization_code"))
    if wanted_code:
        memberships = [m for m in memberships if m.organization.organization_code == wanted_code]
    if wanted_id is not None:
        memberships = [m for m in memberships if m.organization_id == wanted_id]
    if not memberships:
        rate_limit.record_failure(*keys)
        raise ServiceError(403, "You do not have an active membership in that organization.")
    if len(memberships) > 1:
        raise ServiceError(409, "Select the organization to sign in to.", {
            "organization_required": True,
            "organizations": [{"organization_id": m.organization_id, "organization_name": m.organization.organization_name, "role_label": ROLE_LABELS[m.role]} for m in memberships],
        })
    rate_limit.clear(*keys)
    membership = memberships[0]
    csrf = start_corporate_session(user, membership)
    session.permanent = bool(payload.get("remember", False))
    return user, membership, csrf


def switch_mode(user, payload):
    payload = payload if isinstance(payload, dict) else {}
    mode = payload.get("mode")
    if mode == "personal":
        session.pop("membership_id", None)
        session["mode"] = "personal"
        return None
    if mode == "corporate":
        memberships = active_memberships(user.user_id)
        wanted = payload.get("organization_id")
        if wanted is not None:
            memberships = [m for m in memberships if m.organization_id == wanted]
        if not memberships:
            raise ServiceError(403, "You do not have an active membership in that organization.")
        if len(memberships) > 1:
            raise ServiceError(409, "Select the organization to switch to.")
        session["membership_id"] = memberships[0].membership_id
        session["mode"] = "corporate"
        return memberships[0]
    raise ServiceError(400, "Mode must be 'personal' or 'corporate'.")


def session_payload(user):
    """Describes the current mode, membership and the user's available memberships."""
    memberships = active_memberships(user.user_id)
    current = None
    if session.get("mode") == "corporate":
        current = next((m for m in memberships if m.membership_id == session.get("membership_id")), None)
        if not current:
            session.pop("membership_id", None)
            session["mode"] = "personal"
    return {
        "mode": "corporate" if current else "personal",
        "membership": current.to_dict(include_code=current.role == ROLE_ADMIN) if current else None,
        "memberships": [
            {"organization_id": m.organization_id, "organization_name": m.organization.organization_name, "role": m.role, "role_label": ROLE_LABELS[m.role]}
            for m in memberships
        ],
    }


# ---------------------------------------------------------------- organization settings
def update_organization(context, payload):
    payload = payload if isinstance(payload, dict) else {}
    org = context.organization
    errors = {}
    if "organization_name" in payload:
        value = _text(payload["organization_name"], "organization_name", 150, errors=errors)
        if value:
            org.organization_name = value
    if "organization_email" in payload:
        value = _email(payload["organization_email"], "organization_email", errors)
        if value:
            org.organization_email = value
    for field, limit in (("contact_phone", 30), ("address", 300)):
        if field in payload:
            value = _text(payload[field], field, limit, required=False, errors=errors)
            if field == "contact_phone" and value and not PHONE_PATTERN.fullmatch(value):
                errors[field] = "Enter a valid phone number."
            setattr(org, field, value)
    if "joining_enabled" in payload:
        if not isinstance(payload["joining_enabled"], bool):
            errors["joining_enabled"] = "Must be true or false."
        else:
            org.joining_enabled = payload["joining_enabled"]
    if errors:
        db.session.rollback()
        raise ServiceError(400, "Please correct the highlighted fields.", errors)
    log_action(org.organization_id, context.user_id, "organization_updated", "Organization settings updated.")
    db.session.commit()
    return org


def regenerate_code(context):
    org = context.organization
    org.organization_code = _unique_code(org.organization_name)
    log_action(org.organization_id, context.user_id, "organization_code_regenerated", "Organization code regenerated.")
    db.session.commit()
    return org


# ---------------------------------------------------------------- members
def _membership_in_org(context, membership_id):
    membership = OrganizationMembership.query.filter_by(
        membership_id=membership_id, organization_id=context.organization_id
    ).first()
    if not membership:
        raise ServiceError(404, "Member not found.")
    return membership


def _department_in_org(context, department_id):
    department = Department.query.filter_by(department_id=department_id, organization_id=context.organization_id).first()
    if not department:
        raise ServiceError(400, "Department not found in this organization.", {"department_id": "Department not found."})
    return department


def list_members(context, args):
    query = OrganizationMembership.query.join(User).filter(OrganizationMembership.organization_id == context.organization_id)
    if args.get("role") in ROLES:
        query = query.filter(OrganizationMembership.role == args["role"])
    if args.get("status") in MEMBERSHIP_STATUSES:
        query = query.filter(OrganizationMembership.membership_status == args["status"])
    if args.get("department_id", "").isdigit():
        query = query.filter(OrganizationMembership.department_id == int(args["department_id"]))
    search = (args.get("search") or "").strip()
    if search:
        like = f"%{search.lower()}%"
        query = query.filter(func.lower(User.name).like(like) | func.lower(User.email).like(like))
    return query.order_by(User.name).all()


def add_member(context, payload):
    """Admin creates a brand-new account. Existing accounts must join with the code (consent)."""
    payload = payload if isinstance(payload, dict) else {}
    errors = {}
    name = _text(payload.get("name"), "name", 120, errors=errors)
    email = _email(payload.get("email"), "email", errors)
    password = _password(payload.get("password"), errors)
    role = payload.get("role", ROLE_EMPLOYEE)
    if role not in ROLES:
        errors["role"] = "Invalid role."
    department = None
    if payload.get("department_id") not in (None, ""):
        if not isinstance(payload["department_id"], int):
            errors["department_id"] = "Invalid department."
        elif not errors:
            department = _department_in_org(context, payload["department_id"])
    if errors:
        raise ServiceError(400, "Please correct the highlighted fields.", errors)
    if User.query.filter_by(email=email).first():
        raise ServiceError(409, "An account with this email already exists. Ask the person to join using the organization code.")
    user = User(name=name, email=email)
    user.set_password(password)
    db.session.add(user)
    db.session.flush()
    membership = OrganizationMembership(
        organization_id=context.organization_id, user_id=user.user_id, role=role,
        department_id=department.department_id if department else None,
    )
    db.session.add(membership)
    log_action(context.organization_id, context.user_id, "member_added", f"Added {name} as {ROLE_LABELS[role]}.")
    db.session.commit()
    return membership


def _active_admin_count(organization_id, exclude_membership_id=None):
    query = OrganizationMembership.query.filter_by(
        organization_id=organization_id, role=ROLE_ADMIN, membership_status=MEMBERSHIP_ACTIVE
    )
    if exclude_membership_id:
        query = query.filter(OrganizationMembership.membership_id != exclude_membership_id)
    return query.count()


def update_member(context, membership_id, payload):
    payload = payload if isinstance(payload, dict) else {}
    membership = _membership_in_org(context, membership_id)
    allowed = {"role", "department_id", "membership_status"}
    unknown = set(payload) - allowed
    if unknown:
        raise ServiceError(400, "Unsupported fields: " + ", ".join(sorted(unknown)) + ".")
    changes = []
    is_self = membership.user_id == context.user_id

    if "role" in payload and payload["role"] != membership.role:
        if payload["role"] not in ROLES:
            raise ServiceError(400, "Invalid role.", {"role": "Invalid role."})
        if is_self:
            raise ServiceError(403, "You cannot change your own role.")
        if membership.role == ROLE_ADMIN and _active_admin_count(context.organization_id, membership.membership_id) == 0:
            raise ServiceError(409, "The organization must keep at least one active administrator.")
        old_role = membership.role
        membership.role = payload["role"]
        if old_role == ROLE_MANAGER:  # stop managing departments once no longer a manager
            Department.query.filter_by(organization_id=context.organization_id, manager_id=membership.user_id).update({"manager_id": None})
        changes.append(f"role {ROLE_LABELS[old_role]} -> {ROLE_LABELS[membership.role]}")

    if "department_id" in payload:
        value = payload["department_id"]
        if value in (None, ""):
            membership.department_id = None
        elif isinstance(value, int) and not isinstance(value, bool):
            membership.department_id = _department_in_org(context, value).department_id
        else:
            raise ServiceError(400, "Invalid department.", {"department_id": "Invalid department."})
        changes.append("department changed")

    if "membership_status" in payload and payload["membership_status"] != membership.membership_status:
        if payload["membership_status"] not in MEMBERSHIP_STATUSES:
            raise ServiceError(400, "Invalid status.", {"membership_status": "Invalid status."})
        if is_self:
            raise ServiceError(403, "You cannot deactivate your own membership.")
        if payload["membership_status"] == MEMBERSHIP_INACTIVE:
            if membership.role == ROLE_ADMIN and _active_admin_count(context.organization_id, membership.membership_id) == 0:
                raise ServiceError(409, "The organization must keep at least one active administrator.")
            Department.query.filter_by(organization_id=context.organization_id, manager_id=membership.user_id).update({"manager_id": None})
        membership.membership_status = payload["membership_status"]
        changes.append(f"status -> {membership.membership_status}")

    if changes:
        log_action(context.organization_id, context.user_id, "member_updated", f"{membership.user.name}: " + "; ".join(changes))
    db.session.commit()
    return membership


# ---------------------------------------------------------------- departments
def _validate_manager(context, manager_id):
    if manager_id in (None, ""):
        return None
    if not isinstance(manager_id, int) or isinstance(manager_id, bool):
        raise ServiceError(400, "Invalid manager.", {"manager_id": "Invalid manager."})
    membership = OrganizationMembership.query.filter_by(
        organization_id=context.organization_id, user_id=manager_id, role=ROLE_MANAGER, membership_status=MEMBERSHIP_ACTIVE,
    ).first()
    if not membership:
        raise ServiceError(400, "The selected user must be an active Manager in this organization.", {"manager_id": "Choose an active user with the Manager role."})
    return manager_id


def create_department(context, payload):
    payload = payload if isinstance(payload, dict) else {}
    errors = {}
    name = _text(payload.get("department_name"), "department_name", 100, errors=errors)
    if errors:
        raise ServiceError(400, "Please correct the highlighted fields.", errors)
    if Department.query.filter(Department.organization_id == context.organization_id, func.lower(Department.department_name) == name.lower()).first():
        raise ServiceError(409, "A department with this name already exists.", {"department_name": "Name already in use."})
    manager_id = _validate_manager(context, payload.get("manager_id"))
    department = Department(organization_id=context.organization_id, department_name=name, manager_id=manager_id)
    db.session.add(department)
    log_action(context.organization_id, context.user_id, "department_created", f"Department '{name}' created.")
    db.session.commit()
    return department


def get_department(context, department_id):
    department = Department.query.filter_by(department_id=department_id, organization_id=context.organization_id).first()
    if not department:
        raise ServiceError(404, "Department not found.")
    return department


def update_department(context, department_id, payload):
    payload = payload if isinstance(payload, dict) else {}
    department = get_department(context, department_id)
    errors = {}
    if "department_name" in payload:
        name = _text(payload["department_name"], "department_name", 100, errors=errors)
        if name and name.lower() != department.department_name.lower():
            if Department.query.filter(Department.organization_id == context.organization_id, func.lower(Department.department_name) == name.lower()).first():
                errors["department_name"] = "Name already in use."
        if name and not errors:
            department.department_name = name
    if "status" in payload:
        if payload["status"] not in DEPT_STATUSES:
            errors["status"] = "Invalid status."
        else:
            department.status = payload["status"]
    if errors:
        db.session.rollback()
        raise ServiceError(400, "Please correct the highlighted fields.", errors)
    if "manager_id" in payload:
        department.manager_id = _validate_manager(context, payload["manager_id"])
    log_action(context.organization_id, context.user_id, "department_updated", f"Department '{department.department_name}' updated.")
    db.session.commit()
    return department


def department_members(context, department_id):
    department = get_department(context, department_id)
    members = OrganizationMembership.query.join(User).filter(
        OrganizationMembership.organization_id == context.organization_id,
        OrganizationMembership.department_id == department.department_id,
    ).order_by(User.name).all()
    return department, members


def managed_department_ids(context):
    """Departments this user is explicitly assigned to manage within the current organization."""
    rows = Department.query.filter_by(organization_id=context.organization_id, manager_id=context.user_id).all()
    return [row.department_id for row in rows]
