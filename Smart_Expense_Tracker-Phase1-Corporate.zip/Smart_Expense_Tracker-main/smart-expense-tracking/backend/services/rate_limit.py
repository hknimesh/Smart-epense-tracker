"""Small in-process failure limiter for corporate login/join (brute-force protection).

State is per server process. Behind several workers, use a shared store (e.g. Redis) instead.
"""
import threading
import time
from collections import defaultdict, deque

from flask import current_app

from services.corporate_errors import ServiceError

_lock = threading.Lock()
_failures = defaultdict(deque)


def _limits():
    return (
        current_app.config.get("CORPORATE_MAX_FAILURES", 10),
        current_app.config.get("CORPORATE_FAILURE_WINDOW_SECONDS", 15 * 60),
    )


def _prune(bucket, window, now):
    while bucket and now - bucket[0] > window:
        bucket.popleft()


def check_allowed(*keys):
    limit, window = _limits()
    now = time.monotonic()
    with _lock:
        for key in keys:
            bucket = _failures[key]
            _prune(bucket, window, now)
            if len(bucket) >= limit:
                raise ServiceError(429, "Too many failed attempts. Please wait a few minutes and try again.")


def record_failure(*keys):
    _, window = _limits()
    now = time.monotonic()
    with _lock:
        for key in keys:
            bucket = _failures[key]
            _prune(bucket, window, now)
            bucket.append(now)


def clear(*keys):
    with _lock:
        for key in keys:
            _failures.pop(key, None)


def reset_all():
    with _lock:
        _failures.clear()
