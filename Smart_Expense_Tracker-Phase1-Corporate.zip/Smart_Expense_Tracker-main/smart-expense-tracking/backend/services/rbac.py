"""Server-side role-based access control for corporate APIs.

Every protected corporate endpoint is wrapped with `corporate_required(...)`. The role is always
loaded from the database (never from the request or the client), and the membership is
re-validated on each call so deactivation or role changes take effect immediately.
"""
from dataclasses import dataclass
from functools import wraps

from flask import g, jsonify, session

from extensions import db
from models import Organization, OrganizationMembership, User
from models.corporate_constants import MEMBERSHIP_ACTIVE, ORG_ACTIVE


@dataclass
class CorporateContext:
    user: User
    membership: OrganizationMembership
    organization: Organization

    @property
    def user_id(self):
        return self.user.user_id

    @property
    def organization_id(self):
        return self.organization.organization_id

    @property
    def role(self):
        return self.membership.role


def _error(status, message):
    return jsonify(success=False, message=message), status


def load_context():
    """Return (context, error_response). Exactly one of the two is None."""
    user_id = session.get("user_id")
    user = db.session.get(User, user_id) if user_id else None
    if not user:
        session.pop("user_id", None)
        return None, _error(401, "Authentication required.")
    membership_id = session.get("membership_id")
    if session.get("mode") != "corporate" or not membership_id:
        return None, _error(403, "Corporate access requires signing in to an organization.")
    membership = db.session.get(OrganizationMembership, membership_id)
    organization = membership.organization if membership else None
    if (
        not membership
        or membership.user_id != user.user_id
        or membership.membership_status != MEMBERSHIP_ACTIVE
        or not organization
        or organization.status != ORG_ACTIVE
    ):
        session.pop("membership_id", None)
        session.pop("mode", None)
        return None, _error(403, "Your organization membership is no longer active.")
    return CorporateContext(user, membership, organization), None


def corporate_required(*allowed_roles):
    """Decorator: require an authenticated, active corporate membership with one of `allowed_roles`.

    With no roles given, any active member is accepted.
    """

    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            context, error = load_context()
            if error:
                return error
            if allowed_roles and context.role not in allowed_roles:
                return _error(403, "Your role does not permit this action.")
            g.corp = context
            return view(*args, **kwargs)

        return wrapper

    return decorator
