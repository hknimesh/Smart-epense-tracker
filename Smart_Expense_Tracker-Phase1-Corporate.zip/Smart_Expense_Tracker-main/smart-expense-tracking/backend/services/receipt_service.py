"""Receipt upload validation and storage for corporate expenses."""
import uuid
from pathlib import Path

from flask import current_app

from services.corporate_errors import ServiceError

MAX_RECEIPT_BYTES = 5 * 1024 * 1024
# extension -> (mime type, magic-byte check)
RECEIPT_TYPES = {
    "pdf": ("application/pdf", lambda b: b.startswith(b"%PDF-")),
    "png": ("image/png", lambda b: b.startswith(b"\x89PNG\r\n\x1a\n")),
    "jpg": ("image/jpeg", lambda b: b.startswith(b"\xff\xd8\xff")),
    "jpeg": ("image/jpeg", lambda b: b.startswith(b"\xff\xd8\xff")),
}


def receipt_root():
    configured = current_app.config.get("CORPORATE_RECEIPT_DIR")
    root = Path(configured) if configured else Path(current_app.instance_path) / "corporate_receipts"
    root.mkdir(parents=True, exist_ok=True)
    return root


def save_receipt(file_storage, organization_id):
    """Validate and store an uploaded receipt. Returns (relative_path, original_name)."""
    original = Path(file_storage.filename or "").name
    extension = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if extension not in RECEIPT_TYPES:
        raise ServiceError(400, "Receipt must be a PDF, PNG or JPG file.", {"receipt": "Unsupported file type."})
    data = file_storage.read(MAX_RECEIPT_BYTES + 1)
    if not data:
        raise ServiceError(400, "The receipt file is empty.", {"receipt": "Empty file."})
    if len(data) > MAX_RECEIPT_BYTES:
        raise ServiceError(400, "Receipt must be 5 MB or smaller.", {"receipt": "File too large."})
    if not RECEIPT_TYPES[extension][1](data):
        raise ServiceError(400, "The file content does not match its type.", {"receipt": "Invalid file content."})
    stored_extension = "jpg" if extension == "jpeg" else extension
    relative = f"{organization_id}/{uuid.uuid4().hex}.{stored_extension}"
    target = receipt_root() / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return relative, original[:255]


def receipt_file(relative_path):
    """Resolve a stored receipt to a safe absolute path, or None."""
    if not relative_path:
        return None
    root = receipt_root().resolve()
    candidate = (root / relative_path).resolve()
    if root not in candidate.parents or not candidate.is_file():
        return None
    return candidate


def receipt_mime(path):
    return RECEIPT_TYPES.get(path.suffix.lstrip(".").lower(), ("application/octet-stream", None))[0]
