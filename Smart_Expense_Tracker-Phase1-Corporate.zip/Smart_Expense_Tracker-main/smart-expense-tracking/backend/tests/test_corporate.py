"""Phase 1 corporate module tests (isolated in-memory SQLite; never touches MySQL)."""
import io
from datetime import date, timedelta
from decimal import Decimal

import pytest

from extensions import db
from models import (
    CorporateExpense, Department, Expense, ExpenseApproval, Organization, OrganizationMembership, User,
)
from services import rate_limit
from tests.test_auth import TestConfig, add_category
from app import create_app

PW = "correct horse battery"
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 64


@pytest.fixture
def app():
    test_app = create_app(TestConfig)
    with test_app.app_context():
        db.create_all()
        rate_limit.reset_all()
        yield test_app
        db.session.remove()
        db.drop_all()


class Actor:
    def __init__(self, app, email=None):
        self.client = app.test_client()
        self.email = email
        self.csrf = None

    def _headers(self):
        if not self.csrf:
            self.csrf = self.client.get("/api/auth/csrf").json["data"]["csrf_token"]
        return {"X-CSRF-Token": self.csrf}

    def get(self, url, **kw):
        return self.client.get(url, **kw)

    def post(self, url, json=None, **kw):
        return self.client.post(url, json=json, headers=self._headers(), **kw)

    def put(self, url, json=None, **kw):
        return self.client.put(url, json=json, headers=self._headers(), **kw)

    def corporate_login(self, email, password=PW, **extra):
        self.email = email
        response = self.post("/api/corporate/auth/login", {"email": email, "password": password, **extra})
        if response.status_code == 200:
            self.csrf = response.json["data"]["csrf_token"]
        return response

    def personal_login(self, email, password=PW):
        response = self.post("/api/auth/login", {"email": email, "password": password})
        if response.status_code == 200:
            self.csrf = response.json["data"]["csrf_token"]
        return response


def register_org(app, name="Acme Works", admin_email="admin@acme.test", password=PW):
    actor = Actor(app)
    response = actor.post("/api/corporate/organizations/register", {
        "organization_name": name, "organization_email": "hello@acme.test", "admin_name": "Ada Admin",
        "admin_email": admin_email, "password": password,
    })
    return actor, response


def login_as(app, email, password=PW, **extra):
    actor = Actor(app)
    response = actor.corporate_login(email, password, **extra)
    assert response.status_code == 200, response.json
    return actor


@pytest.fixture
def world(app):
    """One organization with every role; two IT employees, one HR employee."""
    _, response = register_org(app)
    assert response.status_code == 201
    code = response.json["data"]["organization"]["organization_code"]
    admin = login_as(app, "admin@acme.test")
    depts = {d["department_name"]: d["department_id"] for d in admin.get("/api/corporate/departments").json["data"]["departments"]}
    people = [
        ("mgr_it@acme.test", "manager", "IT"), ("mgr_hr@acme.test", "manager", "Human Resources"),
        ("emp1@acme.test", "employee", "IT"), ("emp2@acme.test", "employee", "IT"),
        ("emp_hr@acme.test", "employee", "Human Resources"),
        ("fin@acme.test", "finance_officer", None), ("exec@acme.test", "executive", None),
    ]
    for email, role, dept in people:
        r = admin.post("/api/corporate/members", {"name": email.split("@")[0], "email": email, "password": PW, "role": role, "department_id": depts.get(dept)})
        assert r.status_code == 201, r.json
    for email, dept in (("mgr_it@acme.test", "IT"), ("mgr_hr@acme.test", "Human Resources")):
        uid = User.query.filter_by(email=email).first().user_id
        assert admin.put(f"/api/corporate/departments/{depts[dept]}", {"manager_id": uid}).status_code == 200
    actors = {"admin": admin}
    for key, email in {"mgr_it": "mgr_it@acme.test", "mgr_hr": "mgr_hr@acme.test", "emp1": "emp1@acme.test", "emp2": "emp2@acme.test",
                       "emp_hr": "emp_hr@acme.test", "fin": "fin@acme.test", "exec": "exec@acme.test"}.items():
        actors[key] = login_as(app, email)
    actors.update(code=code, depts=depts)
    return actors


def expense_body(**overrides):
    body = {"title": "Client lunch", "amount": "1500.50", "expense_date": date.today().isoformat(), "category": "Food and accommodation", "vendor": "Cafe", "payment_method": "Corporate Card"}
    body.update(overrides)
    return body


def submit(actor, **overrides):
    response = actor.post("/api/corporate/expenses", expense_body(**overrides))
    assert response.status_code == 201, response.json
    return response.json["data"]["expense"]


# ================================================================ authentication & organization
def test_organization_registration_creates_admin_departments_and_code(app):
    actor, response = register_org(app)
    assert response.status_code == 201
    org = response.json["data"]["organization"]
    assert len(org["organization_code"]) == 9 and org["organization_code"].startswith("ACM")
    membership = OrganizationMembership.query.one()
    assert membership.role == "org_admin"
    assert Department.query.count() == 6
    assert {d.department_name for d in Department.query.all()} == {"IT", "Human Resources", "Finance", "Marketing", "Sales", "Operations"}


def test_organization_codes_are_unique(app):
    codes = {register_org(app, name="Acme", admin_email=f"a{i}@x.test")[1].json["data"]["organization"]["organization_code"] for i in range(8)}
    assert len(codes) == 8


def test_organization_registration_validation_and_existing_account(app):
    _, bad = register_org(app, name="", admin_email="not-an-email", password="short")
    assert bad.status_code == 400 and {"organization_name", "admin_email", "password"} <= set(bad.json["errors"])
    personal = Actor(app)
    assert personal.post("/api/auth/register", {"name": "Pat", "email": "pat@x.test", "password": PW}).status_code == 201
    _, wrong = register_org(app, admin_email="pat@x.test", password="wrong password!")
    assert wrong.status_code == 401
    _, ok = register_org(app, name="Pat Co", admin_email="pat@x.test")
    assert ok.status_code == 201
    assert User.query.filter_by(email="pat@x.test").count() == 1


def test_employee_join_valid_code_gets_employee_role_even_if_role_requested(app, world):
    actor = Actor(app)
    response = actor.post("/api/corporate/auth/join", {"name": "New Hire", "email": "new@acme.test", "password": PW, "organization_code": world["code"].lower(), "role": "org_admin"})
    assert response.status_code == 201
    membership = OrganizationMembership.query.join(User).filter(User.email == "new@acme.test").one()
    assert membership.role == "employee" and membership.department_id is None


def test_join_invalid_code_rejected_and_rate_limited(app, world):
    actor = Actor(app)
    body = {"name": "X", "email": "x@acme.test", "password": PW, "organization_code": "WRONG1234"}
    for _ in range(10):
        assert actor.post("/api/corporate/auth/join", body).status_code == 400
    assert actor.post("/api/corporate/auth/join", body).status_code == 429
    assert User.query.filter_by(email="x@acme.test").count() == 0


def test_existing_personal_account_joins_without_duplicate_user(app, world):
    actor = Actor(app)
    assert actor.post("/api/auth/register", {"name": "Sam Personal", "email": "sam@x.test", "password": PW}).status_code == 201
    joined = actor.post("/api/corporate/auth/join", {"name": "Other Name", "email": "sam@x.test", "password": PW, "organization_code": world["code"]})
    assert joined.status_code == 201
    assert User.query.filter_by(email="sam@x.test").count() == 1
    assert User.query.filter_by(email="sam@x.test").one().name == "Sam Personal"
    again = actor.post("/api/corporate/auth/join", {"name": "S", "email": "sam@x.test", "password": PW, "organization_code": world["code"]})
    assert again.status_code == 409
    wrong = Actor(app).post("/api/corporate/auth/join", {"name": "S", "email": "sam@x.test", "password": "bad password!", "organization_code": world["code"]})
    assert wrong.status_code == 401


def test_corporate_login_roles_and_invalid_credentials(app, world):
    for email, role in (("admin@acme.test", "org_admin"), ("emp1@acme.test", "employee"), ("mgr_it@acme.test", "manager"), ("fin@acme.test", "finance_officer"), ("exec@acme.test", "executive")):
        actor = Actor(app)
        response = actor.corporate_login(email)
        assert response.status_code == 200 and response.json["data"]["membership"]["role"] == role
        assert actor.get("/api/corporate/session").json["data"]["mode"] == "corporate"
    assert Actor(app).corporate_login("emp1@acme.test", "wrong password!").status_code == 401
    assert Actor(app).corporate_login("nobody@acme.test").status_code == 401
    assert "organization_code" not in world["emp1"].get("/api/corporate/organization").json["data"]["organization"]
    assert "organization_code" in world["admin"].get("/api/corporate/organization").json["data"]["organization"]


def test_login_client_cannot_choose_a_role(app, world):
    actor = Actor(app)
    response = actor.corporate_login("emp1@acme.test", role="org_admin")
    assert response.json["data"]["membership"]["role"] == "employee"


def test_login_without_membership_is_forbidden_but_personal_login_works(app):
    actor = Actor(app)
    actor.post("/api/auth/register", {"name": "Solo", "email": "solo@x.test", "password": PW})
    assert Actor(app).corporate_login("solo@x.test").status_code == 403
    assert actor.personal_login("solo@x.test").status_code == 200
    assert actor.get("/api/corporate/session").json["data"]["mode"] == "personal"


def test_multiple_memberships_require_organization_selection(app, world):
    _, other = register_org(app, name="Beta Corp", admin_email="boss@beta.test")
    beta_code = other.json["data"]["organization"]["organization_code"]
    actor = Actor(app)
    assert actor.post("/api/corporate/auth/join", {"name": "E1", "email": "emp1@acme.test", "password": PW, "organization_code": beta_code}).status_code == 201
    response = Actor(app).corporate_login("emp1@acme.test")
    assert response.status_code == 409 and len(response.json["errors"]["organizations"]) == 2
    beta_id = Organization.query.filter_by(organization_code=beta_code).one().organization_id
    chosen = Actor(app)
    assert chosen.corporate_login("emp1@acme.test", organization_id=beta_id).status_code == 200
    assert chosen.get("/api/corporate/organization").json["data"]["organization"]["organization_name"] == "Beta Corp"


def test_unauthenticated_and_personal_mode_sessions_are_blocked(app, world):
    anonymous = Actor(app)
    assert anonymous.get("/api/corporate/expenses").status_code == 401
    personal = Actor(app)
    personal.post("/api/auth/register", {"name": "P", "email": "p@x.test", "password": PW})
    personal.personal_login("p@x.test")
    assert personal.get("/api/corporate/expenses").status_code == 403


def test_deactivated_membership_is_locked_out_immediately(app, world):
    mid = OrganizationMembership.query.join(User).filter(User.email == "emp1@acme.test").one().membership_id
    assert world["admin"].put(f"/api/corporate/members/{mid}", {"membership_status": "inactive"}).status_code == 200
    assert world["emp1"].get("/api/corporate/expenses").status_code == 403
    assert Actor(app).corporate_login("emp1@acme.test").status_code == 403


# ================================================================ RBAC
def test_employee_cannot_use_manager_finance_or_admin_apis(app, world):
    emp = world["emp1"]
    assert emp.get("/api/corporate/approvals").status_code == 403
    assert emp.post("/api/corporate/approvals/1/approve").status_code == 403
    assert emp.get("/api/corporate/members").status_code == 403
    assert emp.post("/api/corporate/departments", {"department_name": "Hack"}).status_code == 403
    assert emp.get("/api/corporate/dashboard/finance").status_code == 403
    assert emp.get("/api/corporate/dashboard/admin").status_code == 403
    assert emp.get("/api/corporate/reports/export").status_code == 403
    assert emp.put("/api/corporate/organization", {"organization_name": "Pwned"}).status_code == 403


def test_admin_has_no_automatic_financial_access(app, world):
    admin = world["admin"]
    submit(world["emp1"])
    for url in ("/api/corporate/expenses", "/api/corporate/dashboard/finance", "/api/corporate/dashboard/executive", "/api/corporate/reports/summary", "/api/corporate/approvals"):
        assert admin.get(url).status_code == 403, url
    assert world["fin"].get("/api/corporate/members").status_code == 403
    assert world["exec"].get("/api/corporate/members").status_code == 403


def test_users_cannot_change_their_own_role(app, world):
    mid = OrganizationMembership.query.join(User).filter(User.email == "emp1@acme.test").one().membership_id
    assert world["emp1"].put(f"/api/corporate/members/{mid}", {"role": "org_admin"}).status_code == 403
    world["emp1"].put("/api/users/profile", {"name": "Renamed", "role": "org_admin"})
    assert db.session.get(OrganizationMembership, mid).role == "employee"
    admin_mid = OrganizationMembership.query.join(User).filter(User.email == "admin@acme.test").one().membership_id
    assert world["admin"].put(f"/api/corporate/members/{admin_mid}", {"role": "employee"}).status_code == 403
    assert world["admin"].put(f"/api/corporate/members/{admin_mid}", {"membership_status": "inactive"}).status_code == 403


def test_admin_assigns_roles_and_organization_keeps_an_admin(app, world):
    admin = world["admin"]
    mid = OrganizationMembership.query.join(User).filter(User.email == "emp2@acme.test").one().membership_id
    assert admin.put(f"/api/corporate/members/{mid}", {"role": "org_admin"}).status_code == 200
    assert admin.put(f"/api/corporate/members/{mid}", {"role": "employee"}).status_code == 200
    assert admin.put(f"/api/corporate/members/{mid}", {"organization_id": 99}).status_code == 400
    assert admin.put(f"/api/corporate/members/{mid}", {"role": "superuser"}).status_code == 400


def test_cross_organization_isolation(app, world):
    expense = submit(world["emp1"])
    _, other = register_org(app, name="Beta Corp", admin_email="boss@beta.test")
    beta_admin = login_as(app, "boss@beta.test")
    members = {"fin": "f@beta.test", "emp": "e@beta.test"}
    depts = beta_admin.get("/api/corporate/departments").json["data"]["departments"]
    for key, email in members.items():
        beta_admin.post("/api/corporate/members", {"name": key, "email": email, "password": PW, "role": "finance_officer" if key == "fin" else "employee", "department_id": depts[0]["department_id"] if key == "emp" else None})
    beta_fin, beta_emp = login_as(app, "f@beta.test"), login_as(app, "e@beta.test")
    assert beta_fin.get(f"/api/corporate/expenses/{expense['expense_id']}").status_code == 404
    assert beta_fin.get("/api/corporate/expenses").json["data"]["pagination"]["total"] == 0
    assert beta_fin.post(f"/api/corporate/approvals/{expense['expense_id']}/approve").status_code == 404
    acme_member = OrganizationMembership.query.join(User).filter(User.email == "emp1@acme.test").one().membership_id
    assert beta_admin.put(f"/api/corporate/members/{acme_member}", {"role": "manager"}).status_code == 404
    acme_dept = world["depts"]["IT"]
    assert beta_admin.put(f"/api/corporate/departments/{acme_dept}", {"department_name": "Hijacked"}).status_code == 404
    # supplying someone else's department/organization on submit is rejected or ignored
    assert beta_emp.post("/api/corporate/expenses", expense_body(department_id=acme_dept)).status_code == 400


# ================================================================ departments & members
def test_department_management(app, world):
    admin = world["admin"]
    created = admin.post("/api/corporate/departments", {"department_name": "Legal"})
    assert created.status_code == 201
    assert admin.post("/api/corporate/departments", {"department_name": "legal"}).status_code == 409
    did = created.json["data"]["department"]["department_id"]
    assert admin.put(f"/api/corporate/departments/{did}", {"department_name": "Legal & Compliance", "status": "inactive"}).status_code == 200
    # manager must hold the Manager role
    emp_uid = User.query.filter_by(email="emp1@acme.test").one().user_id
    assert admin.put(f"/api/corporate/departments/{did}", {"manager_id": emp_uid}).status_code == 400
    members = admin.get(f"/api/corporate/departments/{world['depts']['IT']}/members").json["data"]["members"]
    assert {m["user_email"] for m in members} == {"emp1@acme.test", "emp2@acme.test", "mgr_it@acme.test"}
    assert world["mgr_hr"].get(f"/api/corporate/departments/{world['depts']['IT']}/members").status_code == 404
    assert world["mgr_it"].get(f"/api/corporate/departments/{world['depts']['IT']}/members").status_code == 200


def test_admin_cannot_attach_existing_account_without_consent(app, world):
    response = world["admin"].post("/api/corporate/members", {"name": "E", "email": "emp1@acme.test", "password": PW, "role": "employee"})
    assert response.status_code == 409


def test_demoting_manager_clears_department_manager(app, world):
    mid = OrganizationMembership.query.join(User).filter(User.email == "mgr_it@acme.test").one().membership_id
    world["admin"].put(f"/api/corporate/members/{mid}", {"role": "employee"})
    assert db.session.get(Department, world["depts"]["IT"]).manager_id is None


# ================================================================ expenses
def test_employee_submits_expense_with_server_controlled_fields(app, world):
    emp = world["emp1"]
    response = emp.post("/api/corporate/expenses", expense_body(organization_id=999, user_id=999, approval_status="paid", department_id=world["depts"]["IT"]))
    assert response.status_code == 201
    expense = CorporateExpense.query.one()
    emp_user = User.query.filter_by(email="emp1@acme.test").one()
    assert expense.user_id == emp_user.user_id
    assert expense.organization_id == Organization.query.one().organization_id
    assert expense.department_id == world["depts"]["IT"]
    assert expense.approval_status == "pending_manager"
    assert expense.amount == Decimal("1500.50")
    history = ExpenseApproval.query.filter_by(expense_id=expense.expense_id).all()
    assert len(history) == 1 and history[0].new_status == "pending_manager"


@pytest.mark.parametrize("override", [
    {"amount": "-5"}, {"amount": "0"}, {"amount": "10.123"}, {"amount": "abc"}, {"title": "ab"},
    {"expense_date": (date.today() + timedelta(days=2)).isoformat()}, {"expense_date": "yesterday"},
    {"category": "Gambling"}, {"payment_method": "Bitcoin"},
])
def test_expense_validation(app, world, override):
    assert world["emp1"].post("/api/corporate/expenses", expense_body(**override)).status_code == 400
    assert CorporateExpense.query.count() == 0


def test_employee_without_department_or_in_other_department_cannot_submit(app, world):
    assert world["emp1"].post("/api/corporate/expenses", expense_body(department_id=world["depts"]["Marketing"])).status_code == 400
    actor = Actor(app)
    actor.post("/api/corporate/auth/join", {"name": "Nodept", "email": "nodept@acme.test", "password": PW, "organization_code": world["code"]})
    nodept = login_as(app, "nodept@acme.test")
    assert nodept.post("/api/corporate/expenses", expense_body()).status_code == 400


def test_only_employees_submit_and_employees_see_only_their_own(app, world):
    first, second = submit(world["emp1"]), submit(world["emp2"], title="Taxi fare")
    assert world["mgr_it"].post("/api/corporate/expenses", expense_body()).status_code == 403
    mine = world["emp1"].get("/api/corporate/expenses").json["data"]
    assert [e["expense_id"] for e in mine["expenses"]] == [first["expense_id"]]
    assert world["emp1"].get(f"/api/corporate/expenses/{second['expense_id']}").status_code == 404
    assert world["emp1"].put(f"/api/corporate/expenses/{second['expense_id']}", {"title": "Hijack title"}).status_code == 404
    assert world["emp1"].get(f"/api/corporate/expenses/{first['expense_id']}").json["data"]["expense"]["history"][0]["new_status"] == "pending_manager"


def test_employee_can_edit_only_while_pending_manager(app, world):
    expense = submit(world["emp1"])
    url = f"/api/corporate/expenses/{expense['expense_id']}"
    assert world["emp1"].put(url, {"title": "Corrected title", "amount": "99.00"}).status_code == 200
    assert world["emp1"].put(url, {"status": "paid", "approval_status": "paid", "amount": "99.00"}).json["data"]["expense"]["approval_status"] == "pending_manager"
    world["mgr_it"].post(f"/api/corporate/approvals/{expense['expense_id']}/approve")
    assert world["emp1"].put(url, {"title": "Too late"}).status_code == 409


def test_receipt_upload_validation_and_access(app, world, tmp_path):
    app.config["CORPORATE_RECEIPT_DIR"] = str(tmp_path)
    emp = world["emp1"]
    ok = emp.client.post("/api/corporate/expenses", data={**expense_body(), "receipt": (io.BytesIO(PNG), "bill.png")}, headers=emp._headers(), content_type="multipart/form-data")
    assert ok.status_code == 201 and ok.json["data"]["expense"]["has_receipt"]
    eid = ok.json["data"]["expense"]["expense_id"]
    assert emp.get(f"/api/corporate/expenses/{eid}/receipt").data == PNG
    assert world["mgr_it"].get(f"/api/corporate/expenses/{eid}/receipt").status_code == 200
    assert world["mgr_hr"].get(f"/api/corporate/expenses/{eid}/receipt").status_code == 404
    assert world["emp2"].get(f"/api/corporate/expenses/{eid}/receipt").status_code == 404
    for name, content in (("evil.exe", b"MZ"), ("fake.png", b"not a png"), ("big.pdf", b"%PDF-" + b"0" * (5 * 1024 * 1024 + 10))):
        r = emp.client.post("/api/corporate/expenses", data={**expense_body(), "receipt": (io.BytesIO(content), name)}, headers=emp._headers(), content_type="multipart/form-data")
        assert r.status_code in (400, 413), name
    assert CorporateExpense.query.count() == 1


# ================================================================ approval workflow
def test_full_workflow_manager_finance_paid_with_history(app, world):
    e = submit(world["emp1"])
    eid = e["expense_id"]
    r = world["mgr_it"].post(f"/api/corporate/approvals/{eid}/approve", {"comments": "ok"})
    assert r.status_code == 200 and r.json["data"]["expense"]["approval_status"] == "pending_finance"
    r = world["fin"].post(f"/api/corporate/approvals/{eid}/approve")
    assert r.json["data"]["expense"]["approval_status"] == "approved"
    r = world["fin"].post(f"/api/corporate/approvals/{eid}/pay")
    expense = r.json["data"]["expense"]
    assert expense["approval_status"] == "paid" and expense["paid_at"]
    history = [(h["previous_status"], h["new_status"]) for h in expense["history"]]
    assert history == [(None, "pending_manager"), ("pending_manager", "pending_finance"), ("pending_finance", "approved"), ("approved", "paid")]
    assert world["emp1"].get(f"/api/corporate/expenses/{eid}").json["data"]["expense"]["approval_status"] == "paid"


def test_manager_rejection_requires_reason(app, world):
    eid = submit(world["emp1"])["expense_id"]
    assert world["mgr_it"].post(f"/api/corporate/approvals/{eid}/reject", {"comments": ""}).status_code == 400
    r = world["mgr_it"].post(f"/api/corporate/approvals/{eid}/reject", {"comments": "Not a business expense"})
    assert r.status_code == 200 and r.json["data"]["expense"]["approval_status"] == "rejected"
    assert world["emp1"].get(f"/api/corporate/expenses/{eid}").json["data"]["expense"]["rejection_reason"] == "Not a business expense"
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/approve").status_code == 409


def test_finance_rejection_and_invalid_transitions(app, world):
    eid = submit(world["emp1"])["expense_id"]
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/approve").status_code == 409   # skipping manager
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/pay").status_code == 409
    world["mgr_it"].post(f"/api/corporate/approvals/{eid}/approve")
    assert world["mgr_it"].post(f"/api/corporate/approvals/{eid}/approve").status_code == 409  # already moved on
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/pay").status_code == 409         # not yet verified
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/reject", {"comments": ""}).status_code == 400
    r = world["fin"].post(f"/api/corporate/approvals/{eid}/reject", {"comments": "Receipt missing"})
    assert r.json["data"]["expense"]["approval_status"] == "rejected"
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/approve").status_code == 409     # terminal
    assert world["fin"].post(f"/api/corporate/approvals/{eid}/explode").status_code == 400


def test_manager_limited_to_managed_department(app, world):
    it_id = submit(world["emp1"])["expense_id"]
    hr_id = submit(world["emp_hr"])["expense_id"]
    assert world["mgr_it"].post(f"/api/corporate/approvals/{hr_id}/approve").status_code == 404
    assert world["mgr_it"].get(f"/api/corporate/expenses/{hr_id}").status_code == 404
    ids = [e["expense_id"] for e in world["mgr_it"].get("/api/corporate/expenses").json["data"]["expenses"]]
    assert ids == [it_id]
    assert [e["expense_id"] for e in world["mgr_it"].get("/api/corporate/approvals").json["data"]["expenses"]] == [it_id]
    assert world["mgr_hr"].post(f"/api/corporate/approvals/{hr_id}/approve").status_code == 200


def test_approval_queue_search_stays_within_scope(app, world):
    submit(world["emp1"], title="Unique laptop bag", vendor="Acme Store")
    submit(world["emp2"], title="Taxi fare")
    submit(world["emp_hr"], title="Laptop sleeve")
    queue = lambda actor, q: [e["title"] for e in actor.get(f"/api/corporate/approvals?search={q}").json["data"]["expenses"]]
    assert queue(world["mgr_it"], "laptop") == ["Unique laptop bag"]           # HR's "Laptop sleeve" is out of scope
    assert queue(world["mgr_it"], "acme") == ["Unique laptop bag"]             # vendor match
    assert queue(world["mgr_it"], "emp2") == ["Taxi fare"]                     # employee-name match
    assert queue(world["mgr_it"], "nothing-matches") == []
    assert len(world["mgr_it"].get("/api/corporate/approvals").json["data"]["expenses"]) == 2


def test_reviewers_cannot_review_their_own_expense(app, world):
    eid = submit(world["emp1"])["expense_id"]
    # promote the submitter to manager of IT: they still cannot approve their own claim
    emp_uid = User.query.filter_by(email="emp1@acme.test").one().user_id
    mid = OrganizationMembership.query.filter_by(user_id=emp_uid).one().membership_id
    world["admin"].put(f"/api/corporate/members/{mid}", {"role": "manager"})
    world["admin"].put(f"/api/corporate/departments/{world['depts']['IT']}", {"manager_id": emp_uid})
    promoted = login_as(app, "emp1@acme.test")
    assert promoted.post(f"/api/corporate/approvals/{eid}/approve").status_code == 403
    # and the same for finance
    world["admin"].put(f"/api/corporate/members/{mid}", {"role": "finance_officer"})
    as_finance = login_as(app, "emp1@acme.test")
    assert as_finance.post(f"/api/corporate/approvals/{eid}/approve").status_code == 403


# ================================================================ reports & dashboards
def build_known_data(world):
    ids = {}
    ids["a"] = submit(world["emp1"], amount="100.00", category="Travel", expense_date=(date.today() - timedelta(days=40)).isoformat())["expense_id"]
    ids["b"] = submit(world["emp2"], amount="250.50", category="Equipment")["expense_id"]
    ids["c"] = submit(world["emp_hr"], amount="75.25", category="Office supplies")["expense_id"]
    ids["d"] = submit(world["emp1"], amount="40.00", category="Travel")["expense_id"]
    mgr, fin = world["mgr_it"], world["fin"]
    mgr.post(f"/api/corporate/approvals/{ids['a']}/approve"); fin.post(f"/api/corporate/approvals/{ids['a']}/approve"); fin.post(f"/api/corporate/approvals/{ids['a']}/pay")
    mgr.post(f"/api/corporate/approvals/{ids['b']}/approve"); fin.post(f"/api/corporate/approvals/{ids['b']}/approve")
    world["mgr_hr"].post(f"/api/corporate/approvals/{ids['c']}/approve")
    mgr.post(f"/api/corporate/approvals/{ids['d']}/reject", {"comments": "personal"})
    return ids


def test_finance_dashboard_and_reports_match_database(app, world):
    build_known_data(world)
    data = world["fin"].get("/api/corporate/dashboard/finance").json["data"]
    s = data["summary"]
    assert (s["submitted_count"], s["submitted_amount"]) == (4, "465.75")
    assert (s["paid_count"], s["paid_amount"]) == (1, "100.00")
    assert (s["approved_count"], s["approved_amount"]) == (1, "250.50")
    assert (s["pending_finance_count"], s["pending_finance_amount"]) == (1, "75.25")
    assert (s["rejected_count"], s["rejected_amount"]) == (1, "40.00")
    assert s["expenditure_amount"] == "350.50"
    depts = {d["department_name"]: d for d in data["by_department"]}
    assert depts["IT"]["expenditure_amount"] == "350.50" and depts["IT"]["submitted_count"] == 3
    assert depts["Human Resources"]["pending_finance_amount"] == "75.25" and depts["Human Resources"]["expenditure_amount"] == "0.00"
    assert len(data["recent_transactions"]) == 3   # approved(a), paid(a), approved(b)


def test_report_filters_by_date_department_status(app, world):
    ids = build_known_data(world)
    fin = world["fin"]
    recent = (date.today() - timedelta(days=10)).isoformat()
    s = fin.get(f"/api/corporate/reports/summary?start_date={recent}").json["data"]["summary"]
    assert s["submitted_count"] == 3                                   # the 40-day-old claim is excluded
    old = fin.get(f"/api/corporate/reports/summary?end_date={recent}").json["data"]["summary"]
    assert old["submitted_count"] == 1 and old["paid_count"] == 1
    hr = fin.get(f"/api/corporate/reports/summary?department_id={world['depts']['Human Resources']}").json["data"]["summary"]
    assert hr["submitted_count"] == 1
    listing = fin.get("/api/corporate/expenses?status=rejected,paid").json["data"]
    assert {e["expense_id"] for e in listing["expenses"]} == {ids["a"], ids["d"]}
    assert listing["total_amount"] == "140.00"
    assert fin.get("/api/corporate/expenses?status=bogus").status_code == 400
    assert fin.get("/api/corporate/expenses?start_date=2026-02-01&end_date=2026-01-01").status_code == 400
    assert fin.get("/api/corporate/expenses?search=client").json["data"]["pagination"]["total"] == 4   # all titled "Client lunch"
    assert fin.get("/api/corporate/expenses?search=zzz").json["data"]["pagination"]["total"] == 0
    assert fin.get("/api/corporate/expenses?category=Travel").json["data"]["pagination"]["total"] == 2


def test_role_scoped_dashboards(app, world):
    build_known_data(world)
    employee = world["emp1"].get("/api/corporate/dashboard/employee").json["data"]["summary"]
    assert (employee["submitted_count"], employee["paid_count"], employee["rejected_count"]) == (2, 1, 1)
    manager = world["mgr_it"].get("/api/corporate/dashboard/manager").json["data"]
    assert manager["summary"]["submitted_count"] == 3 and [d["department_name"] for d in manager["departments"]] == ["IT"]
    executive = world["exec"].get("/api/corporate/dashboard/executive").json["data"]
    assert executive["summary"]["submitted_amount"] == "465.75" and len(executive["by_department"]) == 2
    assert sum(Decimal(m["submitted_amount"]) for m in executive["monthly"]) == Decimal("465.75")
    admin = world["admin"].get("/api/corporate/dashboard/admin").json["data"]
    assert admin["counts"]["total_members"] == 8 and admin["counts"]["total_departments"] == 6 and admin["counts"]["total_employees"] == 3
    assert admin["organization"]["organization_code"] == world["code"] and admin["recent_activity"]
    assert world["emp1"].get("/api/corporate/dashboard/manager").status_code == 403
    assert world["mgr_it"].get("/api/corporate/dashboard/finance").status_code == 403
    assert world["fin"].get("/api/corporate/dashboard/executive").status_code == 403


def test_employee_report_exposes_only_own_data_and_manager_scope(app, world):
    build_known_data(world)
    emp_report = world["emp2"].get("/api/corporate/reports/summary").json["data"]
    assert emp_report["summary"]["submitted_count"] == 1 and "by_employee" not in emp_report
    mgr_report = world["mgr_hr"].get("/api/corporate/reports/summary").json["data"]
    assert mgr_report["summary"]["submitted_count"] == 1 and len(mgr_report["by_employee"]) == 1
    assert world["exec"].get("/api/corporate/reports/summary").json["data"]["summary"]["submitted_count"] == 4


def test_csv_export_scope_and_formula_escaping(app, world):
    submit(world["emp1"], title="=HYPERLINK(\"http://evil\")")
    submit(world["emp_hr"], title="HR item")
    csv_text = world["fin"].get("/api/corporate/reports/export").data.decode()
    assert "'=HYPERLINK" in csv_text and "HR item" in csv_text
    assert "HR item" not in world["mgr_it"].get("/api/corporate/reports/export").data.decode()


# ================================================================ personal regression & coexistence
def test_corporate_and_personal_data_stay_separate(app, world):
    submit(world["emp1"], amount="999.00")
    personal = Actor(app)
    assert personal.personal_login("emp1@acme.test").status_code == 200
    category = add_category(app, "Food")
    created = personal.post("/api/expenses", {"amount": "12.50", "date": "2026-02-12", "category_id": category, "description": "Lunch"})
    assert created.status_code == 201
    listing = personal.get("/api/expenses").json["data"]
    assert listing["pagination"]["total"] == 1 and listing["total_amount"] == "12.50"
    assert Expense.query.count() == 1 and CorporateExpense.query.count() == 1
    assert personal.post("/api/income", {"amount": "500.00", "date": "2026-02-01", "source": "Salary"}).status_code == 201
    summary = personal.get("/api/dashboard/summary?month=2&year=2026")
    assert summary.status_code == 200
    assert "999.00" not in str(summary.json)        # corporate amounts never leak into personal figures
    assert personal.get("/api/corporate/expenses").status_code == 403         # personal login is not corporate access
    switched = personal.post("/api/corporate/session/switch", {"mode": "corporate"})
    assert switched.status_code == 200 and switched.json["data"]["mode"] == "corporate"
    assert personal.get("/api/corporate/expenses").json["data"]["pagination"]["total"] == 1
    assert personal.post("/api/corporate/session/switch", {"mode": "personal"}).json["data"]["mode"] == "personal"
    assert personal.get("/api/corporate/expenses").status_code == 403


def test_csrf_still_enforced_on_corporate_mutations(app, world):
    emp = world["emp1"]
    assert emp.client.post("/api/corporate/expenses", json=expense_body()).status_code == 400
    assert Actor(app).client.post("/api/corporate/auth/login", json={"email": "emp1@acme.test", "password": PW}).status_code == 400


def test_init_corporate_db_command_is_additive(app):
    from models import OrganizationAuditLog
    db.session.add(User(name="Keep", email="keep@x.test", password_hash="x"))
    db.session.commit()
    for model in (ExpenseApproval, CorporateExpense, OrganizationAuditLog, OrganizationMembership, Department, Organization):
        model.__table__.drop(db.engine)
    result = app.test_cli_runner().invoke(args=["init-corporate-db"])
    assert result.exit_code == 0 and "organizations" in result.output
    assert User.query.filter_by(email="keep@x.test").count() == 1
    again = app.test_cli_runner().invoke(args=["init-corporate-db"])
    assert "none (already present)" in again.output


# ================================================================ demo data
def test_demo_data_generation_is_correct_and_idempotent(app):
    from services import corporate_demo_service as demo
    real = User(name="Real Person", email="real@example.com")
    real.set_password(PW)
    db.session.add(real)
    db.session.commit()
    summary = demo.seed_demo()
    assert summary["users"] == 20 and summary["expenses"] == demo.EXPENSE_COUNT
    assert demo.seed_demo() is None
    assert Organization.query.filter_by(is_demo=True).count() == 1 and Organization.query.count() == 1
    assert Department.query.count() == 5 and OrganizationMembership.query.count() == 20
    statuses = {e.approval_status for e in CorporateExpense.query}
    assert statuses == {"pending_manager", "pending_finance", "approved", "paid", "rejected"}
    assert OrganizationMembership.query.filter_by(user_id=real.user_id).count() == 0
    dates = [e.expense_date for e in CorporateExpense.query]
    assert (max(dates) - min(dates)).days >= 60 and max(dates) <= date.today()
    for e in CorporateExpense.query.limit(50):
        assert e.department_id == OrganizationMembership.query.filter_by(user_id=e.user_id).one().department_id
        assert e.approvals[0].previous_status is None and e.approvals[-1].new_status == e.approval_status
    # demo accounts can log in and see data computed from the records
    cfo = login_as(app, "ananya.iyer@northwind-demo.example", "Demo@12345")
    total = cfo.get("/api/corporate/dashboard/executive").json["data"]["summary"]["submitted_count"]
    assert total == demo.EXPENSE_COUNT
    assert login_as(app, "arjun.rao@northwind-demo.example", "Demo@12345").get("/api/corporate/dashboard/manager").status_code == 200
    # cleanup removes demo rows only
    removed = demo.cleanup_demo()
    assert removed["expenses"] == demo.EXPENSE_COUNT and Organization.query.count() == 0
    assert User.query.count() == 1 and User.query.one().email == "real@example.com"
