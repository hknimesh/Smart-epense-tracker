# MySQL Database

The schema contains the existing Phase 2 `user` and `category` tables, `expenses`, `income`, and `budgets`. Income and budget records reference their owning user; budgets can optionally reference a category. Category deletion is blocked while expenses or budgets reference that category. The singular existing table names are retained to preserve Phase 2 database data. Budget records are unique by user, category (including an overall-budget scope), month, and year.

Create a local database and least-privilege application account in MySQL:

```sql
CREATE DATABASE smart_expense_tracking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'smart_expense_user'@'localhost' IDENTIFIED BY 'choose-a-local-password';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
	ON smart_expense_tracking.* TO 'smart_expense_user'@'localhost';
FLUSH PRIVILEGES;
```

Copy `backend/.env.example` to `backend/.env`, set the connection values and a long random `SECRET_KEY`, then run `python -m flask --app app init-db` from the `backend` directory. This command creates missing tables and seeds the predefined categories idempotently without resetting existing tables. Set `ADMIN_EMAILS` to a comma-separated list of existing account email addresses authorized to manage categories. Never commit the real `.env` file.


## Corporate tables (Phase 1)

Corporate Expense Management adds six **new** tables and changes none of the existing ones: `organizations`, `departments`, `organization_memberships`, `corporate_expenses`, `expense_approvals`, `organization_audit_logs`.

- Existing database with data: `python -m flask --app app init-corporate-db` (from `backend`), or run `database/migrations/001_add_corporate_tables.sql`. Both are additive and safe to re-run.
- New database: `python -m flask --app app init-db` creates everything.
- The least-privilege account above already has the required privileges (`CREATE`, `INDEX`, `REFERENCES`, DML).
- Corporate role is stored per membership (`organization_memberships.role`), never on `user`. Amounts are `DECIMAL(12,2)`.
- Optional demonstration data: `python -m flask --app app seed-corporate-demo` (see the main README; `--cleanup` removes only the demo organization).
