-- Smart Expense Tracker: Phase 1 corporate tables (MySQL 8 / InnoDB, utf8mb4).
-- ADDITIVE ONLY: creates six new tables if they do not exist. It never alters, drops or
-- deletes anything, so existing personal tables and data are untouched.
-- Requires the existing `user` table (created by `flask --app app init-db`).
-- Safe to run more than once. The Flask command `flask --app app init-corporate-db`
-- does the same thing and is the recommended way; this file is for manual/DBA use.
-- Generated from the SQLAlchemy models in backend/models.

CREATE TABLE IF NOT EXISTS organizations (
	organization_id INTEGER NOT NULL AUTO_INCREMENT, 
	organization_name VARCHAR(150) NOT NULL, 
	organization_code VARCHAR(16) NOT NULL, 
	organization_email VARCHAR(254) NOT NULL, 
	contact_phone VARCHAR(30), 
	address VARCHAR(300), 
	status VARCHAR(20) NOT NULL, 
	joining_enabled BOOL NOT NULL, 
	is_demo BOOL NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (organization_id), 
	CONSTRAINT ck_organizations_status CHECK (status IN ('active', 'inactive')),
	UNIQUE INDEX ix_organizations_organization_code (organization_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
	department_id INTEGER NOT NULL AUTO_INCREMENT, 
	organization_id INTEGER NOT NULL, 
	department_name VARCHAR(100) NOT NULL, 
	manager_id INTEGER, 
	status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (department_id), 
	CONSTRAINT uq_departments_org_name UNIQUE (organization_id, department_name), 
	CONSTRAINT ck_departments_status CHECK (status IN ('active', 'inactive')), 
	FOREIGN KEY(organization_id) REFERENCES organizations (organization_id) ON DELETE RESTRICT, 
	FOREIGN KEY(manager_id) REFERENCES user (user_id) ON DELETE SET NULL,
	INDEX ix_departments_manager_id (manager_id),
	INDEX ix_departments_organization_id (organization_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS organization_memberships (
	membership_id INTEGER NOT NULL AUTO_INCREMENT, 
	organization_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	department_id INTEGER, 
	`role` VARCHAR(30) NOT NULL, 
	membership_status VARCHAR(20) NOT NULL, 
	joined_at DATETIME NOT NULL, 
	PRIMARY KEY (membership_id), 
	CONSTRAINT uq_memberships_org_user UNIQUE (organization_id, user_id), 
	CONSTRAINT ck_memberships_role CHECK (role IN ('org_admin', 'employee', 'manager', 'finance_officer', 'executive')), 
	CONSTRAINT ck_memberships_status CHECK (membership_status IN ('active', 'inactive')), 
	FOREIGN KEY(organization_id) REFERENCES organizations (organization_id) ON DELETE RESTRICT, 
	FOREIGN KEY(user_id) REFERENCES user (user_id) ON DELETE CASCADE, 
	FOREIGN KEY(department_id) REFERENCES departments (department_id) ON DELETE SET NULL,
	INDEX ix_memberships_org_role (organization_id, role),
	INDEX ix_organization_memberships_department_id (department_id),
	INDEX ix_organization_memberships_organization_id (organization_id),
	INDEX ix_organization_memberships_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS corporate_expenses (
	expense_id INTEGER NOT NULL AUTO_INCREMENT, 
	organization_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	department_id INTEGER NOT NULL, 
	title VARCHAR(200) NOT NULL, 
	description VARCHAR(1000), 
	amount NUMERIC(12, 2) NOT NULL, 
	category VARCHAR(60) NOT NULL, 
	vendor VARCHAR(160), 
	payment_method VARCHAR(40), 
	receipt_path VARCHAR(255), 
	receipt_filename VARCHAR(255), 
	expense_date DATE NOT NULL, 
	approval_status VARCHAR(30) NOT NULL, 
	rejection_reason VARCHAR(500), 
	paid_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (expense_id), 
	CONSTRAINT ck_corporate_expenses_positive_amount CHECK (amount > 0), 
	CONSTRAINT ck_corporate_expenses_status CHECK (approval_status IN ('pending_manager', 'pending_finance', 'rejected', 'approved', 'paid')), 
	FOREIGN KEY(organization_id) REFERENCES organizations (organization_id) ON DELETE RESTRICT, 
	FOREIGN KEY(user_id) REFERENCES user (user_id) ON DELETE RESTRICT, 
	FOREIGN KEY(department_id) REFERENCES departments (department_id) ON DELETE RESTRICT,
	INDEX ix_corp_exp_org_date (organization_id, expense_date),
	INDEX ix_corp_exp_org_dept (organization_id, department_id),
	INDEX ix_corp_exp_org_status (organization_id, approval_status),
	INDEX ix_corp_exp_org_user (organization_id, user_id),
	INDEX ix_corporate_expenses_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS expense_approvals (
	approval_id INTEGER NOT NULL AUTO_INCREMENT, 
	expense_id INTEGER NOT NULL, 
	reviewer_id INTEGER NOT NULL, 
	previous_status VARCHAR(30), 
	new_status VARCHAR(30) NOT NULL, 
	comments VARCHAR(500), 
	action_date DATETIME NOT NULL, 
	PRIMARY KEY (approval_id), 
	FOREIGN KEY(expense_id) REFERENCES corporate_expenses (expense_id) ON DELETE CASCADE, 
	FOREIGN KEY(reviewer_id) REFERENCES user (user_id) ON DELETE RESTRICT,
	INDEX ix_expense_approvals_action_date (action_date),
	INDEX ix_expense_approvals_expense_id (expense_id),
	INDEX ix_expense_approvals_reviewer_id (reviewer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS organization_audit_logs (
	log_id INTEGER NOT NULL AUTO_INCREMENT, 
	organization_id INTEGER NOT NULL, 
	actor_id INTEGER, 
	action VARCHAR(60) NOT NULL, 
	details VARCHAR(500), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (log_id), 
	FOREIGN KEY(organization_id) REFERENCES organizations (organization_id) ON DELETE RESTRICT, 
	FOREIGN KEY(actor_id) REFERENCES user (user_id) ON DELETE SET NULL,
	INDEX ix_audit_org_created (organization_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
