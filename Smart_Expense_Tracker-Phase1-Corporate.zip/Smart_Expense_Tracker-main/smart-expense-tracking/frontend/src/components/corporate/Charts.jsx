import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatMoney } from './format';

const compact = (value) => new Intl.NumberFormat('en-IN', { notation: 'compact', maximumFractionDigits: 1 }).format(value);

export function DepartmentChart({ data, dataKey = 'expenditure_amount', label = 'Expenditure' }) {
	const rows = data.map(row => ({ name: row.department_name, value: Number(row[dataKey]) }));
	if (!rows.length) return <p className="corp-empty">No department data yet.</p>;
	return <div className="corp-chart" role="img" aria-label={`${label} by department`}><ResponsiveContainer width="100%" height={260}>
		<BarChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} /><YAxis tickFormatter={compact} tick={{ fontSize: 11 }} width={48} /><Tooltip formatter={value => formatMoney(value)} /><Bar dataKey="value" name={label} fill="#635bff" radius={[5, 5, 0, 0]} /></BarChart>
	</ResponsiveContainer></div>;
}

export function MonthlyChart({ data }) {
	const rows = data.map(row => ({ name: row.label, Submitted: Number(row.submitted_amount), Expenditure: Number(row.expenditure_amount) }));
	if (!rows.length) return <p className="corp-empty">No monthly data yet.</p>;
	return <div className="corp-chart" role="img" aria-label="Monthly submitted amount and expenditure"><ResponsiveContainer width="100%" height={260}>
		<LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tickFormatter={compact} tick={{ fontSize: 11 }} width={48} /><Tooltip formatter={value => formatMoney(value)} /><Legend /><Line type="monotone" dataKey="Submitted" stroke="#2681d8" strokeWidth={2} dot={{ r: 3 }} /><Line type="monotone" dataKey="Expenditure" stroke="#15915a" strokeWidth={2} dot={{ r: 3 }} /></LineChart>
	</ResponsiveContainer></div>;
}
