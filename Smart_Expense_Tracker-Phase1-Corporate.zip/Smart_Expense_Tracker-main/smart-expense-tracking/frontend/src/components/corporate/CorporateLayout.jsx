import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import UserAvatar from '../UserAvatar';
import { NAV } from './format';

export default function CorporateLayout({ children }) {
	const { user, membership, memberships, logout, switchMode } = useAuth();
	const navigate = useNavigate();
	const links = NAV[membership?.role] || [];
	const org = membership?.organization;
	const signOut = async () => { if (await logout()) navigate('/login'); };
	const goPersonal = async () => { await switchMode('personal'); navigate('/dashboard'); };
	const otherOrgs = memberships.filter(m => m.organization_id !== membership?.organization_id);
	const switchOrg = async (id) => { await switchMode('corporate', id); navigate('/corporate'); };

	return <div className="app-shell corp-shell">
		<aside className="sidebar">
			<div className="brand"><span className="brand-mark">₹</span><span>SmartExpense</span></div>
			<div className="corp-org"><small>Corporate</small><strong>{org?.organization_name}</strong><span>{membership?.role_label}</span></div>
			<nav>{links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/corporate'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}</nav>
			<button className="logout" onClick={goPersonal}>Switch to Personal</button>
			<button className="logout" style={{ marginTop: 0 }} onClick={signOut}>Logout</button>
		</aside>
		<div className="main-area">
			<header className="navbar">
				<div><span className="mobile-brand">SmartExpense</span><h1>{org?.organization_name}</h1><p>{user?.name} · {membership?.role_label}{membership?.department_name ? ` · ${membership.department_name}` : ''}</p></div>
				<details className="profile-menu"><summary aria-label="Open account menu"><UserAvatar user={user} /></summary>
					<div className="profile-menu-popover"><strong>{user?.name}</strong><span>{user?.email}</span>
						{otherOrgs.map(m => <button key={m.organization_id} type="button" onClick={() => switchOrg(m.organization_id)}>Switch to {m.organization_name}</button>)}
						<button type="button" onClick={goPersonal}>Personal Finance</button><button type="button" onClick={signOut}>Log out</button></div></details>
			</header>
			{org?.is_demo && <div className="corp-demo-banner" role="note">Demonstration data: this organization and its records are fictional.</div>}
			<main className="page-content">{children}</main>
		</div>
	</div>;
}
