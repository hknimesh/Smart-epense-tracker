export default function DashboardState({ loading, error, onRetry, children }) {
	if (loading) return <div className="panel corp-empty" role="status">Loading...</div>;
	if (error) return <div className="panel"><div className="form-error" role="alert">{error}</div>{onRetry && <button type="button" className="secondary-btn" onClick={onRetry}>Try again</button>}</div>;
	return children;
}
