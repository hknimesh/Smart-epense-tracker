import { useEffect, useState } from 'react';
import { corporateApi, getApiErrorMessage } from '../../services/api';
import StatusBadge from './StatusBadge';
import ExpenseEditForm from './ExpenseEditForm';
import { formatDate, formatDateTime, formatMoney } from './format';

export default function ExpenseDetailModal({ expenseId, canEdit = false, onClose, onChanged }) {
	const [expense, setExpense] = useState(null);
	const [error, setError] = useState('');
	const [editing, setEditing] = useState(false);

	useEffect(() => {
		let active = true;
		corporateApi.expense(expenseId).then(response => { if (active) setExpense(response.data.data.expense); }).catch(requestError => { if (active) setError(getApiErrorMessage(requestError)); });
		return () => { active = false; };
	}, [expenseId]);
	useEffect(() => {
		const onKey = event => { if (event.key === 'Escape') onClose(); };
		document.addEventListener('keydown', onKey);
		return () => document.removeEventListener('keydown', onKey);
	}, [onClose]);

	const openReceipt = async () => {
		try {
			const response = await corporateApi.receipt(expenseId);
			window.open(URL.createObjectURL(response.data), '_blank', 'noopener');
		} catch (requestError) { setError(getApiErrorMessage(requestError, 'Could not open the receipt.')); }
	};

	return <div className="corp-modal-backdrop" role="presentation" onClick={event => { if (event.target === event.currentTarget) onClose(); }}>
		<div className="corp-modal" role="dialog" aria-modal="true" aria-label="Expense details">
			<div className="corp-modal-head"><h3>{expense?.title || 'Expense details'}</h3><button type="button" className="text-btn" onClick={onClose} aria-label="Close">Close</button></div>
			{error && <div className="form-error" role="alert">{error}</div>}
			{!expense && !error && <p className="muted">Loading...</p>}
			{expense && editing && <ExpenseEditForm expense={expense} onCancel={() => setEditing(false)} onSaved={(updated) => { setExpense(updated); setEditing(false); onChanged?.(); }} />}
			{expense && !editing && <>
				<dl className="corp-detail">
					<div><dt>Status</dt><dd><StatusBadge status={expense.approval_status} /></dd></div>
					<div><dt>Amount</dt><dd>{formatMoney(expense.amount)}</dd></div>
					<div><dt>Date</dt><dd>{formatDate(expense.expense_date)}</dd></div>
					<div><dt>Employee</dt><dd>{expense.employee_name}</dd></div>
					<div><dt>Department</dt><dd>{expense.department_name}</dd></div>
					<div><dt>Category</dt><dd>{expense.category}</dd></div>
					<div><dt>Vendor</dt><dd>{expense.vendor || '—'}</dd></div>
					<div><dt>Payment method</dt><dd>{expense.payment_method || '—'}</dd></div>
					{expense.paid_at && <div><dt>Paid on</dt><dd>{formatDateTime(expense.paid_at)}</dd></div>}
				</dl>
				{expense.description && <p className="corp-desc">{expense.description}</p>}
				{expense.rejection_reason && <div className="form-error">Rejection reason: {expense.rejection_reason}</div>}
				{expense.has_receipt && <button type="button" className="secondary-btn" onClick={openReceipt}>View receipt ({expense.receipt_filename})</button>}
				<h4>Approval history</h4>
				<ol className="corp-timeline">{expense.history.map(item => <li key={item.approval_id}><strong>{item.new_status_label}</strong> <span>by {item.reviewer_name}</span><small>{formatDateTime(item.action_date)}</small>{item.comments && <em>{item.comments}</em>}</li>)}</ol>
				{canEdit && expense.approval_status === 'pending_manager' && <div className="corp-modal-actions"><button type="button" className="secondary-btn" onClick={() => setEditing(true)}>Edit expense</button></div>}
			</>}
		</div>
	</div>;
}
