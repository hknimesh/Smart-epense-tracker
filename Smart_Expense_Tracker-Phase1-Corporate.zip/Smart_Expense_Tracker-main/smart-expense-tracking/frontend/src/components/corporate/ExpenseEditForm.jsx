import { useState } from 'react';
import { corporateApi, getApiErrorMessage } from '../../services/api';
import useCorporateMeta from './useCorporateMeta';
import { localDate } from './format';

/** Create (no `expense`) or edit (with `expense`) form. Department is derived by the server. */
export default function ExpenseEditForm({ expense, onSaved, onCancel }) {
	const meta = useCorporateMeta();
	const [form, setForm] = useState({
		title: expense?.title || '', description: expense?.description || '', amount: expense?.amount || '',
		expense_date: expense?.expense_date || localDate(), category: expense?.category || '',
		vendor: expense?.vendor || '', payment_method: expense?.payment_method || '',
	});
	const [receipt, setReceipt] = useState(null);
	const [error, setError] = useState('');
	const [fieldErrors, setFieldErrors] = useState({});
	const [saving, setSaving] = useState(false);
	const update = key => event => setForm({ ...form, [key]: event.target.value });

	const submit = async (event) => {
		event.preventDefault();
		setError(''); setFieldErrors({});
		if (receipt && receipt.size > 5 * 1024 * 1024) { setFieldErrors({ receipt: 'Receipt must be 5 MB or smaller.' }); return; }
		setSaving(true);
		try {
			const response = expense
				? await corporateApi.updateExpense(expense.expense_id, form)
				: await corporateApi.createExpense(form, receipt);
			onSaved(response.data.data.expense, response.data.message);
		} catch (requestError) {
			setFieldErrors(requestError.response?.data?.errors || {});
			setError(getApiErrorMessage(requestError));
		} finally { setSaving(false); }
	};
	const err = key => fieldErrors[key] && <span className="field-error">{fieldErrors[key]}</span>;

	return <form className="corp-form" onSubmit={submit}>
		{error && <div className="form-error" role="alert">{error}</div>}
		<label className="corp-field">Title<input value={form.title} onChange={update('title')} maxLength={200} required />{err('title')}</label>
		<div className="corp-form-row">
			<label className="corp-field">Amount (₹)<input type="number" inputMode="decimal" step="0.01" min="0.01" value={form.amount} onChange={update('amount')} required />{err('amount')}</label>
			<label className="corp-field">Date<input type="date" max={localDate()} value={form.expense_date} onChange={update('expense_date')} required />{err('expense_date')}</label>
		</div>
		<div className="corp-form-row">
			<label className="corp-field">Category<select value={form.category} onChange={update('category')} required><option value="">Select category</option>{meta.categories.map(c => <option key={c} value={c}>{c}</option>)}</select>{err('category')}</label>
			<label className="corp-field">Payment method<select value={form.payment_method} onChange={update('payment_method')}><option value="">Select method</option>{meta.payment_methods.map(c => <option key={c} value={c}>{c}</option>)}</select>{err('payment_method')}</label>
		</div>
		<label className="corp-field">Vendor<input value={form.vendor} onChange={update('vendor')} maxLength={160} />{err('vendor')}</label>
		<label className="corp-field">Description<textarea rows={3} value={form.description} onChange={update('description')} maxLength={1000} />{err('description')}</label>
		{!expense && <label className="corp-field">Receipt (optional, PDF/PNG/JPG up to 5 MB)<input type="file" accept=".pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg" onChange={event => setReceipt(event.target.files?.[0] || null)} />{err('receipt')}</label>}
		{err('department_id')}
		<div className="corp-modal-actions">{onCancel && <button type="button" className="secondary-btn" onClick={onCancel} disabled={saving}>Cancel</button>}<button className="primary-btn" type="submit" disabled={saving}>{saving ? 'Saving...' : expense ? 'Save changes' : 'Submit expense'}</button></div>
	</form>;
}
