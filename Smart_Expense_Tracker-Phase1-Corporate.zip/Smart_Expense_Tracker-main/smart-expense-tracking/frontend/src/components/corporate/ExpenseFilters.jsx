import useCorporateMeta from './useCorporateMeta';

export const emptyFilters = { search: '', status: '', department_id: '', user_id: '', category: '', start_date: '', end_date: '' };

export default function ExpenseFilters({ value, onChange, departments = [], employees = [], hideDepartment = false, compact = false }) {
	const meta = useCorporateMeta();
	const set = (key) => (event) => onChange({ ...value, [key]: event.target.value });
	return <div className="corp-filters">
		{!compact && <label>Search<input value={value.search} onChange={set('search')} placeholder="Title or vendor" /></label>}
		<label>Status<select value={value.status} onChange={set('status')}><option value="">All statuses</option>{meta.statuses.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}</select></label>
		{!hideDepartment && departments.length > 1 && <label>Department<select value={value.department_id} onChange={set('department_id')}><option value="">All departments</option>{departments.map(d => <option key={d.department_id} value={d.department_id}>{d.department_name}</option>)}</select></label>}
		{employees.length > 0 && <label>Employee<select value={value.user_id} onChange={set('user_id')}><option value="">All employees</option>{employees.map(e => <option key={e.user_id} value={e.user_id}>{e.employee_name}</option>)}</select></label>}
		{!compact && <label>Category<select value={value.category} onChange={set('category')}><option value="">All categories</option>{meta.categories.map(c => <option key={c} value={c}>{c}</option>)}</select></label>}
		<label>From<input type="date" value={value.start_date} onChange={set('start_date')} /></label>
		<label>To<input type="date" value={value.end_date} onChange={set('end_date')} /></label>
		<button type="button" className="secondary-btn" onClick={() => onChange(emptyFilters)}>Reset</button>
	</div>;
}
