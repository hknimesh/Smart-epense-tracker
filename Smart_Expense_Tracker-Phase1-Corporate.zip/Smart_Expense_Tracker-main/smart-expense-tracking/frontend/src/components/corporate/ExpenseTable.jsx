import StatusBadge from './StatusBadge';
import { formatDate, formatMoney } from './format';

export default function ExpenseTable({ expenses, onView, showEmployee = true, showDepartment = true, renderActions, empty = 'No expenses match the current filters.' }) {
	if (!expenses.length) return <p className="corp-empty">{empty}</p>;
	return <div className="corp-table-wrap"><table className="corp-table">
		<thead><tr><th>Date</th><th>Title</th>{showEmployee && <th>Employee</th>}{showDepartment && <th>Department</th>}<th>Category</th><th className="num">Amount</th><th>Status</th><th><span className="sr-only">Actions</span></th></tr></thead>
		<tbody>{expenses.map(expense => <tr key={expense.expense_id}>
			<td>{formatDate(expense.expense_date)}</td>
			<td><button type="button" className="corp-link" onClick={() => onView?.(expense)}>{expense.title}</button>{expense.vendor && <small className="corp-sub">{expense.vendor}</small>}</td>
			{showEmployee && <td>{expense.employee_name}</td>}{showDepartment && <td>{expense.department_name}</td>}
			<td>{expense.category}</td><td className="num">{formatMoney(expense.amount)}</td><td><StatusBadge status={expense.approval_status} /></td>
			<td className="corp-actions">{renderActions ? renderActions(expense) : <button type="button" className="text-btn" onClick={() => onView?.(expense)}>View</button>}</td>
		</tr>)}</tbody>
	</table></div>;
}
