export default function Pager({ pagination, onPage }) {
	if (!pagination || pagination.pages <= 1) return null;
	return <div className="corp-pager"><button type="button" className="secondary-btn" disabled={pagination.page <= 1} onClick={() => onPage(pagination.page - 1)}>Previous</button><span>Page {pagination.page} of {pagination.pages} · {pagination.total} records</span><button type="button" className="secondary-btn" disabled={pagination.page >= pagination.pages} onClick={() => onPage(pagination.page + 1)}>Next</button></div>;
}
