import { useEffect, useRef, useState } from 'react';

export default function ReasonDialog({ title, message, confirmLabel = 'Reject', requireReason = true, busy, error, onCancel, onConfirm }) {
	const [reason, setReason] = useState('');
	const ref = useRef(null);
	useEffect(() => { ref.current?.focus(); }, []);
	useEffect(() => {
		const onKey = event => { if (event.key === 'Escape' && !busy) onCancel(); };
		document.addEventListener('keydown', onKey);
		return () => document.removeEventListener('keydown', onKey);
	}, [busy, onCancel]);
	const invalid = requireReason && reason.trim().length < 3;
	return <div className="corp-modal-backdrop" role="presentation"><div className="corp-modal small" role="dialog" aria-modal="true" aria-label={title}>
		<h3>{title}</h3><p className="muted">{message}</p>
		{error && <div className="form-error" role="alert">{error}</div>}
		<label className="corp-field">{requireReason ? 'Reason (required)' : 'Comments (optional)'}<textarea ref={ref} value={reason} maxLength={500} rows={4} onChange={event => setReason(event.target.value)} /></label>
		<div className="corp-modal-actions"><button type="button" className="secondary-btn" onClick={onCancel} disabled={busy}>Cancel</button><button type="button" className="corp-danger" disabled={busy || invalid} onClick={() => onConfirm(reason.trim())}>{busy ? 'Saving...' : confirmLabel}</button></div>
	</div></div>;
}
