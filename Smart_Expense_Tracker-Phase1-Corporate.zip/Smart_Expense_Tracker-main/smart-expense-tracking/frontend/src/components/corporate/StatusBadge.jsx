const LABELS = { pending_manager: 'Pending Manager Approval', pending_finance: 'Pending Finance Verification', approved: 'Approved', paid: 'Paid', rejected: 'Rejected' };
export default function StatusBadge({ status }) {
	return <span className={`corp-badge corp-badge-${status}`}>{LABELS[status] || status}</span>;
}
