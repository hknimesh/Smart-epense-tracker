const money = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' });
export const formatMoney = (value) => money.format(Number(value || 0));
export const formatDate = (value) => (value ? new Date(value.length === 10 ? `${value}T00:00:00` : value).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
export const formatDateTime = (value) => (value ? new Date(value).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');
export const localDate = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };

// Navigation per role. The server enforces permissions independently of this list.
export const NAV = {
	org_admin: [['/corporate', 'Overview'], ['/corporate/employees', 'Employees'], ['/corporate/departments', 'Departments'], ['/corporate/settings', 'Organization Settings']],
	employee: [['/corporate', 'Dashboard'], ['/corporate/submit', 'Submit Expense'], ['/corporate/expenses', 'My Expenses'], ['/corporate/reimbursements', 'Reimbursements'], ['/corporate/profile', 'Profile']],
	manager: [['/corporate', 'Overview'], ['/corporate/team', 'Team Expenses'], ['/corporate/approvals', 'Approvals'], ['/corporate/department-expenses', 'Department Expenses']],
	finance_officer: [['/corporate', 'Overview'], ['/corporate/expenses', 'Corporate Expenses'], ['/corporate/approvals', 'Verification'], ['/corporate/reimbursements', 'Reimbursements'], ['/corporate/reports', 'Reports']],
	executive: [['/corporate', 'Overview'], ['/corporate/expenses', 'Company Expenses'], ['/corporate/departments', 'Departments'], ['/corporate/reports', 'Financial Reports']],
};
