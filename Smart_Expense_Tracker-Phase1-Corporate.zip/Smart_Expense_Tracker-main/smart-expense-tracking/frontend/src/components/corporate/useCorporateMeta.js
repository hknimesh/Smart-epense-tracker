import { useEffect, useState } from 'react';
import { corporateApi } from '../../services/api';

let cached = null;
export default function useCorporateMeta() {
	const [meta, setMeta] = useState(cached || { categories: [], payment_methods: [], statuses: [], roles: [] });
	useEffect(() => {
		if (cached) return undefined;
		let active = true;
		corporateApi.meta().then(response => { cached = response.data.data; if (active) setMeta(cached); }).catch(() => {});
		return () => { active = false; };
	}, []);
	return meta;
}
