import { useCallback, useEffect, useState } from 'react';
import { getApiErrorMessage } from '../../services/api';

/** Runs `fn` on mount and whenever `deps` change. Returns { data, loading, error, reload }. */
export default function useLoader(fn, deps = []) {
	const [state, setState] = useState({ data: null, loading: true, error: '' });
	const [tick, setTick] = useState(0);
	const reload = useCallback(() => setTick(value => value + 1), []);
	useEffect(() => {
		let active = true;
		setState(previous => ({ ...previous, loading: true, error: '' }));
		fn().then(data => { if (active) setState({ data, loading: false, error: '' }); })
			.catch(requestError => { if (active) setState({ data: null, loading: false, error: getApiErrorMessage(requestError) }); });
		return () => { active = false; };
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [...deps, tick]);
	return { ...state, reload };
}
