import { createContext, useContext, useEffect, useState } from 'react';
import { api, corporateApi, ensureCsrfToken, setCsrfToken } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  // Corporate session state. `mode` is 'personal' or 'corporate'; the role always comes from the server.
  const [mode, setMode] = useState('personal');
  const [membership, setMembership] = useState(null);
  const [memberships, setMemberships] = useState([]);

  const applySession = (data) => {
    setMode(data?.mode === 'corporate' && data.membership ? 'corporate' : 'personal');
    setMembership(data?.membership || null);
    setMemberships(data?.memberships || []);
  };

  const loadCorporateSession = async () => {
    try {
      const response = await corporateApi.session();
      applySession(response.data.data);
    } catch {
      applySession(null);
    }
  };

  const refreshProfile = async () => {
    const response = await api.get('/auth/me');
    setUser(response.data.data.user);
    return response.data.data.user;
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await ensureCsrfToken();
        const response = await api.get('/auth/me');
        if (mounted) setUser(response.data.data.user);
        try {
          const session = await corporateApi.session();
          if (mounted) applySession(session.data.data);
        } catch { /* corporate session is optional */ }
      } catch (bootstrapError) {
        if (mounted) {
          setUser(null);
          if (bootstrapError.response?.status !== 401) {
            setError(bootstrapError.response?.data?.message || 'Unable to reach the server. Check that the backend is running.');
          }
        }
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  const login = async (email, password, remember = false) => {
    setError('');
    try {
      const response = await api.post('/auth/login', { email, password, remember });
      setCsrfToken(response.data.data.csrf_token);
      setUser(response.data.data.user);
      setMode('personal');
      setMembership(null);
      loadCorporateSession();
      return response.data.data.user;
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'Unable to reach the server. Check that the backend is running.');
      throw requestError;
    }
  };

  // Corporate login: one endpoint for every role; the role is read from the database by the server.
  const corporateLogin = async (email, password, remember = false, organizationId) => {
    setError('');
    try {
      const payload = { email, password, remember };
      if (organizationId) payload.organization_id = Number(organizationId);
      const response = await corporateApi.login(payload);
      setCsrfToken(response.data.data.csrf_token);
      setUser(response.data.data.user);
      setMode('corporate');
      setMembership(response.data.data.membership);
      setMemberships(response.data.data.memberships || []);
      return response.data.data.membership;
    } catch (requestError) {
      if (requestError.response?.data?.errors?.organization_required) throw requestError;
      setError(requestError.response?.data?.message || 'Unable to reach the server. Check that the backend is running.');
      throw requestError;
    }
  };

  const switchMode = async (nextMode, organizationId) => {
    const payload = { mode: nextMode };
    if (organizationId) payload.organization_id = organizationId;
    const response = await corporateApi.switchMode(payload);
    applySession(response.data.data);
    return response.data.data;
  };

  const register = async (name, email, password) => {
    setError('');
    try {
      return await api.post('/auth/register', { name, email, password });
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'Unable to reach the server. Check that the backend is running.');
      throw requestError;
    }
  };

  const logout = async () => {
    try {
      const response = await api.post('/auth/logout');
      setCsrfToken(response.data.data.csrf_token);
      setUser(null);
      applySession(null);
      return true;
    } catch (requestError) {
      setError(requestError.response?.data?.message || 'Could not contact the server to end the session.');
      return false;
    }
  };

  const clearError = () => setError('');
  const role = mode === 'corporate' ? membership?.role || null : null;
  return <AuthContext.Provider value={{ user, loading, error, mode, membership, memberships, role, login, corporateLogin, switchMode, register, logout, refreshProfile, clearError }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
