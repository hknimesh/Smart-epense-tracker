import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { corporateApi, getApiErrorMessage } from '../services/api';
import '../styles/corporate.css';

export default function JoinOrganization() {
	const [form, setForm] = useState({ name: '', email: '', password: '', organization_code: '' });
	const [error, setError] = useState('');
	const [fieldErrors, setFieldErrors] = useState({});
	const [submitting, setSubmitting] = useState(false);
	const navigate = useNavigate();
	const update = event => setForm({ ...form, [event.target.name]: event.target.value });

	const submit = async (event) => {
		event.preventDefault();
		setError(''); setFieldErrors({});
		setSubmitting(true);
		try {
			const response = await corporateApi.join(form);
			navigate('/login', { replace: true, state: { message: response.data.message } });
		} catch (requestError) {
			setFieldErrors(requestError.response?.data?.errors || {});
			setError(getApiErrorMessage(requestError));
		} finally {
			setSubmitting(false);
		}
	};
	const field = (name, label, props = {}) => <label>{label}<input name={name} value={form[name]} onChange={update} {...props} />{fieldErrors[name] && <span className="field-error">{fieldErrors[name]}</span>}</label>;

	return <div className="auth-page"><div className="auth-card">
		<div className="auth-brand"><span>₹</span><strong>SmartExpense</strong></div>
		<h1>Join an organization</h1><p className="muted">Enter the organization code from your administrator. You will join as an Employee; your administrator assigns your department and any other role.</p>
		{error && <div className="form-error" role="alert">{error}</div>}
		<form onSubmit={submit}>
			{field('name', 'Full name', { required: true, maxLength: 120, autoComplete: 'name' })}
			{field('email', 'Email', { type: 'email', required: true, autoComplete: 'email' })}
			{field('password', 'Password', { type: 'password', required: true, minLength: 8, maxLength: 128, autoComplete: 'new-password' })}
			{field('organization_code', 'Organization code', { required: true, maxLength: 20, placeholder: 'e.g. ABC7K2M9Q', autoCapitalize: 'characters' })}
			<p className="muted small">Already use SmartExpense personally? Enter your existing email and password: your personal account is reused, not duplicated.</p>
			<button className="primary-btn" type="submit" disabled={submitting}>{submitting ? 'Joining...' : 'Join organization'}</button>
		</form>
		<p className="auth-footer"><Link to="/login">Back to Login</Link></p>
	</div></div>;
}
