import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/corporate.css';

export default function Login() {
	const [kind, setKind] = useState('personal');
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [remember, setRemember] = useState(false);
	const [show, setShow] = useState(false);
	const [error, setError] = useState('');
	const [submitting, setSubmitting] = useState(false);
	const [organizations, setOrganizations] = useState([]);
	const [organizationId, setOrganizationId] = useState('');
	const { login, corporateLogin, clearError, error: authError } = useAuth();
	const navigate = useNavigate();
	const location = useLocation();
	const corporate = kind === 'corporate';

	const choose = (next) => { setKind(next); setError(''); setOrganizations([]); setOrganizationId(''); clearError(); };

	const submit = async (event) => {
		event.preventDefault();
		setError('');
		clearError();
		if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email) || !password) {
			setError('Enter a valid email address and your password.');
			return;
		}
		if (organizations.length && !organizationId) {
			setError('Select the organization you want to sign in to.');
			return;
		}
		setSubmitting(true);
		try {
			if (corporate) {
				await corporateLogin(email, password, remember, organizationId);
				navigate('/corporate', { replace: true });
			} else {
				await login(email, password, remember);
				navigate('/dashboard', { replace: true });
			}
		} catch (requestError) {
			const data = requestError.response?.data;
			if (data?.errors?.organization_required) {
				setOrganizations(data.errors.organizations);
				setError(data.message);
			} else {
				setError(data?.message || 'Unable to reach the server. Check that the backend is running.');
			}
		} finally {
			setSubmitting(false);
		}
	};

	return <div className="auth-page"><div className="auth-card">
		<div className="auth-brand"><span>₹</span><strong>SmartExpense</strong></div>
		<h1>Welcome back</h1>
		<div className="mode-picker" role="tablist" aria-label="Choose how you want to sign in">
			<button type="button" role="tab" aria-selected={!corporate} className={!corporate ? 'mode-option active' : 'mode-option'} onClick={() => choose('personal')}><strong>Personal Finance</strong><small>Manage personal income, expenses and budgets.</small></button>
			<button type="button" role="tab" aria-selected={corporate} className={corporate ? 'mode-option active' : 'mode-option'} onClick={() => choose('corporate')}><strong>Corporate Finance</strong><small>Manage organizational expenses and financial operations.</small></button>
		</div>
		<p className="muted">{corporate ? 'Sign in with your organization account. Your role is assigned by your organization.' : 'Sign in to your personal finance dashboard.'}</p>
		{location.state?.message && <div className="form-success" role="status">{location.state.message}</div>}
		{(error || authError) && <div className="form-error" role="alert">{error || authError}</div>}
		<form onSubmit={submit}>
			<label>Email<input type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" autoComplete="email" required /></label>
			<label>Password<div className="password-wrap"><input type={show ? 'text' : 'password'} value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter your password" autoComplete="current-password" required /><button type="button" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>{show ? 'Hide' : 'Show'}</button></div></label>
			{corporate && organizations.length > 0 && <label>Organization<select className="corp-select" value={organizationId} onChange={event => setOrganizationId(event.target.value)}><option value="">Select organization</option>{organizations.map(org => <option key={org.organization_id} value={org.organization_id}>{org.organization_name} ({org.role_label})</option>)}</select></label>}
			<div className="form-row"><label className="check"><input type="checkbox" checked={remember} onChange={event => setRemember(event.target.checked)} /> Remember me</label><span className="link-text">{corporate ? 'Change your password in Profile after login.' : 'Password changes are available in Profile after login.'}</span></div>
			<button className="primary-btn" type="submit" disabled={submitting}>{submitting ? 'Signing in...' : corporate ? 'Corporate Login' : 'Login'}</button>
		</form>
		{corporate
			? <p className="auth-footer"><Link to="/register/organization">Register your organization</Link> · <Link to="/join-organization">Join with an organization code</Link></p>
			: <p className="auth-footer">Don't have an account? <Link to="/register">Create one</Link></p>}
	</div></div>;
}
