import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { corporateApi, getApiErrorMessage } from '../services/api';
import '../styles/corporate.css';

const empty = { organization_name: '', organization_email: '', admin_name: '', admin_email: '', password: '', confirm: '', contact_phone: '', address: '' };

export default function RegisterOrganization() {
	const [form, setForm] = useState(empty);
	const [error, setError] = useState('');
	const [fieldErrors, setFieldErrors] = useState({});
	const [submitting, setSubmitting] = useState(false);
	const navigate = useNavigate();
	const update = event => setForm({ ...form, [event.target.name]: event.target.value });

	const submit = async (event) => {
		event.preventDefault();
		setError(''); setFieldErrors({});
		if (form.password !== form.confirm) { setError('Passwords do not match.'); return; }
		const { confirm, ...payload } = form;
		setSubmitting(true);
		try {
			const response = await corporateApi.registerOrganization(payload);
			navigate('/login', { replace: true, state: { message: `${response.data.message} Your organization code is ${response.data.data.organization.organization_code}.` } });
		} catch (requestError) {
			setFieldErrors(requestError.response?.data?.errors || {});
			setError(getApiErrorMessage(requestError));
		} finally {
			setSubmitting(false);
		}
	};
	const field = (name, label, props = {}) => <label>{label}<input name={name} value={form[name]} onChange={update} {...props} />{fieldErrors[name] && <span className="field-error">{fieldErrors[name]}</span>}</label>;

	return <div className="auth-page"><div className="auth-card wide">
		<div className="auth-brand"><span>₹</span><strong>SmartExpense</strong></div>
		<h1>Register your organization</h1><p className="muted">Create a corporate workspace. You become its Organization Administrator and receive a code employees use to join.</p>
		{error && <div className="form-error" role="alert">{error}</div>}
		<form onSubmit={submit}>
			{field('organization_name', 'Organization name', { required: true, maxLength: 150, placeholder: 'ABC Technologies' })}
			{field('organization_email', 'Organization email', { type: 'email', required: true, placeholder: 'info@company.com' })}
			{field('admin_name', 'Administrator name', { required: true, maxLength: 120, autoComplete: 'name' })}
			{field('admin_email', 'Administrator email', { type: 'email', required: true, autoComplete: 'email' })}
			{field('password', 'Password', { type: 'password', required: true, minLength: 8, maxLength: 128, autoComplete: 'new-password', placeholder: 'Minimum 8 characters' })}
			{field('confirm', 'Confirm password', { type: 'password', required: true, autoComplete: 'new-password' })}
			{field('contact_phone', 'Contact phone (optional)', { maxLength: 30 })}
			{field('address', 'Address (optional)', { maxLength: 300 })}
			<p className="muted small">Already have a personal SmartExpense account? Use its email and password to attach it to your new organization.</p>
			<button className="primary-btn" type="submit" disabled={submitting}>{submitting ? 'Registering...' : 'Register organization'}</button>
		</form>
		<p className="auth-footer"><Link to="/login">Back to Login</Link></p>
	</div></div>;
}
