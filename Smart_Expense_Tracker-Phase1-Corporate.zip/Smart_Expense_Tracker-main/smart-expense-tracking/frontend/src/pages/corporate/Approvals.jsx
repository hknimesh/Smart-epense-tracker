import { useEffect, useState } from 'react';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import ExpenseTable from '../../components/corporate/ExpenseTable';
import Pager from '../../components/corporate/Pager';
import ReasonDialog from '../../components/corporate/ReasonDialog';
import useLoader from '../../components/corporate/useLoader';
import { useAuth } from '../../context/AuthContext';
import { corporateApi, getApiErrorMessage } from '../../services/api';

/** queue: 'manager' (managers), 'verification' or 'payment' (finance officers). */
export default function Approvals({ queue, title, description }) {
	const { role } = useAuth();
	const effectiveQueue = queue || (role === 'manager' ? 'manager' : 'verification');
	const [page, setPage] = useState(1);
	const [searchDraft, setSearchDraft] = useState('');
	const [search, setSearch] = useState('');
	useEffect(() => { const t = setTimeout(() => { setSearch(searchDraft.trim()); setPage(1); }, 300); return () => clearTimeout(t); }, [searchDraft]);
	const { data, loading, error, reload } = useLoader(() => corporateApi.approvals({ queue: effectiveQueue, page, ...(search ? { search } : {}) }).then(r => r.data.data), [effectiveQueue, page, search]);
	const [notice, setNotice] = useState('');
	const [actionError, setActionError] = useState('');
	const [rejecting, setRejecting] = useState(null);
	const [busyId, setBusyId] = useState(null);
	const [viewing, setViewing] = useState(null);

	const act = async (expense, action, comments) => {
		setBusyId(expense.expense_id); setActionError(''); setNotice('');
		try {
			const response = await corporateApi.review(expense.expense_id, action, comments);
			setNotice(`${response.data.message} (${expense.title})`); setRejecting(null); reload();
		} catch (requestError) { setActionError(getApiErrorMessage(requestError)); reload(); setRejecting(null); }
		finally { setBusyId(null); }
	};
	const approveLabel = effectiveQueue === 'manager' ? 'Approve' : 'Verify';

	return <div className="corp-page"><div className="page-header"><div><h2>{title || (effectiveQueue === 'manager' ? 'Approvals' : effectiveQueue === 'payment' ? 'Reimbursements' : 'Verification')}</h2><p>{description || (effectiveQueue === 'manager' ? 'Expenses from your departments waiting for approval.' : effectiveQueue === 'payment' ? 'Verified expenses waiting to be paid.' : 'Manager-approved expenses waiting for finance verification.')}</p></div></div>
		{notice && <div className="form-success" role="status">{notice}</div>}
		{actionError && <div className="form-error" role="alert">{actionError}</div>}
		<div className="panel corp-filters corp-block"><label>Search queue<input type="search" value={searchDraft} onChange={e => setSearchDraft(e.target.value)} placeholder="Title, vendor or employee" /></label></div>
		<DashboardState loading={loading && !data} error={error} onRetry={reload}>{data && <section className="panel corp-block">
			<ExpenseTable expenses={data.expenses} onView={e => setViewing(e.expense_id)} empty="Nothing is waiting in this queue." renderActions={expense => <div className="corp-row-actions">
				<button type="button" className="text-btn" onClick={() => setViewing(expense.expense_id)}>View</button>
				{effectiveQueue === 'payment'
					? <button type="button" className="corp-ok" disabled={busyId === expense.expense_id} onClick={() => act(expense, 'pay')}>Mark paid</button>
					: <><button type="button" className="corp-ok" disabled={busyId === expense.expense_id} onClick={() => act(expense, 'approve')}>{approveLabel}</button><button type="button" className="corp-danger" disabled={busyId === expense.expense_id} onClick={() => setRejecting(expense)}>Reject</button></>}
			</div>} />
			<Pager pagination={data.pagination} onPage={setPage} /></section>}</DashboardState>
		{rejecting && <ReasonDialog title={`Reject "${rejecting.title}"`} message="The employee will see this reason." busy={busyId === rejecting.expense_id} onCancel={() => setRejecting(null)} onConfirm={reason => act(rejecting, 'reject', reason)} />}
		{viewing && <ExpenseDetailModal expenseId={viewing} onClose={() => setViewing(null)} />}
	</div>;
}
