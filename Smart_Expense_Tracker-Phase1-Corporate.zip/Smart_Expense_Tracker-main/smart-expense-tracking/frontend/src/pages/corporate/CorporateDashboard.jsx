import { Link } from 'react-router-dom';
import { useState } from 'react';
import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import { formatDateTime } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { useAuth } from '../../context/AuthContext';
import { corporateApi } from '../../services/api';
import EmployeeDashboard from './EmployeeDashboard';
import ExecutiveDashboard from './ExecutiveDashboard';
import FinanceDashboard from './FinanceDashboard';
import ManagerDashboard from './ManagerDashboard';

function AdminDashboard() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.adminDashboard().then(r => r.data.data));
	const [copied, setCopied] = useState(false);
	const c = data?.counts;
	const copy = async () => { try { await navigator.clipboard.writeText(data.organization.organization_code); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { /* clipboard unavailable */ } };
	return <div className="corp-page">
		<div className="page-header"><div><h2>Organization Overview</h2><p>{data?.organization?.organization_name || 'Your organization'}</p></div><Link className="primary-btn corp-cta" to="/corporate/employees">Manage employees</Link></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{c && <>
			<section className="panel corp-code"><div><small>Organization code</small><strong>{data.organization.organization_code}</strong><p className="muted">Share this code with employees so they can join. Joining is {data.organization.joining_enabled ? 'enabled' : 'disabled'}. Manage it in <Link to="/corporate/settings">Organization Settings</Link>.</p></div><button type="button" className="secondary-btn" onClick={copy}>{copied ? 'Copied' : 'Copy code'}</button></section>
			<div className="summary-grid">
				<SummaryCard title="Total employees" value={c.total_employees} detail="Members with the Employee role" icon="☺" tone="blue" />
				<SummaryCard title="Active memberships" value={c.active_memberships} detail={`${c.total_members} total members`} icon="✓" tone="green" />
				<SummaryCard title="Departments" value={c.total_departments} detail={`${c.active_departments} active`} icon="▦" tone="purple" />
				<SummaryCard title="Managers / Finance" value={`${c.by_role.manager} / ${c.by_role.finance_officer}`} detail={`${c.by_role.executive} executive(s)`} icon="★" tone="blue" />
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Department overview</h3><Link to="/corporate/departments" className="link-text">Manage</Link></div><div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>Department</th><th>Manager</th><th className="num">Members</th><th>Status</th></tr></thead><tbody>{data.departments.map(d => <tr key={d.department_id}><td>{d.department_name}</td><td>{d.manager_name || <span className="muted">Not assigned</span>}</td><td className="num">{d.member_count}</td><td>{d.status}</td></tr>)}</tbody></table></div></section>
				<section className="panel"><div className="panel-title"><h3>Recent activity</h3></div>{data.recent_activity.length === 0 ? <p className="corp-empty">No activity yet.</p> : <ul className="corp-activity">{data.recent_activity.map(a => <li key={a.log_id}><strong>{a.details || a.action}</strong><small>{a.actor_name} · {formatDateTime(a.created_at)}</small></li>)}</ul>}</section>
			</div>
		</>}</DashboardState>
	</div>;
}

export default function CorporateDashboard() {
	const { role } = useAuth();
	if (role === 'org_admin') return <AdminDashboard />;
	if (role === 'employee') return <EmployeeDashboard />;
	if (role === 'manager') return <ManagerDashboard />;
	if (role === 'finance_officer') return <FinanceDashboard />;
	if (role === 'executive') return <ExecutiveDashboard />;
	return <div className="panel corp-empty">Your role does not have a dashboard.</div>;
}
