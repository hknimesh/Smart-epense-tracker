import { useEffect, useState } from 'react';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import ExpenseFilters, { emptyFilters } from '../../components/corporate/ExpenseFilters';
import ExpenseTable from '../../components/corporate/ExpenseTable';
import Pager from '../../components/corporate/Pager';
import useLoader from '../../components/corporate/useLoader';
import { formatMoney } from '../../components/corporate/format';
import { useAuth } from '../../context/AuthContext';
import { corporateApi } from '../../services/api';

/** One list for every role. The server returns only what the signed-in role may see. */
export default function CorporateExpenses({ title = 'Corporate Expenses', description = 'Expense history for your scope.' }) {
	const { role } = useAuth();
	const isEmployee = role === 'employee';
	const [draft, setDraft] = useState(emptyFilters);
	const [filters, setFilters] = useState(emptyFilters);
	const [page, setPage] = useState(1);
	const [viewing, setViewing] = useState(null);
	const lists = useLoader(async () => {
		const [departments, employees] = await Promise.all([
			corporateApi.departments().then(r => r.data.data.departments),
			isEmployee ? Promise.resolve([]) : corporateApi.reportSummary({}).then(r => r.data.data.by_employee || []),
		]);
		return { departments, employees };
	});
	const list = useLoader(() => {
		const params = Object.fromEntries(Object.entries({ ...filters, page, per_page: 20 }).filter(([, v]) => v !== ''));
		return corporateApi.expenses(params).then(r => r.data.data);
	}, [filters, page]);
	useEffect(() => { const t = setTimeout(() => { setFilters(draft); setPage(1); }, 300); return () => clearTimeout(t); }, [draft]);

	return <div className="corp-page"><div className="page-header"><div><h2>{title}</h2><p>{description}</p></div></div>
		<div className="panel corp-block"><ExpenseFilters value={draft} onChange={setDraft} departments={lists.data?.departments} employees={lists.data?.employees} hideDepartment={isEmployee} /></div>
		<DashboardState loading={list.loading && !list.data} error={list.error} onRetry={list.reload}>{list.data && <section className="panel corp-block">
			<div className="corp-total">{list.data.pagination.total} expense(s) · total {formatMoney(list.data.total_amount)}</div>
			<ExpenseTable expenses={list.data.expenses} onView={e => setViewing(e.expense_id)} showEmployee={!isEmployee} showDepartment={!isEmployee} />
			<Pager pagination={list.data.pagination} onPage={setPage} /></section>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} canEdit={isEmployee} onClose={() => setViewing(null)} onChanged={list.reload} />}
	</div>;
}
