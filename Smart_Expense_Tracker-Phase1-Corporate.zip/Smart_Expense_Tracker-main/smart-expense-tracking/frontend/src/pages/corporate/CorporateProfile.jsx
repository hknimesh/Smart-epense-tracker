import { useAuth } from '../../context/AuthContext';
import Profile from '../Profile';

export default function CorporateProfile() {
	const { membership } = useAuth();
	return <div className="corp-page">
		<section className="panel corp-block"><div className="panel-title"><h3>Organization membership</h3></div>
			<dl className="corp-detail"><div><dt>Organization</dt><dd>{membership?.organization?.organization_name}</dd></div><div><dt>Role</dt><dd>{membership?.role_label}</dd></div><div><dt>Department</dt><dd>{membership?.department_name || 'Not assigned'}</dd></div><div><dt>Status</dt><dd>{membership?.membership_status}</dd></div></dl>
			<p className="muted small">Your role and department are assigned by your organization administrator and cannot be changed here.</p></section>
		<Profile />
	</div>;
}
