import { Navigate, Route, Routes } from 'react-router-dom';
import CorporateLayout from '../../components/corporate/CorporateLayout';
import { useAuth } from '../../context/AuthContext';
import Approvals from './Approvals';
import CorporateDashboard from './CorporateDashboard';
import CorporateExpenses from './CorporateExpenses';
import CorporateProfile from './CorporateProfile';
import Departments from './Departments';
import Employees from './Employees';
import OrganizationSettings from './OrganizationSettings';
import Reimbursements from './Reimbursements';
import Reports from './Reports';
import SubmitExpense from './SubmitExpense';

/** Convenience only: the server enforces every permission independently. */
function Only({ roles, children }) {
	const { role } = useAuth();
	return roles.includes(role) ? children : <Navigate to="/corporate" replace />;
}

export default function CorporateRoutes() {
	const { role } = useAuth();
	const expensesPage = {
		employee: <CorporateExpenses title="My Expenses" description="Every expense you submitted and where it stands." />,
		finance_officer: <CorporateExpenses title="Corporate Expenses" description="All expenses across the organization." />,
		executive: <CorporateExpenses title="Company Expenses" description="Company-wide expense history (read-only)." />,
	}[role];
	return <CorporateLayout><Routes>
		<Route index element={<CorporateDashboard />} />
		<Route path="submit" element={<Only roles={['employee']}><SubmitExpense /></Only>} />
		<Route path="expenses" element={expensesPage || <Navigate to="/corporate" replace />} />
		<Route path="reimbursements" element={<Only roles={['employee', 'finance_officer']}><Reimbursements /></Only>} />
		<Route path="profile" element={<Only roles={['employee']}><CorporateProfile /></Only>} />
		<Route path="team" element={<Only roles={['manager']}><CorporateExpenses title="Team Expenses" description="Expenses submitted by employees in the departments you manage." /></Only>} />
		<Route path="approvals" element={<Only roles={['manager', 'finance_officer']}><Approvals /></Only>} />
		<Route path="department-expenses" element={<Only roles={['manager']}><Reports title="Department Expenses" description="Spending totals and history for your departments." /></Only>} />
		<Route path="reports" element={<Only roles={['finance_officer', 'executive']}><Reports title={role === 'executive' ? 'Financial Reports' : 'Reports'} description="Expense totals computed from organization records." /></Only>} />
		<Route path="employees" element={<Only roles={['org_admin']}><Employees /></Only>} />
		<Route path="departments" element={<Only roles={['org_admin', 'executive']}><Departments /></Only>} />
		<Route path="settings" element={<Only roles={['org_admin']}><OrganizationSettings /></Only>} />
		<Route path="*" element={<Navigate to="/corporate" replace />} />
	</Routes></CorporateLayout>;
}
