import { useState } from 'react';
import DashboardState from '../../components/corporate/DashboardState';
import { DepartmentChart } from '../../components/corporate/Charts';
import useLoader from '../../components/corporate/useLoader';
import { formatMoney } from '../../components/corporate/format';
import { useAuth } from '../../context/AuthContext';
import { corporateApi, getApiErrorMessage } from '../../services/api';

/** Admin: manage departments. Executive: read-only department-wise expenditure. */
function DepartmentSpend() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.reportSummary({}).then(r => r.data.data));
	return <div className="corp-page"><div className="page-header"><div><h2>Departments</h2><p>Expenditure by department (approved + paid expenses).</p></div></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{data && <>
			<section className="panel corp-block"><div className="panel-title"><h3>Expenditure by department</h3></div><DepartmentChart data={data.by_department} /></section>
			<section className="panel corp-block"><div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>Department</th><th className="num">Expenses</th><th className="num">Submitted</th><th className="num">Pending</th><th className="num">Rejected</th><th className="num">Approved</th><th className="num">Paid</th><th className="num">Expenditure</th></tr></thead>
				<tbody>{data.by_department.map(d => <tr key={d.department_id}><td>{d.department_name}</td><td className="num">{d.submitted_count}</td><td className="num">{formatMoney(d.submitted_amount)}</td><td className="num">{formatMoney(d.pending_amount)}</td><td className="num">{formatMoney(d.rejected_amount)}</td><td className="num">{formatMoney(d.approved_amount)}</td><td className="num">{formatMoney(d.paid_amount)}</td><td className="num"><strong>{formatMoney(d.expenditure_amount)}</strong></td></tr>)}</tbody></table></div></section></>}</DashboardState></div>;
}

function ManageDepartments() {
	const depts = useLoader(() => corporateApi.departments().then(r => r.data.data.departments));
	const people = useLoader(() => corporateApi.members({ role: 'manager', status: 'active' }).then(r => r.data.data.members));
	const [name, setName] = useState('');
	const [notice, setNotice] = useState('');
	const [error, setError] = useState('');
	const [renaming, setRenaming] = useState(null);
	const [members, setMembers] = useState(null);

	const run = async (promise, success) => {
		setError(''); setNotice('');
		try { await promise; setNotice(success); depts.reload(); } catch (requestError) { setError(getApiErrorMessage(requestError)); depts.reload(); }
	};
	const create = async (event) => { event.preventDefault(); await run(corporateApi.createDepartment({ department_name: name }), 'Department created.'); setName(''); };
	const showMembers = async (d) => {
		try { const r = await corporateApi.departmentMembers(d.department_id); setMembers({ department: d, list: r.data.data.members }); } catch (requestError) { setError(getApiErrorMessage(requestError)); }
	};

	return <div className="corp-page"><div className="page-header"><div><h2>Departments</h2><p>Create departments, assign managers and see who works where.</p></div></div>
		{notice && <div className="form-success" role="status">{notice}</div>}
		{error && <div className="form-error" role="alert">{error}</div>}
		<form className="panel corp-inline-form corp-block" onSubmit={create}><label className="corp-field">New department<input value={name} onChange={e => setName(e.target.value)} maxLength={100} required placeholder="e.g. Legal" /></label><button className="primary-btn" type="submit">Create department</button></form>
		<DashboardState loading={depts.loading} error={depts.error} onRetry={depts.reload}>{depts.data && <section className="panel corp-block"><div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>Department</th><th>Manager</th><th className="num">Members</th><th>Status</th><th>Actions</th></tr></thead><tbody>
			{depts.data.map(d => <tr key={d.department_id}>
				<td>{renaming?.id === d.department_id
					? <form className="corp-rename" onSubmit={async e => { e.preventDefault(); await run(corporateApi.updateDepartment(d.department_id, { department_name: renaming.name }), 'Department renamed.'); setRenaming(null); }}><input aria-label="Department name" value={renaming.name} onChange={e => setRenaming({ ...renaming, name: e.target.value })} maxLength={100} /><button className="text-btn" type="submit">Save</button><button className="text-btn" type="button" onClick={() => setRenaming(null)}>Cancel</button></form>
					: d.department_name}</td>
				<td><select aria-label={`Manager for ${d.department_name}`} value={d.manager_id || ''} onChange={e => run(corporateApi.updateDepartment(d.department_id, { manager_id: e.target.value ? Number(e.target.value) : null }), 'Manager updated.')}><option value="">Not assigned</option>{(people.data || []).map(m => <option key={m.user_id} value={m.user_id}>{m.user_name}</option>)}</select></td>
				<td className="num">{d.member_count}</td><td><span className={d.status === 'active' ? 'corp-chip on' : 'corp-chip'}>{d.status}</span></td>
				<td className="corp-actions"><button type="button" className="text-btn" onClick={() => showMembers(d)}>Members</button><button type="button" className="text-btn" onClick={() => setRenaming({ id: d.department_id, name: d.department_name })}>Rename</button><button type="button" className="text-btn" onClick={() => run(corporateApi.updateDepartment(d.department_id, { status: d.status === 'active' ? 'inactive' : 'active' }), `Department ${d.status === 'active' ? 'deactivated' : 'activated'}.`)}>{d.status === 'active' ? 'Deactivate' : 'Activate'}</button></td></tr>)}</tbody></table></div></section>}</DashboardState>
		{members && <div className="corp-modal-backdrop" onClick={e => { if (e.target === e.currentTarget) setMembers(null); }}><div className="corp-modal small" role="dialog" aria-modal="true" aria-label="Department members"><div className="corp-modal-head"><h3>{members.department.department_name} members</h3><button type="button" className="text-btn" onClick={() => setMembers(null)}>Close</button></div>
			{members.list.length === 0 ? <p className="corp-empty">No members assigned. Assign people from the Employees page.</p> : <ul className="corp-activity">{members.list.map(m => <li key={m.membership_id}><strong>{m.user_name}</strong><small>{m.role_label} · {m.membership_status}</small></li>)}</ul>}</div></div>}
	</div>;
}

export default function Departments() {
	const { role } = useAuth();
	return role === 'org_admin' ? <ManageDepartments /> : <DepartmentSpend />;
}
export { DepartmentSpend };
