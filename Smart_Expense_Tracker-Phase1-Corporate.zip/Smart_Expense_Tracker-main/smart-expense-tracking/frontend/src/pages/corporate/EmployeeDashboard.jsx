import { useState } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import ExpenseTable from '../../components/corporate/ExpenseTable';
import { MonthlyChart } from '../../components/corporate/Charts';
import { formatMoney } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { corporateApi } from '../../services/api';

export default function EmployeeDashboard() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.dashboard('employee').then(r => r.data.data));
	const [viewing, setViewing] = useState(null);
	const s = data?.summary;
	return <div className="corp-page">
		<div className="page-header"><div><h2>My Expense Dashboard</h2><p>Your corporate expense claims and their approval status.</p></div><Link className="primary-btn corp-cta" to="/corporate/submit">Submit Expense</Link></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{s && <>
			<div className="summary-grid">
				<SummaryCard title="Total submitted" value={s.submitted_count} detail={formatMoney(s.submitted_amount)} icon="▤" tone="blue" />
				<SummaryCard title="Approved" value={s.approved_count + s.paid_count} detail={formatMoney(Number(s.approved_amount) + Number(s.paid_amount))} icon="✓" tone="green" />
				<SummaryCard title="Pending" value={s.pending_count} detail={formatMoney(s.pending_amount)} icon="…" tone="purple" />
				<SummaryCard title="Rejected" value={s.rejected_count} detail={formatMoney(s.rejected_amount)} icon="✕" tone="red" />
			</div>
			<div className="summary-grid corp-two">
				<SummaryCard title="Reimbursement awaiting payment" value={formatMoney(s.approved_amount)} detail={`${s.approved_count} verified expense(s)`} icon="₹" tone="purple" />
				<SummaryCard title="Reimbursed (paid)" value={formatMoney(s.paid_amount)} detail={`${s.paid_count} paid expense(s)`} icon="₹" tone="green" />
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Recent expenses</h3><Link to="/corporate/expenses" className="link-text">View all</Link></div><ExpenseTable expenses={data.recent} onView={e => setViewing(e.expense_id)} showEmployee={false} showDepartment={false} empty="You have not submitted any expenses yet." /></section>
				<section className="panel"><div className="panel-title"><h3>Last 6 months</h3></div><MonthlyChart data={data.monthly} /></section>
			</div>
		</>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} canEdit onClose={() => setViewing(null)} onChanged={reload} />}
	</div>;
}
