import { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import DashboardState from '../../components/corporate/DashboardState';
import useCorporateMeta from '../../components/corporate/useCorporateMeta';
import useLoader from '../../components/corporate/useLoader';
import { formatDate } from '../../components/corporate/format';
import { useAuth } from '../../context/AuthContext';
import { corporateApi, getApiErrorMessage } from '../../services/api';

const emptyNew = { name: '', email: '', password: '', role: 'employee', department_id: '' };

export default function Employees() {
	const meta = useCorporateMeta();
	const { membership } = useAuth();
	const [filters, setFilters] = useState({ search: '', role: '', status: '' });
	const members = useLoader(() => corporateApi.members(filters).then(r => r.data.data.members), [filters.search, filters.role, filters.status]);
	const depts = useLoader(() => corporateApi.departments().then(r => r.data.data.departments));
	const [notice, setNotice] = useState('');
	const [error, setError] = useState('');
	const [adding, setAdding] = useState(false);
	const [form, setForm] = useState(emptyNew);
	const [fieldErrors, setFieldErrors] = useState({});
	const [busy, setBusy] = useState(false);
	const activeDepts = (depts.data || []).filter(d => d.status === 'active');

	const patch = async (member, changes) => {
		setError(''); setNotice('');
		try { await corporateApi.updateMember(member.membership_id, changes); setNotice(`${member.user_name} updated.`); members.reload(); }
		catch (requestError) { setError(getApiErrorMessage(requestError)); members.reload(); }
	};
	const add = async (event) => {
		event.preventDefault(); setBusy(true); setError(''); setFieldErrors({});
		try {
			const payload = { ...form, department_id: form.department_id ? Number(form.department_id) : null };
			const response = await corporateApi.addMember(payload);
			setNotice(response.data.message); setAdding(false); setForm(emptyNew); members.reload();
		} catch (requestError) { setFieldErrors(requestError.response?.data?.errors || {}); setError(getApiErrorMessage(requestError)); }
		finally { setBusy(false); }
	};
	const err = key => fieldErrors[key] && <span className="field-error">{fieldErrors[key]}</span>;

	return <div className="corp-page">
		<div className="page-header"><div><h2>Employees</h2><p>Manage members, roles, departments and access.</p></div><button type="button" className="primary-btn corp-cta" onClick={() => { setAdding(!adding); setError(''); }}>{adding ? 'Close' : 'Add employee'}</button></div>
		{notice && <div className="form-success" role="status">{notice}</div>}
		{error && <div className="form-error" role="alert">{error}</div>}
		{adding && <form className="panel corp-form corp-block" onSubmit={add}>
			<h3>Add a new member</h3><p className="muted small">Creates a new account with a temporary password. If the person already has an account, ask them to join using the organization code instead.</p>
			<div className="corp-form-row"><label className="corp-field">Full name<input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required maxLength={120} />{err('name')}</label><label className="corp-field">Email<input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />{err('email')}</label></div>
			<div className="corp-form-row"><label className="corp-field">Temporary password<input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required minLength={8} autoComplete="new-password" />{err('password')}</label>
				<label className="corp-field">Role<select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>{meta.roles.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}</select>{err('role')}</label>
				<label className="corp-field">Department<select value={form.department_id} onChange={e => setForm({ ...form, department_id: e.target.value })}><option value="">None</option>{activeDepts.map(d => <option key={d.department_id} value={d.department_id}>{d.department_name}</option>)}</select>{err('department_id')}</label></div>
			<div className="corp-modal-actions"><button className="primary-btn" type="submit" disabled={busy}>{busy ? 'Adding...' : 'Add member'}</button></div>
		</form>}
		<div className="corp-filters panel"><label>Search<input value={filters.search} onChange={e => setFilters({ ...filters, search: e.target.value })} placeholder="Name or email" /></label>
			<label>Role<select value={filters.role} onChange={e => setFilters({ ...filters, role: e.target.value })}><option value="">All roles</option>{meta.roles.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}</select></label>
			<label>Status<select value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })}><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></select></label></div>
		<DashboardState loading={members.loading} error={members.error} onRetry={members.reload}>{members.data && <section className="panel corp-block">
			{members.data.length === 0 ? <p className="corp-empty">No members match.</p> : <div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Joined</th><th>Status</th></tr></thead><tbody>
				{members.data.map(m => { const self = m.membership_id === membership.membership_id; return <tr key={m.membership_id}>
					<td>{m.user_name}{self && <small className="corp-sub">You</small>}</td><td>{m.user_email}</td>
					<td><select aria-label={`Role for ${m.user_name}`} value={m.role} disabled={self} onChange={e => patch(m, { role: e.target.value })}>{meta.roles.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}</select></td>
					<td><select aria-label={`Department for ${m.user_name}`} value={m.department_id || ''} onChange={e => patch(m, { department_id: e.target.value ? Number(e.target.value) : null })}><option value="">Unassigned</option>{(depts.data || []).map(d => <option key={d.department_id} value={d.department_id}>{d.department_name}{d.status !== 'active' ? ' (inactive)' : ''}</option>)}</select></td>
					<td>{formatDate(m.joined_at)}</td>
					<td><button type="button" className={m.membership_status === 'active' ? 'corp-chip on' : 'corp-chip'} disabled={self} onClick={() => patch(m, { membership_status: m.membership_status === 'active' ? 'inactive' : 'active' })}>{m.membership_status === 'active' ? 'Active' : 'Inactive'}</button></td>
				</tr>; })}</tbody></table></div>}</section>}</DashboardState>
	</div>;
}
