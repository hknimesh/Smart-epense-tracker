import { useState } from 'react';
import { Link } from 'react-router-dom';
import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import { DepartmentChart, MonthlyChart } from '../../components/corporate/Charts';
import StatusBadge from '../../components/corporate/StatusBadge';
import { formatDateTime, formatMoney } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { corporateApi } from '../../services/api';

export default function ExecutiveDashboard() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.dashboard('executive').then(r => r.data.data));
	const [viewing, setViewing] = useState(null);
	const s = data?.summary;
	return <div className="corp-page">
		<div className="page-header"><div><h2>Executive Overview</h2><p>Company-wide expenditure summaries and trends.</p></div><Link className="primary-btn corp-cta" to="/corporate/reports">Financial reports</Link></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{s && <>
			<div className="summary-grid">
				<SummaryCard title="Total company expenditure" value={formatMoney(s.expenditure_amount)} detail="Approved + paid" icon="₹" tone="green" />
				<SummaryCard title="Submitted (all statuses)" value={formatMoney(s.submitted_amount)} detail={`${s.submitted_count} expenses`} icon="▤" tone="blue" />
				<SummaryCard title="In approval pipeline" value={formatMoney(s.pending_amount)} detail={`${s.pending_count} pending`} icon="…" tone="purple" />
				<SummaryCard title="Paid out" value={formatMoney(s.paid_amount)} detail={`${s.paid_count} paid`} icon="✓" tone="green" />
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Department-wise expenditure</h3></div><DepartmentChart data={data.by_department} /></section>
				<section className="panel"><div className="panel-title"><h3>Monthly trend</h3></div><MonthlyChart data={data.monthly} /></section>
			</div>
			<section className="panel corp-block"><div className="panel-title"><h3>Monthly expense summary</h3></div><div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>Month</th><th className="num">Expenses</th><th className="num">Submitted</th><th className="num">Expenditure</th></tr></thead><tbody>{data.monthly.map(m => <tr key={m.label}><td>{m.label}</td><td className="num">{m.submitted_count}</td><td className="num">{formatMoney(m.submitted_amount)}</td><td className="num">{formatMoney(m.expenditure_amount)}</td></tr>)}</tbody></table></div></section>
			<section className="panel corp-block"><div className="panel-title"><h3>Recent financial activity</h3></div>
				{data.recent_activity.length === 0 ? <p className="corp-empty">No activity yet.</p> : <div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>When</th><th>Expense</th><th className="num">Amount</th><th>Event</th></tr></thead><tbody>{data.recent_activity.map(t => <tr key={t.approval_id}><td>{formatDateTime(t.action_date)}</td><td><button type="button" className="corp-link" onClick={() => setViewing(t.expense_id)}>{t.title}</button><small className="corp-sub">{t.employee_name}</small></td><td className="num">{formatMoney(t.amount)}</td><td><StatusBadge status={t.new_status} /></td></tr>)}</tbody></table></div>}</section>
		</>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} onClose={() => setViewing(null)} />}
	</div>;
}
