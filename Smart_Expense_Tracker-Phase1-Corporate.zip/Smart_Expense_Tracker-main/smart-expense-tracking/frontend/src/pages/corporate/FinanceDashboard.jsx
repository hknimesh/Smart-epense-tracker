import { useState } from 'react';
import { Link } from 'react-router-dom';
import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import { DepartmentChart, MonthlyChart } from '../../components/corporate/Charts';
import StatusBadge from '../../components/corporate/StatusBadge';
import { formatDateTime, formatMoney } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { corporateApi } from '../../services/api';

export default function FinanceDashboard() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.dashboard('finance').then(r => r.data.data));
	const [viewing, setViewing] = useState(null);
	const s = data?.summary;
	return <div className="corp-page">
		<div className="page-header"><div><h2>Finance Overview</h2><p>Organization-wide expenses, verification and reimbursement status.</p></div><Link className="primary-btn corp-cta" to="/corporate/approvals">Verify expenses</Link></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{s && <>
			<div className="summary-grid">
				<SummaryCard title="Total corporate expenditure" value={formatMoney(s.expenditure_amount)} detail="Approved + paid" icon="₹" tone="green" />
				<SummaryCard title="Approved expenses" value={s.expenditure_count} detail="Verified by finance (incl. paid)" icon="✓" tone="blue" />
				<SummaryCard title="Pending finance verification" value={s.pending_finance_count} detail={formatMoney(s.pending_finance_amount)} icon="…" tone="purple" />
				<SummaryCard title="Reimbursement pending" value={formatMoney(s.approved_amount)} detail={`${s.approved_count} verified, awaiting payment`} icon="₹" tone="red" />
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Department-wise expenditure</h3></div><DepartmentChart data={data.by_department} /></section>
				<section className="panel"><div className="panel-title"><h3>Last 6 months</h3></div><MonthlyChart data={data.monthly} /></section>
			</div>
			<section className="panel corp-block"><div className="panel-title"><h3>Recent financial transactions</h3><Link to="/corporate/reports" className="link-text">Reports</Link></div>
				{data.recent_transactions.length === 0 ? <p className="corp-empty">No transactions yet.</p> : <div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>When</th><th>Expense</th><th>Employee</th><th className="num">Amount</th><th>Event</th><th>By</th></tr></thead>
					<tbody>{data.recent_transactions.map(t => <tr key={t.approval_id}><td>{formatDateTime(t.action_date)}</td><td><button type="button" className="corp-link" onClick={() => setViewing(t.expense_id)}>{t.title}</button></td><td>{t.employee_name}</td><td className="num">{formatMoney(t.amount)}</td><td><StatusBadge status={t.new_status} /></td><td>{t.reviewer_name}</td></tr>)}</tbody></table></div>}</section>
		</>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} onClose={() => setViewing(null)} />}
	</div>;
}
