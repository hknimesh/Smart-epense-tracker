import { useState } from 'react';
import { Link } from 'react-router-dom';
import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import ExpenseTable from '../../components/corporate/ExpenseTable';
import { DepartmentChart, MonthlyChart } from '../../components/corporate/Charts';
import { formatMoney } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { corporateApi } from '../../services/api';

export default function ManagerDashboard() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.dashboard('manager').then(r => r.data.data));
	const [viewing, setViewing] = useState(null);
	const s = data?.summary;
	return <div className="corp-page">
		<div className="page-header"><div><h2>Manager Overview</h2><p>Expenditure and approvals for the departments you manage.</p></div><Link className="primary-btn corp-cta" to="/corporate/approvals">Review approvals</Link></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{s && <>
			{data.departments.length === 0 && <div className="form-error" role="status">You are not assigned as manager of any department yet. Ask your administrator.</div>}
			{data.alerts.map((a, i) => <div key={i} className={`corp-alert ${a.level}`} role="status">{a.message}</div>)}
			<div className="summary-grid">
				<SummaryCard title="Department expenditure" value={formatMoney(s.expenditure_amount)} detail={`${formatMoney(data.this_month.expenditure_amount)} this month`} icon="₹" tone="green" />
				<SummaryCard title="Pending approvals" value={s.pending_manager_count} detail={formatMoney(s.pending_manager_amount)} icon="…" tone="purple" />
				<SummaryCard title="Total submitted" value={s.submitted_count} detail={formatMoney(s.submitted_amount)} icon="▤" tone="blue" />
				<SummaryCard title="Rejected" value={s.rejected_count} detail={formatMoney(s.rejected_amount)} icon="✕" tone="red" />
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Pending your approval</h3><Link to="/corporate/approvals" className="link-text">Open approvals</Link></div><ExpenseTable expenses={data.pending_approvals} onView={e => setViewing(e.expense_id)} showDepartment={false} empty="Nothing is waiting for your approval." /></section>
				<section className="panel"><div className="panel-title"><h3>Expenditure by department</h3></div><DepartmentChart data={data.departments} /></section>
			</div>
			<section className="panel corp-block"><div className="panel-title"><h3>Recently submitted</h3><Link to="/corporate/team" className="link-text">Team expenses</Link></div><ExpenseTable expenses={data.recent_submissions} onView={e => setViewing(e.expense_id)} /></section>
			<section className="panel corp-block"><div className="panel-title"><h3>Last 6 months</h3></div><MonthlyChart data={data.monthly} /></section>
		</>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} onClose={() => setViewing(null)} />}
	</div>;
}
