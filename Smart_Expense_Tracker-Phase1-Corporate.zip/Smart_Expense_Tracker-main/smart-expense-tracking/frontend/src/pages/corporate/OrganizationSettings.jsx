import { useEffect, useState } from 'react';
import DashboardState from '../../components/corporate/DashboardState';
import ConfirmDialog from '../../components/ConfirmDialog';
import useLoader from '../../components/corporate/useLoader';
import { corporateApi, getApiErrorMessage } from '../../services/api';

export default function OrganizationSettings() {
	const { data, loading, error, reload } = useLoader(() => corporateApi.organization().then(r => r.data.data.organization));
	const [form, setForm] = useState(null);
	const [notice, setNotice] = useState('');
	const [formError, setFormError] = useState('');
	const [fieldErrors, setFieldErrors] = useState({});
	const [confirmRegen, setConfirmRegen] = useState(false);
	const [busy, setBusy] = useState(false);
	useEffect(() => { if (data) setForm({ organization_name: data.organization_name, organization_email: data.organization_email, contact_phone: data.contact_phone || '', address: data.address || '', joining_enabled: data.joining_enabled }); }, [data]);

	const save = async (event) => {
		event.preventDefault(); setBusy(true); setNotice(''); setFormError(''); setFieldErrors({});
		try { await corporateApi.updateOrganization(form); setNotice('Organization updated.'); reload(); }
		catch (requestError) { setFieldErrors(requestError.response?.data?.errors || {}); setFormError(getApiErrorMessage(requestError)); }
		finally { setBusy(false); }
	};
	const regenerate = async () => {
		setBusy(true);
		try { const r = await corporateApi.regenerateCode(); setNotice(r.data.message); reload(); } catch (requestError) { setFormError(getApiErrorMessage(requestError)); }
		finally { setBusy(false); setConfirmRegen(false); }
	};
	const err = key => fieldErrors[key] && <span className="field-error">{fieldErrors[key]}</span>;

	return <div className="corp-page"><div className="page-header"><div><h2>Organization Settings</h2><p>Organization details and the code employees use to join.</p></div></div>
		{notice && <div className="form-success" role="status">{notice}</div>}
		{formError && <div className="form-error" role="alert">{formError}</div>}
		<DashboardState loading={loading && !data} error={error} onRetry={reload}>{data && form && <>
			<section className="panel corp-code corp-block"><div><small>Organization code</small><strong>{data.organization_code}</strong><p className="muted">Employees enter this code on the “Join an organization” page. Regenerating it immediately invalidates the old code.</p></div><button type="button" className="secondary-btn" onClick={() => setConfirmRegen(true)} disabled={busy}>Regenerate code</button></section>
			<form className="panel corp-form corp-narrow" onSubmit={save}>
				<label className="corp-field">Organization name<input value={form.organization_name} onChange={e => setForm({ ...form, organization_name: e.target.value })} maxLength={150} required />{err('organization_name')}</label>
				<label className="corp-field">Organization email<input type="email" value={form.organization_email} onChange={e => setForm({ ...form, organization_email: e.target.value })} required />{err('organization_email')}</label>
				<div className="corp-form-row"><label className="corp-field">Contact phone<input value={form.contact_phone} onChange={e => setForm({ ...form, contact_phone: e.target.value })} maxLength={30} />{err('contact_phone')}</label><label className="corp-field">Address<input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} maxLength={300} />{err('address')}</label></div>
				<label className="check"><input type="checkbox" checked={form.joining_enabled} onChange={e => setForm({ ...form, joining_enabled: e.target.checked })} /> Allow people to join with the organization code</label>
				<div className="corp-modal-actions"><button className="primary-btn" type="submit" disabled={busy}>{busy ? 'Saving...' : 'Save changes'}</button></div>
			</form></>}</DashboardState>
		{confirmRegen && <ConfirmDialog title="Regenerate organization code?" message="The current code will stop working. Anyone who has not joined yet will need the new code." confirming={busy} onCancel={() => setConfirmRegen(false)} onConfirm={regenerate} />}
	</div>;
}
