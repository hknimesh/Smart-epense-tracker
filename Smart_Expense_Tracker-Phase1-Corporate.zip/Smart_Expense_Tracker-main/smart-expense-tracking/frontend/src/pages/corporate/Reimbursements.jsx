import SummaryCard from '../../components/SummaryCard';
import DashboardState from '../../components/corporate/DashboardState';
import { formatMoney } from '../../components/corporate/format';
import useLoader from '../../components/corporate/useLoader';
import { useAuth } from '../../context/AuthContext';
import { corporateApi } from '../../services/api';
import Approvals from './Approvals';
import { useState } from 'react';
import ExpenseDetailModal from '../../components/corporate/ExpenseDetailModal';
import ExpenseTable from '../../components/corporate/ExpenseTable';

function MyReimbursements() {
	const { data, loading, error, reload } = useLoader(async () => {
		const [summary, list] = await Promise.all([corporateApi.dashboard('employee').then(r => r.data.data.summary), corporateApi.expenses({ status: 'pending_finance,approved,paid', per_page: 50 }).then(r => r.data.data)]);
		return { summary, list };
	});
	const [viewing, setViewing] = useState(null);
	return <div className="corp-page"><div className="page-header"><div><h2>Reimbursements</h2><p>Payment status of your expenses that passed manager approval.</p></div></div>
		<DashboardState loading={loading} error={error} onRetry={reload}>{data && <>
			<div className="summary-grid corp-three">
				<SummaryCard title="With finance for verification" value={formatMoney(data.summary.pending_finance_amount)} detail={`${data.summary.pending_finance_count} expense(s)`} icon="…" tone="purple" />
				<SummaryCard title="Verified, awaiting payment" value={formatMoney(data.summary.approved_amount)} detail={`${data.summary.approved_count} expense(s)`} icon="₹" tone="blue" />
				<SummaryCard title="Paid to you" value={formatMoney(data.summary.paid_amount)} detail={`${data.summary.paid_count} expense(s)`} icon="✓" tone="green" />
			</div>
			<section className="panel corp-block"><ExpenseTable expenses={data.list.expenses} onView={e => setViewing(e.expense_id)} showEmployee={false} showDepartment={false} empty="No expenses have reached finance yet." /></section></>}</DashboardState>
		{viewing && <ExpenseDetailModal expenseId={viewing} onClose={() => setViewing(null)} />}
	</div>;
}

export default function Reimbursements() {
	const { role } = useAuth();
	return role === 'finance_officer' ? <Approvals queue="payment" title="Reimbursements" description="Verified expenses waiting to be paid. Mark them paid once the payment is made." /> : <MyReimbursements />;
}
