import { useState } from 'react';
import DashboardState from '../../components/corporate/DashboardState';
import { DepartmentChart, MonthlyChart } from '../../components/corporate/Charts';
import ExpenseFilters, { emptyFilters } from '../../components/corporate/ExpenseFilters';
import useLoader from '../../components/corporate/useLoader';
import { formatMoney } from '../../components/corporate/format';
import { useAuth } from '../../context/AuthContext';
import { corporateApi, getApiErrorMessage } from '../../services/api';

const clean = filters => Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));

function Breakdown({ rows, nameKey, nameLabel }) {
	return <div className="corp-table-wrap"><table className="corp-table"><thead><tr><th>{nameLabel}</th><th className="num">Expenses</th><th className="num">Pending</th><th className="num">Rejected</th><th className="num">Approved</th><th className="num">Paid</th><th className="num">Submitted total</th></tr></thead>
		<tbody>{rows.map((r, i) => <tr key={i}><td>{r[nameKey]}</td><td className="num">{r.submitted_count}</td><td className="num">{formatMoney(r.pending_amount)}</td><td className="num">{formatMoney(r.rejected_amount)}</td><td className="num">{formatMoney(r.approved_amount)}</td><td className="num">{formatMoney(r.paid_amount)}</td><td className="num"><strong>{formatMoney(r.submitted_amount)}</strong></td></tr>)}</tbody></table></div>;
}

export default function Reports({ title = 'Reports', description = 'Expense totals computed from your organization records.' }) {
	const { role } = useAuth();
	const [filters, setFilters] = useState(emptyFilters);
	const [exportError, setExportError] = useState('');
	const departments = useLoader(() => corporateApi.departments().then(r => r.data.data.departments));
	const { data, loading, error, reload } = useLoader(() => corporateApi.reportSummary(clean(filters)).then(r => r.data.data), [JSON.stringify(filters)]);
	const canExport = role !== 'employee';

	const exportCsv = async () => {
		setExportError('');
		try {
			const response = await corporateApi.exportReport(clean(filters));
			const url = URL.createObjectURL(response.data);
			const link = document.createElement('a'); link.href = url; link.download = 'corporate-expenses.csv'; link.click(); URL.revokeObjectURL(url);
		} catch (requestError) { setExportError(getApiErrorMessage(requestError, 'Export failed.')); }
	};
	const s = data?.summary;
	return <div className="corp-page"><div className="page-header"><div><h2>{title}</h2><p>{description}</p></div>{canExport && <button type="button" className="secondary-btn" onClick={exportCsv}>Export CSV</button>}</div>
		{exportError && <div className="form-error" role="alert">{exportError}</div>}
		<div className="panel corp-block"><ExpenseFilters value={filters} onChange={setFilters} departments={departments.data || []} /></div>
		<DashboardState loading={loading && !data} error={error} onRetry={reload}>{s && <>
			<div className="corp-stats">
				{[['Submitted', s.submitted_count, s.submitted_amount], ['Pending manager', s.pending_manager_count, s.pending_manager_amount], ['Pending finance', s.pending_finance_count, s.pending_finance_amount], ['Approved (awaiting payment)', s.approved_count, s.approved_amount], ['Paid', s.paid_count, s.paid_amount], ['Rejected', s.rejected_count, s.rejected_amount]].map(([label, count, amount]) => <div key={label} className="corp-stat"><span>{label}</span><strong>{count}</strong><small>{formatMoney(amount)}</small></div>)}
			</div>
			<div className="dashboard-grid corp-grid">
				<section className="panel"><div className="panel-title"><h3>Department-wise expenditure</h3></div><DepartmentChart data={data.by_department} /></section>
				<section className="panel"><div className="panel-title"><h3>Monthly trend</h3></div><MonthlyChart data={data.monthly} /></section>
			</div>
			<section className="panel corp-block"><div className="panel-title"><h3>Department-wise totals</h3></div><Breakdown rows={data.by_department} nameKey="department_name" nameLabel="Department" /></section>
			<section className="panel corp-block"><div className="panel-title"><h3>Category totals</h3></div><Breakdown rows={data.by_category} nameKey="category" nameLabel="Category" /></section>
			{data.by_employee && <section className="panel corp-block"><div className="panel-title"><h3>Employee-wise expense records</h3></div><Breakdown rows={data.by_employee} nameKey="employee_name" nameLabel="Employee" /></section>}
		</>}</DashboardState>
	</div>;
}
