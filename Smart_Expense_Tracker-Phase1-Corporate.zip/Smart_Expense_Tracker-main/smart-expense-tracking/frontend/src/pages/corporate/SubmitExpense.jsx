import { useState } from 'react';
import { Link } from 'react-router-dom';
import ExpenseEditForm from '../../components/corporate/ExpenseEditForm';
import { useAuth } from '../../context/AuthContext';

export default function SubmitExpense() {
	const { membership } = useAuth();
	const [done, setDone] = useState(null);
	const [formKey, setFormKey] = useState(0);
	return <div className="corp-page"><div className="page-header"><div><h2>Submit Expense</h2><p>Your expense goes to your department manager, then to Finance.</p></div></div>
		{!membership?.department_id && <div className="form-error" role="alert">You are not assigned to a department yet, so you cannot submit expenses. Ask your administrator to assign you to one.</div>}
		{done && <div className="form-success" role="status">{done} <Link to="/corporate/expenses">View my expenses</Link></div>}
		<section className="panel corp-narrow"><p className="muted small">Department: <strong>{membership?.department_name || 'Not assigned'}</strong> (set by your administrator)</p>
			<ExpenseEditForm key={formKey} onSaved={(expense, message) => { setDone(`${message} "${expense.title}" was submitted.`); setFormKey(k => k + 1); }} /></section>
	</div>;
}
