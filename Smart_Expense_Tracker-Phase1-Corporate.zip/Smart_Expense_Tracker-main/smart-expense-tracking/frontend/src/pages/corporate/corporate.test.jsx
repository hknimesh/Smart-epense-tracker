import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import Login from '../Login';
import CorporateLayout from '../../components/corporate/CorporateLayout';
import StatusBadge from '../../components/corporate/StatusBadge';
import ExpenseTable from '../../components/corporate/ExpenseTable';
import ReasonDialog from '../../components/corporate/ReasonDialog';
import { NAV } from '../../components/corporate/format';

const auth = vi.hoisted(() => ({ value: {} }));
vi.mock('../../context/AuthContext', () => ({ useAuth: () => auth.value }));

const base = { login: vi.fn(), corporateLogin: vi.fn(), clearError: vi.fn(), error: '', logout: vi.fn(), switchMode: vi.fn(), memberships: [], user: { name: 'Test User', email: 't@x.test' } };
beforeEach(() => { auth.value = { ...base, login: vi.fn(), corporateLogin: vi.fn(), switchMode: vi.fn() }; });
afterEach(() => cleanup());

function renderLogin() {
	return render(<MemoryRouter initialEntries={['/login']}><Routes>
		<Route path="/login" element={<Login />} /><Route path="/dashboard" element={<p>Personal dashboard</p>} /><Route path="/corporate" element={<p>Corporate home</p>} />
		<Route path="/register/organization" element={<p>Org registration</p>} />
	</Routes></MemoryRouter>);
}
const fill = () => {
	fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'a@b.test' } });
	fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'correct horse battery' } });
};

describe('login mode selection', () => {
	it('offers Personal and Corporate Finance and defaults to the personal flow', async () => {
		auth.value.login.mockResolvedValue({});
		renderLogin();
		expect(screen.getByRole('tab', { name: /Personal Finance/ })).toHaveAttribute('aria-selected', 'true');
		expect(screen.getByRole('tab', { name: /Corporate Finance/ })).toHaveAttribute('aria-selected', 'false');
		fill(); fireEvent.click(screen.getByRole('button', { name: 'Login' }));
		expect(await screen.findByText('Personal dashboard')).toBeInTheDocument();
		expect(auth.value.corporateLogin).not.toHaveBeenCalled();
	});

	it('uses corporate authentication, never sends a role, and lands on the corporate area', async () => {
		auth.value.corporateLogin.mockResolvedValue({ role: 'manager' });
		renderLogin();
		fireEvent.click(screen.getByRole('tab', { name: /Corporate Finance/ }));
		expect(screen.getByRole('link', { name: 'Register your organization' })).toBeInTheDocument();
		fill(); fireEvent.click(screen.getByRole('button', { name: 'Corporate Login' }));
		expect(await screen.findByText('Corporate home')).toBeInTheDocument();
		expect(auth.value.corporateLogin).toHaveBeenCalledWith('a@b.test', 'correct horse battery', false, '');
		expect(auth.value.login).not.toHaveBeenCalled();
	});

	it('asks which organization to use when the account belongs to several', async () => {
		auth.value.corporateLogin
			.mockRejectedValueOnce({ response: { data: { message: 'Select the organization to sign in to.', errors: { organization_required: true, organizations: [{ organization_id: 7, organization_name: 'Beta Corp', role_label: 'Employee' }, { organization_id: 9, organization_name: 'Acme', role_label: 'Manager' }] } } } })
			.mockResolvedValueOnce({});
		renderLogin();
		fireEvent.click(screen.getByRole('tab', { name: /Corporate Finance/ }));
		fill(); fireEvent.click(screen.getByRole('button', { name: 'Corporate Login' }));
		const select = await screen.findByLabelText('Organization');
		expect(within(select).getAllByRole('option')).toHaveLength(3);
		fireEvent.click(screen.getByRole('button', { name: 'Corporate Login' }));
		expect(await screen.findByRole('alert')).toHaveTextContent('Select the organization');
		fireEvent.change(select, { target: { value: '9' } });
		fireEvent.click(screen.getByRole('button', { name: 'Corporate Login' }));
		await waitFor(() => expect(auth.value.corporateLogin).toHaveBeenLastCalledWith('a@b.test', 'correct horse battery', false, '9'));
	});

	it('shows the server error for invalid corporate credentials', async () => {
		auth.value.corporateLogin.mockRejectedValue({ response: { data: { message: 'Invalid email or password.' } } });
		renderLogin();
		fireEvent.click(screen.getByRole('tab', { name: /Corporate Finance/ }));
		fill(); fireEvent.click(screen.getByRole('button', { name: 'Corporate Login' }));
		expect(await screen.findByRole('alert')).toHaveTextContent('Invalid email or password.');
	});
});

describe('role-based navigation', () => {
	const expected = {
		org_admin: ['Overview', 'Employees', 'Departments', 'Organization Settings'],
		employee: ['Dashboard', 'Submit Expense', 'My Expenses', 'Reimbursements', 'Profile'],
		manager: ['Overview', 'Team Expenses', 'Approvals', 'Department Expenses'],
		finance_officer: ['Overview', 'Corporate Expenses', 'Verification', 'Reimbursements', 'Reports'],
		executive: ['Overview', 'Company Expenses', 'Departments', 'Financial Reports'],
	};
	it.each(Object.entries(expected))('%s sees exactly its navigation', (role, labels) => {
		expect(NAV[role].map(([, label]) => label)).toEqual(labels);
		auth.value = { ...auth.value, membership: { role, role_label: role, organization: { organization_name: 'Acme', is_demo: role === 'manager' } } };
		render(<MemoryRouter><CorporateLayout><p>content</p></CorporateLayout></MemoryRouter>);
		const nav = screen.getByRole('navigation');
		expect(within(nav).getAllByRole('link').map(a => a.textContent)).toEqual(labels);
		expect(!!screen.queryByRole('note')).toBe(role === 'manager');
	});
});

describe('shared components', () => {
	it('labels every workflow status', () => {
		const { rerender } = render(<StatusBadge status="pending_manager" />);
		expect(screen.getByText('Pending Manager Approval')).toBeInTheDocument();
		for (const [status, text] of [['pending_finance', 'Pending Finance Verification'], ['approved', 'Approved'], ['paid', 'Paid'], ['rejected', 'Rejected']]) {
			rerender(<StatusBadge status={status} />);
			expect(screen.getByText(text)).toBeInTheDocument();
		}
	});

	it('renders expense rows with formatted amounts and row actions', () => {
		const onView = vi.fn();
		render(<ExpenseTable onView={onView} expenses={[{ expense_id: 1, expense_date: '2026-10-05', title: 'Taxi', vendor: 'Ola', employee_name: 'Isha', department_name: 'IT', category: 'Travel', amount: '1250.50', approval_status: 'paid' }]} />);
		expect(screen.getByText('₹1,250.50')).toBeInTheDocument();
		fireEvent.click(screen.getByRole('button', { name: 'Taxi' }));
		expect(onView).toHaveBeenCalledOnce();
		cleanup();
		render(<ExpenseTable expenses={[]} />);
		expect(screen.getByText(/No expenses match/)).toBeInTheDocument();
	});

	it('requires a rejection reason before confirming', () => {
		const onConfirm = vi.fn();
		render(<ReasonDialog title="Reject" message="why" onCancel={() => {}} onConfirm={onConfirm} />);
		const button = screen.getByRole('button', { name: 'Reject' });
		expect(button).toBeDisabled();
		fireEvent.change(screen.getByLabelText(/Reason/), { target: { value: 'Not a business expense' } });
		expect(button).toBeEnabled();
		fireEvent.click(button);
		expect(onConfirm).toHaveBeenCalledWith('Not a business expense');
	});
});
